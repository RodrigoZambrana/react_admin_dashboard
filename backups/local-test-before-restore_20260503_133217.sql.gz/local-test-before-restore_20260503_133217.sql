--
-- PostgreSQL database dump
--

\restrict EqtJ91IdSxBbTzoIEFZlc29CBKCnX8QxTvzXNajHpqQ2hl2uxo16dOtDqanuXjg

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: CatalogExposureMode; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CatalogExposureMode" AS ENUM (
    'AUTO',
    'M2_DERIVED',
    'UNITARY',
    'EMPTY_IF_NO_PUBLIC_CALCULABLE'
);


ALTER TYPE public."CatalogExposureMode" OWNER TO postgres;

--
-- Name: CmsEntryAssetType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CmsEntryAssetType" AS ENUM (
    'IMAGE',
    'VIDEO',
    'EMBED'
);


ALTER TYPE public."CmsEntryAssetType" OWNER TO postgres;

--
-- Name: CmsEntryStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CmsEntryStatus" AS ENUM (
    'DRAFT',
    'PUBLISHED',
    'ARCHIVED'
);


ALTER TYPE public."CmsEntryStatus" OWNER TO postgres;

--
-- Name: CmsMediaType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CmsMediaType" AS ENUM (
    'IMAGE',
    'VIDEO',
    'DOCUMENT',
    'EMBED',
    'AUDIO'
);


ALTER TYPE public."CmsMediaType" OWNER TO postgres;

--
-- Name: CmsPageBlockType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CmsPageBlockType" AS ENUM (
    'TEXT',
    'RICH_TEXT',
    'IMAGE',
    'BUTTON',
    'LIST_ITEM',
    'FAQ_ITEM',
    'CARD'
);


ALTER TYPE public."CmsPageBlockType" OWNER TO postgres;

--
-- Name: CmsPageScope; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CmsPageScope" AS ENUM (
    'GENERAL_SITE',
    'STOREFRONT'
);


ALTER TYPE public."CmsPageScope" OWNER TO postgres;

--
-- Name: CmsPageSectionType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CmsPageSectionType" AS ENUM (
    'SITE_HEADER',
    'HERO',
    'RICH_TEXT',
    'MEDIA_GRID',
    'MEDIA_CAROUSEL',
    'CONTENT_SPLIT',
    'CTA_BANNER',
    'FAQ',
    'FEATURE_GRID',
    'BUDGET_CALCULATOR',
    'SITE_FOOTER',
    'MEDIA_HERO',
    'MEDIA_GRID_ENHANCED',
    'STORIES_CAROUSEL',
    'VIDEO_SECTION',
    'HIGHLIGHT_CARDS'
);


ALTER TYPE public."CmsPageSectionType" OWNER TO postgres;

--
-- Name: ConversationChannel; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ConversationChannel" AS ENUM (
    'WEBCHAT',
    'EMAIL',
    'WHATSAPP',
    'FACEBOOK',
    'INSTAGRAM',
    'ADMIN_CHAT'
);


ALTER TYPE public."ConversationChannel" OWNER TO postgres;

--
-- Name: ConversationControlMode; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ConversationControlMode" AS ENUM (
    'AI',
    'HUMAN',
    'HYBRID'
);


ALTER TYPE public."ConversationControlMode" OWNER TO postgres;

--
-- Name: ConversationExternalIdentityKind; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ConversationExternalIdentityKind" AS ENUM (
    'USER',
    'THREAD',
    'CANONICAL',
    'ALIAS'
);


ALTER TYPE public."ConversationExternalIdentityKind" OWNER TO postgres;

--
-- Name: ConversationHandoffEventType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ConversationHandoffEventType" AS ENUM (
    'HUMAN_TAKEOVER',
    'HUMAN_RELEASE',
    'AI_SUGGEST_ONLY',
    'AI_RESUME',
    'ASSIGNED',
    'UNASSIGNED'
);


ALTER TYPE public."ConversationHandoffEventType" OWNER TO postgres;

--
-- Name: ConversationMessageAuthorType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ConversationMessageAuthorType" AS ENUM (
    'CUSTOMER',
    'OPERATOR',
    'AGENT',
    'SYSTEM'
);


ALTER TYPE public."ConversationMessageAuthorType" OWNER TO postgres;

--
-- Name: ConversationMessageKind; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ConversationMessageKind" AS ENUM (
    'TEXT',
    'EMAIL',
    'IMAGE',
    'FILE',
    'SYSTEM_EVENT',
    'TOOL_RESULT'
);


ALTER TYPE public."ConversationMessageKind" OWNER TO postgres;

--
-- Name: ConversationParticipantRole; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ConversationParticipantRole" AS ENUM (
    'CUSTOMER',
    'OPERATOR',
    'AGENT',
    'SYSTEM'
);


ALTER TYPE public."ConversationParticipantRole" OWNER TO postgres;

--
-- Name: ConversationRole; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ConversationRole" AS ENUM (
    'CUSTOMER_PUBLIC',
    'CUSTOMER_AUTHENTICATED',
    'ADMIN_SUPPORT',
    'ADMIN_SALES',
    'ADMIN_OPERATIONS',
    'ADMIN_SUPERVISOR',
    'SUPERADMIN'
);


ALTER TYPE public."ConversationRole" OWNER TO postgres;

--
-- Name: ConversationScope; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ConversationScope" AS ENUM (
    'CUSTOMER_PUBLIC',
    'CUSTOMER_AUTHENTICATED',
    'ADMIN_INTERNAL'
);


ALTER TYPE public."ConversationScope" OWNER TO postgres;

--
-- Name: ConversationStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ConversationStatus" AS ENUM (
    'OPEN',
    'CLOSED',
    'WAITING_CUSTOMER',
    'WAITING_INTERNAL'
);


ALTER TYPE public."ConversationStatus" OWNER TO postgres;

--
-- Name: ConversationToolCallStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ConversationToolCallStatus" AS ENUM (
    'REQUESTED',
    'VALIDATED',
    'REJECTED',
    'CONFIRMED',
    'EXECUTED',
    'FAILED'
);


ALTER TYPE public."ConversationToolCallStatus" OWNER TO postgres;

--
-- Name: CustomerReauthMethod; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CustomerReauthMethod" AS ENUM (
    'PASSWORD',
    'GOOGLE',
    'OTP'
);


ALTER TYPE public."CustomerReauthMethod" OWNER TO postgres;

--
-- Name: CustomerSecurityEventType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CustomerSecurityEventType" AS ENUM (
    'PASSWORD_RESET_REQUEST',
    'PASSWORD_RESET_COMPLETED',
    'PASSWORD_RESET_FAILED',
    'PASSWORD_CHANGE',
    'PASSWORD_CHANGE_FAILED',
    'OTP_SENT',
    'OTP_VERIFIED',
    'OTP_FAILED',
    'REAUTH_STARTED',
    'REAUTH_COMPLETED',
    'REAUTH_FAILED',
    'SESSION_REVOKED'
);


ALTER TYPE public."CustomerSecurityEventType" OWNER TO postgres;

--
-- Name: DepositRequirementType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DepositRequirementType" AS ENUM (
    'PERCENTAGE',
    'FIXED'
);


ALTER TYPE public."DepositRequirementType" OWNER TO postgres;

--
-- Name: DocumentType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DocumentType" AS ENUM (
    'ORDER',
    'BUDGET'
);


ALTER TYPE public."DocumentType" OWNER TO postgres;

--
-- Name: EmailCategory; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."EmailCategory" AS ENUM (
    'ORDERS',
    'PAYMENTS',
    'AUTH'
);


ALTER TYPE public."EmailCategory" OWNER TO postgres;

--
-- Name: EmailLogStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."EmailLogStatus" AS ENUM (
    'QUEUED',
    'SENT',
    'FAILED',
    'RETRYING'
);


ALTER TYPE public."EmailLogStatus" OWNER TO postgres;

--
-- Name: EmailRecipientType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."EmailRecipientType" AS ENUM (
    'CUSTOMER',
    'ADMIN',
    'SYSTEM'
);


ALTER TYPE public."EmailRecipientType" OWNER TO postgres;

--
-- Name: EmailTemplateVariant; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."EmailTemplateVariant" AS ENUM (
    'CUSTOMER',
    'ADMIN'
);


ALTER TYPE public."EmailTemplateVariant" OWNER TO postgres;

--
-- Name: EventType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."EventType" AS ENUM (
    'MEETING',
    'TASK',
    'WORKSHOP',
    'OTHER'
);


ALTER TYPE public."EventType" OWNER TO postgres;

--
-- Name: InboxChannelType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."InboxChannelType" AS ENUM (
    'EMAIL',
    'WHATSAPP',
    'MESSENGER',
    'INSTAGRAM',
    'SMS',
    'OTHER'
);


ALTER TYPE public."InboxChannelType" OWNER TO postgres;

--
-- Name: InboxMessageDirection; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."InboxMessageDirection" AS ENUM (
    'INBOUND',
    'OUTBOUND'
);


ALTER TYPE public."InboxMessageDirection" OWNER TO postgres;

--
-- Name: InboxMessageEventType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."InboxMessageEventType" AS ENUM (
    'CREATED',
    'FETCHED',
    'FLAG_UPDATED',
    'MOVED',
    'SENT',
    'SYNCED',
    'ERROR'
);


ALTER TYPE public."InboxMessageEventType" OWNER TO postgres;

--
-- Name: InboxQueueAssignmentMode; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."InboxQueueAssignmentMode" AS ENUM (
    'MANUAL',
    'LEAST_LOADED'
);


ALTER TYPE public."InboxQueueAssignmentMode" OWNER TO postgres;

--
-- Name: InstallationChargeScope; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."InstallationChargeScope" AS ENUM (
    'PER_QUOTE',
    'MATCH_PRODUCT_QUANTITY',
    'MATCH_PRODUCT_MEASUREMENTS'
);


ALTER TYPE public."InstallationChargeScope" OWNER TO postgres;

--
-- Name: InstallationPricePresentationMode; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."InstallationPricePresentationMode" AS ENUM (
    'EXACT',
    'FROM_BASE',
    'HIDDEN'
);


ALTER TYPE public."InstallationPricePresentationMode" OWNER TO postgres;

--
-- Name: InstallationResolutionMode; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."InstallationResolutionMode" AS ENUM (
    'INCLUDED',
    'OPTIONAL_ADD_ON',
    'SEPARATE_SERVICE',
    'NOT_OFFERED',
    'UNKNOWN'
);


ALTER TYPE public."InstallationResolutionMode" OWNER TO postgres;

--
-- Name: KnowledgeCandidateStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."KnowledgeCandidateStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public."KnowledgeCandidateStatus" OWNER TO postgres;

--
-- Name: KnowledgeChunkIndexStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."KnowledgeChunkIndexStatus" AS ENUM (
    'PENDING',
    'PROCESSING',
    'COMPLETED',
    'FAILED'
);


ALTER TYPE public."KnowledgeChunkIndexStatus" OWNER TO postgres;

--
-- Name: KnowledgeConversationBundleStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."KnowledgeConversationBundleStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public."KnowledgeConversationBundleStatus" OWNER TO postgres;

--
-- Name: KnowledgeDerivedArtifactStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."KnowledgeDerivedArtifactStatus" AS ENUM (
    'ACTIVE',
    'DISABLED',
    'STALE'
);


ALTER TYPE public."KnowledgeDerivedArtifactStatus" OWNER TO postgres;

--
-- Name: KnowledgeDerivedArtifactType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."KnowledgeDerivedArtifactType" AS ENUM (
    'TOPIC_TAXONOMY',
    'QUOTE_PROFILE_HINTS',
    'MEASUREMENT_CARRIER_TERMS',
    'KEYWORD_LEXICON'
);


ALTER TYPE public."KnowledgeDerivedArtifactType" OWNER TO postgres;

--
-- Name: KnowledgeDocumentScope; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."KnowledgeDocumentScope" AS ENUM (
    'CUSTOMER_PUBLIC',
    'ADMIN_INTERNAL'
);


ALTER TYPE public."KnowledgeDocumentScope" OWNER TO postgres;

--
-- Name: KnowledgeDocumentStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."KnowledgeDocumentStatus" AS ENUM (
    'DRAFT',
    'ACTIVE',
    'ARCHIVED'
);


ALTER TYPE public."KnowledgeDocumentStatus" OWNER TO postgres;

--
-- Name: KnowledgeIngestionRunStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."KnowledgeIngestionRunStatus" AS ENUM (
    'RUNNING',
    'COMPLETED',
    'FAILED'
);


ALTER TYPE public."KnowledgeIngestionRunStatus" OWNER TO postgres;

--
-- Name: KnowledgeNegativeExampleSourceKind; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."KnowledgeNegativeExampleSourceKind" AS ENUM (
    'REJECTED_CANDIDATE',
    'DISCARDED_FEEDBACK',
    'MANUAL'
);


ALTER TYPE public."KnowledgeNegativeExampleSourceKind" OWNER TO postgres;

--
-- Name: KnowledgeNegativeExampleStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."KnowledgeNegativeExampleStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public."KnowledgeNegativeExampleStatus" OWNER TO postgres;

--
-- Name: KnowledgeRawEventStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."KnowledgeRawEventStatus" AS ENUM (
    'NEW',
    'PROCESSED',
    'DISCARDED'
);


ALTER TYPE public."KnowledgeRawEventStatus" OWNER TO postgres;

--
-- Name: KnowledgeSnapshotEntryType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."KnowledgeSnapshotEntryType" AS ENUM (
    'TOPIC_SUMMARY',
    'APPROVED_RULE',
    'APPROVED_RESPONSE_PATTERN',
    'GUARDRAIL_NEGATIVE',
    'KNOWN_GAP',
    'OPERATIONAL_NOTE'
);


ALTER TYPE public."KnowledgeSnapshotEntryType" OWNER TO postgres;

--
-- Name: KnowledgeSnapshotSourceKind; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."KnowledgeSnapshotSourceKind" AS ENUM (
    'KNOWLEDGE_DOCUMENT',
    'KNOWLEDGE_CANDIDATE',
    'KNOWLEDGE_RAW_EVENT',
    'KNOWLEDGE_CONVERSATION_BUNDLE',
    'KNOWLEDGE_NEGATIVE_EXAMPLE',
    'KNOWLEDGE_FEEDBACK'
);


ALTER TYPE public."KnowledgeSnapshotSourceKind" OWNER TO postgres;

--
-- Name: KnowledgeSnapshotSourceRole; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."KnowledgeSnapshotSourceRole" AS ENUM (
    'PRIMARY_SUPPORT',
    'SECONDARY_SUPPORT',
    'GUARDRAIL',
    'COUNTEREXAMPLE',
    'PENDING_SIGNAL'
);


ALTER TYPE public."KnowledgeSnapshotSourceRole" OWNER TO postgres;

--
-- Name: KnowledgeSnapshotStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."KnowledgeSnapshotStatus" AS ENUM (
    'BUILDING',
    'READY',
    'FAILED',
    'STALE'
);


ALTER TYPE public."KnowledgeSnapshotStatus" OWNER TO postgres;

--
-- Name: KnowledgeSourceType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."KnowledgeSourceType" AS ENUM (
    'DOCS',
    'WEB_URL',
    'BACKEND_DATASET',
    'ADMIN_CURATED',
    'CONVERSATION_DERIVED'
);


ALTER TYPE public."KnowledgeSourceType" OWNER TO postgres;

--
-- Name: KnowledgeSuggestionFeedbackOutcome; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."KnowledgeSuggestionFeedbackOutcome" AS ENUM (
    'USED',
    'EDITED',
    'DISCARDED'
);


ALTER TYPE public."KnowledgeSuggestionFeedbackOutcome" OWNER TO postgres;

--
-- Name: NotificationAudience; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."NotificationAudience" AS ENUM (
    'CUSTOMER',
    'ADMIN'
);


ALTER TYPE public."NotificationAudience" OWNER TO postgres;

--
-- Name: NotificationChannel; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."NotificationChannel" AS ENUM (
    'IN_APP',
    'EMAIL',
    'PUSH'
);


ALTER TYPE public."NotificationChannel" OWNER TO postgres;

--
-- Name: NotificationDeliveryStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."NotificationDeliveryStatus" AS ENUM (
    'PENDING',
    'SENT',
    'FAILED'
);


ALTER TYPE public."NotificationDeliveryStatus" OWNER TO postgres;

--
-- Name: NotificationEventType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."NotificationEventType" AS ENUM (
    'ORDER_RECEIVED',
    'PAYMENT_RECEIVED',
    'ORDER_STATUS_CHANGED'
);


ALTER TYPE public."NotificationEventType" OWNER TO postgres;

--
-- Name: OtpCodeType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."OtpCodeType" AS ENUM (
    'VERIFICATION',
    'RECOVERY'
);


ALTER TYPE public."OtpCodeType" OWNER TO postgres;

--
-- Name: PasswordResetChannel; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PasswordResetChannel" AS ENUM (
    'EMAIL',
    'PHONE',
    'GOOGLE'
);


ALTER TYPE public."PasswordResetChannel" OWNER TO postgres;

--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'REGISTERED',
    'CONFIRMED',
    'FAILED'
);


ALTER TYPE public."PaymentStatus" OWNER TO postgres;

--
-- Name: PaymentType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PaymentType" AS ENUM (
    'DEPOSIT',
    'BALANCE',
    'REFUND'
);


ALTER TYPE public."PaymentType" OWNER TO postgres;

--
-- Name: ProductAttributeType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ProductAttributeType" AS ENUM (
    'COLOR',
    'SIZE',
    'MATERIAL'
);


ALTER TYPE public."ProductAttributeType" OWNER TO postgres;

--
-- Name: ProductMode; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ProductMode" AS ENUM (
    'SIMPLE',
    'VARIABLE',
    'PARAMETRIC'
);


ALTER TYPE public."ProductMode" OWNER TO postgres;

--
-- Name: ProductRelationType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ProductRelationType" AS ENUM (
    'RELATED',
    'FREQUENTLY_BOUGHT_TOGETHER',
    'SUGGESTED_ADD_ON',
    'INSTALLATION_ADD_ON'
);


ALTER TYPE public."ProductRelationType" OWNER TO postgres;

--
-- Name: ProductReviewStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ProductReviewStatus" AS ENUM (
    'PUBLISHED',
    'HIDDEN'
);


ALTER TYPE public."ProductReviewStatus" OWNER TO postgres;

--
-- Name: ProductType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ProductType" AS ENUM (
    'PHYSICAL',
    'SERVICE'
);


ALTER TYPE public."ProductType" OWNER TO postgres;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Role" AS ENUM (
    'SUPERADMIN',
    'ADMIN',
    'USER',
    'OPS',
    'SALES',
    'FINANCE'
);


ALTER TYPE public."Role" OWNER TO postgres;

--
-- Name: SalesUnit; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SalesUnit" AS ENUM (
    'UNIT',
    'SQUARE_METER',
    'LINEAR_METER'
);


ALTER TYPE public."SalesUnit" OWNER TO postgres;

--
-- Name: SecurityEventType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SecurityEventType" AS ENUM (
    'OTP_SENT',
    'OTP_VERIFIED',
    'OTP_FAILED',
    'ACCOUNT_REGISTERED',
    'PASSWORD_RESET_REQUESTED',
    'PASSWORD_RESET_COMPLETED',
    'PROVIDER_FAILURE'
);


ALTER TYPE public."SecurityEventType" OWNER TO postgres;

--
-- Name: UserActivityType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."UserActivityType" AS ENUM (
    'LOGIN',
    'PASSWORD_CHANGE',
    'DEVICE_SIGN_IN',
    'PROFILE_UPDATE',
    'SECURITY_ALERT'
);


ALTER TYPE public."UserActivityType" OWNER TO postgres;

--
-- Name: UserCapability; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."UserCapability" AS ENUM (
    'CONVERSATIONS_MANAGE',
    'CUSTOMERS_MANAGE',
    'APPOINTMENTS_MANAGE',
    'CATALOG_MANAGE',
    'ORDERS_MANAGE',
    'QUOTES_MANAGE',
    'PAYMENTS_MANAGE',
    'ABERTURAS_QUOTE',
    'ABERTURAS_REGISTER',
    'KNOWLEDGE_MANAGE',
    'AI_SETTINGS_MANAGE',
    'USERS_MANAGE'
);


ALTER TYPE public."UserCapability" OWNER TO postgres;

--
-- Name: UserCapabilityGroup; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."UserCapabilityGroup" AS ENUM (
    'SUPPORT',
    'SALES',
    'OPERATIONS',
    'FINANCE',
    'PLATFORM_ADMIN'
);


ALTER TYPE public."UserCapabilityGroup" OWNER TO postgres;

--
-- Name: UserStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."UserStatus" AS ENUM (
    'PENDING_VERIFICATION',
    'ACTIVE',
    'BLOCKED'
);


ALTER TYPE public."UserStatus" OWNER TO postgres;

--
-- Name: WorkOrderStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."WorkOrderStatus" AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'READY',
    'DELIVERED',
    'CLOSED',
    'CANCELED'
);


ALTER TYPE public."WorkOrderStatus" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ActivityColumn; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ActivityColumn" (
    id integer NOT NULL,
    title text NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ActivityColumn" OWNER TO postgres;

--
-- Name: ActivityColumn_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ActivityColumn_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ActivityColumn_id_seq" OWNER TO postgres;

--
-- Name: ActivityColumn_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ActivityColumn_id_seq" OWNED BY public."ActivityColumn".id;


--
-- Name: ActivityTicket; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ActivityTicket" (
    id integer NOT NULL,
    "columnId" integer NOT NULL,
    name text NOT NULL,
    description text,
    priority text DEFAULT 'Medium priority'::text,
    labels text[] DEFAULT ARRAY[]::text[],
    "dueDate" timestamp(3) without time zone,
    "order" integer DEFAULT 0 NOT NULL,
    cover text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ActivityTicket" OWNER TO postgres;

--
-- Name: ActivityTicketMember; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ActivityTicketMember" (
    "ticketId" integer NOT NULL,
    "userId" integer NOT NULL
);


ALTER TABLE public."ActivityTicketMember" OWNER TO postgres;

--
-- Name: ActivityTicket_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ActivityTicket_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ActivityTicket_id_seq" OWNER TO postgres;

--
-- Name: ActivityTicket_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ActivityTicket_id_seq" OWNED BY public."ActivityTicket".id;


--
-- Name: CalendarEvent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CalendarEvent" (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    type public."EventType" DEFAULT 'OTHER'::public."EventType" NOT NULL,
    "startAt" timestamp(3) without time zone NOT NULL,
    "endAt" timestamp(3) without time zone,
    "allDay" boolean DEFAULT false NOT NULL,
    location text,
    color character varying(32),
    metadata jsonb,
    "createdById" integer,
    "projectId" integer,
    "taskId" integer,
    "eventTypeId" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CalendarEvent" OWNER TO postgres;

--
-- Name: CalendarEventAttachment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CalendarEventAttachment" (
    id integer NOT NULL,
    "eventId" integer NOT NULL,
    name text NOT NULL,
    "mimeType" text,
    size integer,
    content bytea NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."CalendarEventAttachment" OWNER TO postgres;

--
-- Name: CalendarEventAttachment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CalendarEventAttachment_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CalendarEventAttachment_id_seq" OWNER TO postgres;

--
-- Name: CalendarEventAttachment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CalendarEventAttachment_id_seq" OWNED BY public."CalendarEventAttachment".id;


--
-- Name: CalendarEventComment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CalendarEventComment" (
    id integer NOT NULL,
    "eventId" integer NOT NULL,
    "userId" integer,
    message text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."CalendarEventComment" OWNER TO postgres;

--
-- Name: CalendarEventComment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CalendarEventComment_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CalendarEventComment_id_seq" OWNER TO postgres;

--
-- Name: CalendarEventComment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CalendarEventComment_id_seq" OWNED BY public."CalendarEventComment".id;


--
-- Name: CalendarEventType; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CalendarEventType" (
    id integer NOT NULL,
    name text NOT NULL,
    color text DEFAULT '#2563eb'::text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CalendarEventType" OWNER TO postgres;

--
-- Name: CalendarEventType_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CalendarEventType_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CalendarEventType_id_seq" OWNER TO postgres;

--
-- Name: CalendarEventType_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CalendarEventType_id_seq" OWNED BY public."CalendarEventType".id;


--
-- Name: CalendarEvent_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CalendarEvent_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CalendarEvent_id_seq" OWNER TO postgres;

--
-- Name: CalendarEvent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CalendarEvent_id_seq" OWNED BY public."CalendarEvent".id;


--
-- Name: CanonicalConfiguration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CanonicalConfiguration" (
    id integer NOT NULL,
    "tenantId" text DEFAULT 'global'::text NOT NULL,
    "baseProductId" integer NOT NULL,
    "configurationRules" jsonb NOT NULL,
    "canonicalName" text NOT NULL,
    "baseLabel" text,
    slug text NOT NULL,
    indexable boolean DEFAULT true NOT NULL,
    "seoTitle" text,
    "seoDescription" text,
    "searchTerms" text[] DEFAULT ARRAY[]::text[] NOT NULL,
    "visibilityRules" jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."CanonicalConfiguration" OWNER TO postgres;

--
-- Name: CanonicalConfiguration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CanonicalConfiguration_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CanonicalConfiguration_id_seq" OWNER TO postgres;

--
-- Name: CanonicalConfiguration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CanonicalConfiguration_id_seq" OWNED BY public."CanonicalConfiguration".id;


--
-- Name: CmsEntry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CmsEntry" (
    id integer NOT NULL,
    "sectionId" integer NOT NULL,
    slug text,
    title text NOT NULL,
    subtitle text,
    description text,
    payload jsonb,
    locale text DEFAULT 'es'::text NOT NULL,
    status public."CmsEntryStatus" DEFAULT 'DRAFT'::public."CmsEntryStatus" NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "publishedAt" timestamp(3) without time zone,
    "startsAt" timestamp(3) without time zone,
    "endsAt" timestamp(3) without time zone,
    "thumbnailUrl" text,
    "ctaLabel" text,
    "ctaUrl" text,
    "productId" integer,
    "categoryId" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CmsEntry" OWNER TO postgres;

--
-- Name: CmsEntryAsset; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CmsEntryAsset" (
    id integer NOT NULL,
    "entryId" integer NOT NULL,
    title text,
    caption text,
    "mediaType" public."CmsEntryAssetType" DEFAULT 'IMAGE'::public."CmsEntryAssetType" NOT NULL,
    "mediaUrl" text NOT NULL,
    "posterUrl" text,
    "externalUrl" text,
    "durationSec" integer,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CmsEntryAsset" OWNER TO postgres;

--
-- Name: CmsEntryAsset_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CmsEntryAsset_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CmsEntryAsset_id_seq" OWNER TO postgres;

--
-- Name: CmsEntryAsset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CmsEntryAsset_id_seq" OWNED BY public."CmsEntryAsset".id;


--
-- Name: CmsEntry_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CmsEntry_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CmsEntry_id_seq" OWNER TO postgres;

--
-- Name: CmsEntry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CmsEntry_id_seq" OWNED BY public."CmsEntry".id;


--
-- Name: CmsMedia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CmsMedia" (
    id integer NOT NULL,
    url text NOT NULL,
    type public."CmsMediaType" DEFAULT 'IMAGE'::public."CmsMediaType" NOT NULL,
    alt text,
    title text,
    "mimeType" text,
    "fileName" text,
    "sizeBytes" integer,
    width integer,
    height integer,
    source text,
    metadata jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CmsMedia" OWNER TO postgres;

--
-- Name: CmsMedia_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CmsMedia_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CmsMedia_id_seq" OWNER TO postgres;

--
-- Name: CmsMedia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CmsMedia_id_seq" OWNED BY public."CmsMedia".id;


--
-- Name: CmsPage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CmsPage" (
    id integer NOT NULL,
    path text NOT NULL,
    title text NOT NULL,
    summary text,
    scope public."CmsPageScope" DEFAULT 'GENERAL_SITE'::public."CmsPageScope" NOT NULL,
    locale text DEFAULT 'es'::text NOT NULL,
    status public."CmsEntryStatus" DEFAULT 'DRAFT'::public."CmsEntryStatus" NOT NULL,
    visible boolean DEFAULT true NOT NULL,
    "seoTitle" text,
    "seoDescription" text,
    "seoImageUrl" text,
    "layoutKey" text,
    "legacySource" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CmsPage" OWNER TO postgres;

--
-- Name: CmsPageAlias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CmsPageAlias" (
    id integer NOT NULL,
    "pageId" integer NOT NULL,
    path text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CmsPageAlias" OWNER TO postgres;

--
-- Name: CmsPageAlias_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CmsPageAlias_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CmsPageAlias_id_seq" OWNER TO postgres;

--
-- Name: CmsPageAlias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CmsPageAlias_id_seq" OWNED BY public."CmsPageAlias".id;


--
-- Name: CmsPageBlock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CmsPageBlock" (
    id integer NOT NULL,
    "sectionId" integer NOT NULL,
    type public."CmsPageBlockType" NOT NULL,
    key text,
    name text,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    visible boolean DEFAULT true NOT NULL,
    content jsonb,
    "mediaId" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CmsPageBlock" OWNER TO postgres;

--
-- Name: CmsPageBlock_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CmsPageBlock_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CmsPageBlock_id_seq" OWNER TO postgres;

--
-- Name: CmsPageBlock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CmsPageBlock_id_seq" OWNED BY public."CmsPageBlock".id;


--
-- Name: CmsPageSection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CmsPageSection" (
    id integer NOT NULL,
    "pageId" integer NOT NULL,
    type public."CmsPageSectionType" NOT NULL,
    key text,
    name text,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    visible boolean DEFAULT true NOT NULL,
    settings jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CmsPageSection" OWNER TO postgres;

--
-- Name: CmsPageSection_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CmsPageSection_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CmsPageSection_id_seq" OWNER TO postgres;

--
-- Name: CmsPageSection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CmsPageSection_id_seq" OWNED BY public."CmsPageSection".id;


--
-- Name: CmsPage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CmsPage_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CmsPage_id_seq" OWNER TO postgres;

--
-- Name: CmsPage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CmsPage_id_seq" OWNED BY public."CmsPage".id;


--
-- Name: CmsSection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CmsSection" (
    id integer NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CmsSection" OWNER TO postgres;

--
-- Name: CmsSection_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CmsSection_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CmsSection_id_seq" OWNER TO postgres;

--
-- Name: CmsSection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CmsSection_id_seq" OWNED BY public."CmsSection".id;


--
-- Name: CompanyProfile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CompanyProfile" (
    id integer NOT NULL,
    singleton text DEFAULT 'default'::text NOT NULL,
    "legalName" text NOT NULL,
    "tradeName" text NOT NULL,
    "taxId" text,
    email text,
    phone text,
    website text,
    "addressLine1" text,
    "addressLine2" text,
    "seoDescription" text,
    "seoAuthor" text,
    "seoImageUrl" text,
    "googleSiteVerification" text,
    logo bytea,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CompanyProfile" OWNER TO postgres;

--
-- Name: CompanyProfile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CompanyProfile_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CompanyProfile_id_seq" OWNER TO postgres;

--
-- Name: CompanyProfile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CompanyProfile_id_seq" OWNED BY public."CompanyProfile".id;


--
-- Name: Conversation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Conversation" (
    id text NOT NULL,
    "tenantKey" text NOT NULL,
    scope public."ConversationScope" NOT NULL,
    "conversationRole" public."ConversationRole" DEFAULT 'CUSTOMER_PUBLIC'::public."ConversationRole" NOT NULL,
    channel public."ConversationChannel" NOT NULL,
    status public."ConversationStatus" DEFAULT 'OPEN'::public."ConversationStatus" NOT NULL,
    "controlMode" public."ConversationControlMode" DEFAULT 'AI'::public."ConversationControlMode" NOT NULL,
    "needsHuman" boolean DEFAULT false NOT NULL,
    subject text,
    "customerId" integer,
    "assignedToUserId" integer,
    "inboxAccountId" text,
    "externalUserId" text,
    "externalThreadId" text,
    "externalChannelRef" text,
    metadata jsonb,
    "pinnedAt" timestamp(3) without time zone,
    "lastMessageAt" timestamp(3) without time zone,
    "lastInboundAt" timestamp(3) without time zone,
    "lastOutboundAt" timestamp(3) without time zone,
    "closedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Conversation" OWNER TO postgres;

--
-- Name: ConversationExternalIdentity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ConversationExternalIdentity" (
    id text NOT NULL,
    "conversationId" text NOT NULL,
    "tenantKey" text NOT NULL,
    channel public."ConversationChannel" NOT NULL,
    kind public."ConversationExternalIdentityKind" NOT NULL,
    value text NOT NULL,
    "normalizedValue" text NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ConversationExternalIdentity" OWNER TO postgres;

--
-- Name: ConversationHandoffEvent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ConversationHandoffEvent" (
    id text NOT NULL,
    "conversationId" text NOT NULL,
    type public."ConversationHandoffEventType" NOT NULL,
    "actorUserId" integer,
    "previousMode" public."ConversationControlMode",
    "nextMode" public."ConversationControlMode",
    notes text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ConversationHandoffEvent" OWNER TO postgres;

--
-- Name: ConversationMessage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ConversationMessage" (
    id text NOT NULL,
    "conversationId" text NOT NULL,
    "authorType" public."ConversationMessageAuthorType" NOT NULL,
    kind public."ConversationMessageKind" DEFAULT 'TEXT'::public."ConversationMessageKind" NOT NULL,
    "authorUserId" integer,
    "authorCustomerId" integer,
    "externalMessageId" text,
    "inboxMessageId" text,
    body text,
    "normalizedText" text,
    payload jsonb,
    metadata jsonb,
    "sentAt" timestamp(3) without time zone,
    "receivedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ConversationMessage" OWNER TO postgres;

--
-- Name: ConversationParticipant; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ConversationParticipant" (
    id text NOT NULL,
    "conversationId" text NOT NULL,
    role public."ConversationParticipantRole" NOT NULL,
    "userId" integer,
    "customerId" integer,
    "externalUserId" text,
    "displayName" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ConversationParticipant" OWNER TO postgres;

--
-- Name: ConversationReadState; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ConversationReadState" (
    "conversationId" text NOT NULL,
    "userId" integer NOT NULL,
    "lastReadAt" timestamp(3) without time zone,
    "manualUnread" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ConversationReadState" OWNER TO postgres;

--
-- Name: ConversationToolCall; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ConversationToolCall" (
    id text NOT NULL,
    "conversationId" text NOT NULL,
    "messageId" text,
    "toolName" text NOT NULL,
    status public."ConversationToolCallStatus" DEFAULT 'REQUESTED'::public."ConversationToolCallStatus" NOT NULL,
    "requestedBy" public."ConversationMessageAuthorType" NOT NULL,
    "requestedByUserId" integer,
    "validatedPayload" jsonb,
    "resultPayload" jsonb,
    "errorCode" text,
    "errorMessage" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ConversationToolCall" OWNER TO postgres;

--
-- Name: CurrencyRate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CurrencyRate" (
    id integer NOT NULL,
    base text NOT NULL,
    quote text NOT NULL,
    rate numeric(18,8) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CurrencyRate" OWNER TO postgres;

--
-- Name: CurrencyRate_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CurrencyRate_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CurrencyRate_id_seq" OWNER TO postgres;

--
-- Name: CurrencyRate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CurrencyRate_id_seq" OWNED BY public."CurrencyRate".id;


--
-- Name: Customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Customer" (
    id integer NOT NULL,
    name text NOT NULL,
    "firstName" text,
    "lastName" text,
    email text,
    "emailVerifiedAt" timestamp(3) without time zone,
    img text,
    location text,
    title text,
    "phoneNumber" text,
    "passwordHash" text,
    "storefrontDefaultPasswordHash" text,
    "passwordAlgorithm" text DEFAULT 'bcrypt'::text,
    "passwordAlgVersion" integer DEFAULT 12,
    "passwordUpdatedAt" timestamp(3) without time zone,
    "storefrontSessionVersion" integer DEFAULT 1 NOT NULL,
    birthday timestamp(3) without time zone,
    facebook text,
    twitter text,
    pinterest text,
    "linkedIn" text,
    "preferredLocale" text DEFAULT 'es'::text NOT NULL,
    "preferredCurrency" text DEFAULT 'UYU'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "statusId" integer
);


ALTER TABLE public."Customer" OWNER TO postgres;

--
-- Name: CustomerAddress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CustomerAddress" (
    id integer NOT NULL,
    "customerId" integer NOT NULL,
    street text NOT NULL,
    number text NOT NULL,
    corner text,
    apartment text,
    department text,
    city text NOT NULL,
    neighborhood text,
    country text NOT NULL,
    comments text,
    label text,
    "isPrimary" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CustomerAddress" OWNER TO postgres;

--
-- Name: CustomerAddress_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CustomerAddress_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CustomerAddress_id_seq" OWNER TO postgres;

--
-- Name: CustomerAddress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CustomerAddress_id_seq" OWNED BY public."CustomerAddress".id;


--
-- Name: CustomerEmailVerificationToken; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CustomerEmailVerificationToken" (
    id integer NOT NULL,
    "customerId" integer NOT NULL,
    "tokenHash" text NOT NULL,
    "emailSnapshot" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone,
    "ipAddress" text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CustomerEmailVerificationToken" OWNER TO postgres;

--
-- Name: CustomerEmailVerificationToken_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CustomerEmailVerificationToken_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CustomerEmailVerificationToken_id_seq" OWNER TO postgres;

--
-- Name: CustomerEmailVerificationToken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CustomerEmailVerificationToken_id_seq" OWNED BY public."CustomerEmailVerificationToken".id;


--
-- Name: CustomerOAuthAccount; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CustomerOAuthAccount" (
    id integer NOT NULL,
    "customerId" integer NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    email text,
    name text,
    "givenName" text,
    "familyName" text,
    picture text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "lastLoginAt" timestamp(3) without time zone
);


ALTER TABLE public."CustomerOAuthAccount" OWNER TO postgres;

--
-- Name: CustomerOAuthAccount_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CustomerOAuthAccount_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CustomerOAuthAccount_id_seq" OWNER TO postgres;

--
-- Name: CustomerOAuthAccount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CustomerOAuthAccount_id_seq" OWNED BY public."CustomerOAuthAccount".id;


--
-- Name: CustomerOtpChallenge; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CustomerOtpChallenge" (
    id integer NOT NULL,
    "customerId" integer NOT NULL,
    phone text NOT NULL,
    "otpHash" text NOT NULL,
    "otpLength" integer DEFAULT 6 NOT NULL,
    "attemptCount" integer DEFAULT 0 NOT NULL,
    "maxAttempts" integer DEFAULT 5 NOT NULL,
    channel text,
    "ipAddress" text,
    "userAgent" text,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "lastAttemptAt" timestamp(3) without time zone,
    "consumedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CustomerOtpChallenge" OWNER TO postgres;

--
-- Name: CustomerOtpChallenge_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CustomerOtpChallenge_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CustomerOtpChallenge_id_seq" OWNER TO postgres;

--
-- Name: CustomerOtpChallenge_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CustomerOtpChallenge_id_seq" OWNED BY public."CustomerOtpChallenge".id;


--
-- Name: CustomerPhone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CustomerPhone" (
    id integer NOT NULL,
    "customerId" integer NOT NULL,
    phone text NOT NULL,
    label text,
    "isPrimary" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."CustomerPhone" OWNER TO postgres;

--
-- Name: CustomerPhone_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CustomerPhone_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CustomerPhone_id_seq" OWNER TO postgres;

--
-- Name: CustomerPhone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CustomerPhone_id_seq" OWNED BY public."CustomerPhone".id;


--
-- Name: CustomerReauthToken; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CustomerReauthToken" (
    id integer NOT NULL,
    "customerId" integer NOT NULL,
    "tokenHash" text NOT NULL,
    method public."CustomerReauthMethod" NOT NULL,
    factors jsonb,
    "ipAddress" text,
    "userAgent" text,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."CustomerReauthToken" OWNER TO postgres;

--
-- Name: CustomerReauthToken_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CustomerReauthToken_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CustomerReauthToken_id_seq" OWNER TO postgres;

--
-- Name: CustomerReauthToken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CustomerReauthToken_id_seq" OWNED BY public."CustomerReauthToken".id;


--
-- Name: CustomerSecurityEvent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CustomerSecurityEvent" (
    id integer NOT NULL,
    "customerId" integer,
    "eventType" public."CustomerSecurityEventType" NOT NULL,
    channel text,
    "ipAddress" text,
    "userAgent" text,
    "deviceId" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."CustomerSecurityEvent" OWNER TO postgres;

--
-- Name: CustomerSecurityEvent_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CustomerSecurityEvent_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CustomerSecurityEvent_id_seq" OWNER TO postgres;

--
-- Name: CustomerSecurityEvent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CustomerSecurityEvent_id_seq" OWNED BY public."CustomerSecurityEvent".id;


--
-- Name: CustomerStatus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CustomerStatus" (
    id integer NOT NULL,
    name text NOT NULL,
    color text
);


ALTER TABLE public."CustomerStatus" OWNER TO postgres;

--
-- Name: CustomerStatus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CustomerStatus_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CustomerStatus_id_seq" OWNER TO postgres;

--
-- Name: CustomerStatus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CustomerStatus_id_seq" OWNED BY public."CustomerStatus".id;


--
-- Name: Customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Customer_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Customer_id_seq" OWNER TO postgres;

--
-- Name: Customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Customer_id_seq" OWNED BY public."Customer".id;


--
-- Name: EmailLog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EmailLog" (
    id integer NOT NULL,
    category public."EmailCategory" NOT NULL,
    "templateId" integer,
    locale text NOT NULL,
    "recipientType" public."EmailRecipientType" NOT NULL,
    "toAddress" text NOT NULL,
    "ccAddresses" text[] DEFAULT ARRAY[]::text[],
    "bccAddresses" text[] DEFAULT ARRAY[]::text[],
    subject text NOT NULL,
    payload jsonb NOT NULL,
    "payloadHash" text NOT NULL,
    status public."EmailLogStatus" DEFAULT 'QUEUED'::public."EmailLogStatus" NOT NULL,
    "providerMessageId" text,
    "errorMessage" text,
    attempts integer DEFAULT 0 NOT NULL,
    "lastAttemptAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."EmailLog" OWNER TO postgres;

--
-- Name: EmailLog_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EmailLog_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."EmailLog_id_seq" OWNER TO postgres;

--
-- Name: EmailLog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EmailLog_id_seq" OWNED BY public."EmailLog".id;


--
-- Name: EmailSetting; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EmailSetting" (
    id integer NOT NULL,
    category public."EmailCategory" NOT NULL,
    "fromAddress" text NOT NULL,
    "fromName" text,
    "adminRecipients" text[] DEFAULT ARRAY[]::text[],
    cc text[] DEFAULT ARRAY[]::text[],
    bcc text[] DEFAULT ARRAY[]::text[],
    enabled boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."EmailSetting" OWNER TO postgres;

--
-- Name: EmailSetting_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EmailSetting_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."EmailSetting_id_seq" OWNER TO postgres;

--
-- Name: EmailSetting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EmailSetting_id_seq" OWNED BY public."EmailSetting".id;


--
-- Name: EmailTemplate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EmailTemplate" (
    id integer NOT NULL,
    category public."EmailCategory" NOT NULL,
    locale text DEFAULT 'en'::text NOT NULL,
    variant public."EmailTemplateVariant" NOT NULL,
    subject text NOT NULL,
    body text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."EmailTemplate" OWNER TO postgres;

--
-- Name: EmailTemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EmailTemplate_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."EmailTemplate_id_seq" OWNER TO postgres;

--
-- Name: EmailTemplate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EmailTemplate_id_seq" OWNED BY public."EmailTemplate".id;


--
-- Name: Expense; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Expense" (
    id integer NOT NULL,
    title text NOT NULL,
    name text,
    description text,
    amount numeric(18,2) DEFAULT 0 NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    currency character varying(8),
    "categoryId" integer,
    "statusId" integer,
    "paymentMethodId" integer,
    "paymentReference" text,
    "taxCreditEligible" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Expense" OWNER TO postgres;

--
-- Name: ExpenseAttachment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ExpenseAttachment" (
    id integer NOT NULL,
    "expenseId" integer NOT NULL,
    name text NOT NULL,
    "mimeType" text,
    size integer,
    content bytea NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ExpenseAttachment" OWNER TO postgres;

--
-- Name: ExpenseAttachment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ExpenseAttachment_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ExpenseAttachment_id_seq" OWNER TO postgres;

--
-- Name: ExpenseAttachment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ExpenseAttachment_id_seq" OWNED BY public."ExpenseAttachment".id;


--
-- Name: ExpenseCategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ExpenseCategory" (
    id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."ExpenseCategory" OWNER TO postgres;

--
-- Name: ExpenseCategory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ExpenseCategory_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ExpenseCategory_id_seq" OWNER TO postgres;

--
-- Name: ExpenseCategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ExpenseCategory_id_seq" OWNED BY public."ExpenseCategory".id;


--
-- Name: ExpenseStatus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ExpenseStatus" (
    id integer NOT NULL,
    name text NOT NULL,
    color text
);


ALTER TABLE public."ExpenseStatus" OWNER TO postgres;

--
-- Name: ExpenseStatus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ExpenseStatus_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ExpenseStatus_id_seq" OWNER TO postgres;

--
-- Name: ExpenseStatus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ExpenseStatus_id_seq" OWNED BY public."ExpenseStatus".id;


--
-- Name: Expense_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Expense_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Expense_id_seq" OWNER TO postgres;

--
-- Name: Expense_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Expense_id_seq" OWNED BY public."Expense".id;


--
-- Name: InboxAccount; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."InboxAccount" (
    id text NOT NULL,
    "displayName" text,
    address text,
    channel public."InboxChannelType" NOT NULL,
    active boolean DEFAULT true NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."InboxAccount" OWNER TO postgres;

--
-- Name: InboxAttachment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."InboxAttachment" (
    id text NOT NULL,
    "messageId" text NOT NULL,
    "remoteId" text,
    "fileName" text,
    "contentType" text,
    size integer,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."InboxAttachment" OWNER TO postgres;

--
-- Name: InboxMessage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."InboxMessage" (
    id text NOT NULL,
    "accountId" text NOT NULL,
    channel public."InboxChannelType" NOT NULL,
    provider text DEFAULT 'generic'::text NOT NULL,
    "messageUid" text NOT NULL,
    "remoteId" text NOT NULL,
    "threadRemoteId" text,
    subject text,
    snippet text,
    "previewText" text,
    "fromAddress" text,
    "fromName" text,
    "toAddresses" text[],
    "ccAddresses" text[],
    "bccAddresses" text[],
    "replyToAddresses" text[],
    direction public."InboxMessageDirection" NOT NULL,
    folder text,
    "queueId" text,
    "isRead" boolean DEFAULT false NOT NULL,
    "isStarred" boolean DEFAULT false NOT NULL,
    "isSpam" boolean DEFAULT false NOT NULL,
    "hasAttachments" boolean DEFAULT false NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "receivedAt" timestamp(3) without time zone,
    "bodyHash" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."InboxMessage" OWNER TO postgres;

--
-- Name: InboxMessageEvent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."InboxMessageEvent" (
    id integer NOT NULL,
    "messageId" text NOT NULL,
    type public."InboxMessageEventType" NOT NULL,
    payload jsonb,
    "occurredAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."InboxMessageEvent" OWNER TO postgres;

--
-- Name: InboxMessageEvent_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."InboxMessageEvent_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."InboxMessageEvent_id_seq" OWNER TO postgres;

--
-- Name: InboxMessageEvent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."InboxMessageEvent_id_seq" OWNED BY public."InboxMessageEvent".id;


--
-- Name: InboxQueue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."InboxQueue" (
    id text NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    description text,
    rules jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    priority integer DEFAULT 100 NOT NULL,
    "slaTargetMinutes" integer DEFAULT 30 NOT NULL,
    "maxAssignedConversations" integer,
    "assignmentMode" public."InboxQueueAssignmentMode" DEFAULT 'MANUAL'::public."InboxQueueAssignmentMode" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."InboxQueue" OWNER TO postgres;

--
-- Name: InboxQueueUserAssignment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."InboxQueueUserAssignment" (
    id text NOT NULL,
    "queueId" text NOT NULL,
    "userId" integer NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "isPrimary" boolean DEFAULT false NOT NULL,
    "maxOpenConversations" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."InboxQueueUserAssignment" OWNER TO postgres;

--
-- Name: InboxSyncState; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."InboxSyncState" (
    id text NOT NULL,
    "accountId" text NOT NULL,
    channel public."InboxChannelType" NOT NULL,
    folder text NOT NULL,
    "lastRemoteId" text,
    "lastSyncAt" timestamp(3) without time zone,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."InboxSyncState" OWNER TO postgres;

--
-- Name: KnowledgeCandidate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."KnowledgeCandidate" (
    id text NOT NULL,
    "tenantKey" text NOT NULL,
    scope public."KnowledgeDocumentScope" NOT NULL,
    "sourceType" public."KnowledgeSourceType" DEFAULT 'CONVERSATION_DERIVED'::public."KnowledgeSourceType" NOT NULL,
    status public."KnowledgeCandidateStatus" DEFAULT 'PENDING'::public."KnowledgeCandidateStatus" NOT NULL,
    "observationId" text,
    title text NOT NULL,
    excerpt text NOT NULL,
    "redactedExcerpt" text,
    summary text,
    "detectedIntent" text,
    problem text,
    "contextSummary" text,
    "suggestedResponse" text,
    "approvedResponse" text,
    confidence double precision,
    "dedupeHash" text,
    "clusterKey" text,
    version integer DEFAULT 1 NOT NULL,
    "piiDetected" boolean DEFAULT false NOT NULL,
    metadata jsonb,
    "conversationId" text,
    "messageId" text,
    "createdByUserId" integer,
    "reviewedByUserId" integer,
    "reviewedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."KnowledgeCandidate" OWNER TO postgres;

--
-- Name: KnowledgeConversationBundle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."KnowledgeConversationBundle" (
    id text NOT NULL,
    "tenantKey" text NOT NULL,
    scope public."KnowledgeDocumentScope" NOT NULL,
    status public."KnowledgeConversationBundleStatus" DEFAULT 'PENDING'::public."KnowledgeConversationBundleStatus" NOT NULL,
    "conversationId" text NOT NULL,
    title text NOT NULL,
    summary text,
    "detectedIntents" text[] DEFAULT ARRAY[]::text[],
    "eventCount" integer DEFAULT 0 NOT NULL,
    "candidateCount" integer DEFAULT 0 NOT NULL,
    "approvedCount" integer DEFAULT 0 NOT NULL,
    "pendingCount" integer DEFAULT 0 NOT NULL,
    "previewQuestion" text,
    "previewResponse" text,
    metadata jsonb,
    "createdByUserId" integer,
    "reviewedByUserId" integer,
    "reviewedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."KnowledgeConversationBundle" OWNER TO postgres;

--
-- Name: KnowledgeDerivedArtifact; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."KnowledgeDerivedArtifact" (
    id text NOT NULL,
    "tenantKey" text NOT NULL,
    scope public."KnowledgeDocumentScope" NOT NULL,
    type public."KnowledgeDerivedArtifactType" NOT NULL,
    status public."KnowledgeDerivedArtifactStatus" DEFAULT 'ACTIVE'::public."KnowledgeDerivedArtifactStatus" NOT NULL,
    "sourceDocumentId" text NOT NULL,
    content jsonb NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."KnowledgeDerivedArtifact" OWNER TO postgres;

--
-- Name: KnowledgeDocument; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."KnowledgeDocument" (
    id text NOT NULL,
    "tenantKey" text NOT NULL,
    scope public."KnowledgeDocumentScope" NOT NULL,
    "sourceType" public."KnowledgeSourceType" NOT NULL,
    status public."KnowledgeDocumentStatus" DEFAULT 'ACTIVE'::public."KnowledgeDocumentStatus" NOT NULL,
    "chunkIndexStatus" public."KnowledgeChunkIndexStatus" DEFAULT 'PENDING'::public."KnowledgeChunkIndexStatus" NOT NULL,
    "chunkIndexVersion" integer DEFAULT 1 NOT NULL,
    "chunkCount" integer DEFAULT 0 NOT NULL,
    "chunkIndexAttempts" integer DEFAULT 0 NOT NULL,
    "chunkIndexedAt" timestamp(3) without time zone,
    "chunkIndexRequestedAt" timestamp(3) without time zone,
    "chunkIndexStartedAt" timestamp(3) without time zone,
    "chunkIndexError" text,
    "sourceKey" text NOT NULL,
    title text NOT NULL,
    summary text,
    content text NOT NULL,
    "sourceFileName" text,
    "sourceFilePath" text,
    "sourceFileMime" text,
    "sourceFileSize" integer,
    tags text[] DEFAULT ARRAY[]::text[],
    "piiRiskLevel" text DEFAULT 'low'::text,
    metadata jsonb,
    "authoredByUserId" integer,
    "approvedByUserId" integer,
    "approvedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."KnowledgeDocument" OWNER TO postgres;

--
-- Name: KnowledgeDocumentChunk; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."KnowledgeDocumentChunk" (
    id text NOT NULL,
    "chunkKey" text NOT NULL,
    "tenantKey" text NOT NULL,
    "documentId" text NOT NULL,
    scope public."KnowledgeDocumentScope" NOT NULL,
    "sourceType" public."KnowledgeSourceType" NOT NULL,
    "chunkIndex" integer NOT NULL,
    "charStart" integer NOT NULL,
    "charEnd" integer NOT NULL,
    "charLength" integer NOT NULL,
    content text NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[],
    metadata jsonb,
    provider text NOT NULL,
    model text NOT NULL,
    dimensions integer NOT NULL,
    "contentHash" text NOT NULL,
    vector jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."KnowledgeDocumentChunk" OWNER TO postgres;

--
-- Name: KnowledgeDocumentEmbedding; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."KnowledgeDocumentEmbedding" (
    id text NOT NULL,
    "documentId" text NOT NULL,
    provider text NOT NULL,
    model text NOT NULL,
    dimensions integer NOT NULL,
    "contentHash" text NOT NULL,
    vector jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."KnowledgeDocumentEmbedding" OWNER TO postgres;

--
-- Name: KnowledgeIngestionRun; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."KnowledgeIngestionRun" (
    id text NOT NULL,
    "tenantKey" text NOT NULL,
    "sourceType" text NOT NULL,
    "triggerType" text NOT NULL,
    status public."KnowledgeIngestionRunStatus" DEFAULT 'RUNNING'::public."KnowledgeIngestionRunStatus" NOT NULL,
    "processedCount" integer DEFAULT 0 NOT NULL,
    "createdCandidates" integer DEFAULT 0 NOT NULL,
    "skippedCount" integer DEFAULT 0 NOT NULL,
    "errorCount" integer DEFAULT 0 NOT NULL,
    metadata jsonb,
    "createdByUserId" integer,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "finishedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."KnowledgeIngestionRun" OWNER TO postgres;

--
-- Name: KnowledgeNegativeExample; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."KnowledgeNegativeExample" (
    id text NOT NULL,
    "tenantKey" text NOT NULL,
    scope public."KnowledgeDocumentScope" NOT NULL,
    status public."KnowledgeNegativeExampleStatus" DEFAULT 'PENDING'::public."KnowledgeNegativeExampleStatus" NOT NULL,
    "sourceKind" public."KnowledgeNegativeExampleSourceKind" NOT NULL,
    "conversationId" text,
    "candidateId" text,
    "feedbackId" text,
    title text NOT NULL,
    summary text,
    "detectedIntent" text,
    channel public."ConversationChannel",
    "disallowedText" text NOT NULL,
    "correctedText" text,
    metadata jsonb,
    "createdByUserId" integer,
    "reviewedByUserId" integer,
    "reviewedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."KnowledgeNegativeExample" OWNER TO postgres;

--
-- Name: KnowledgeRawEvent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."KnowledgeRawEvent" (
    id text NOT NULL,
    "tenantKey" text NOT NULL,
    scope public."KnowledgeDocumentScope" NOT NULL,
    channel public."ConversationChannel" NOT NULL,
    "sourceAuthorType" public."ConversationMessageAuthorType" NOT NULL,
    status public."KnowledgeRawEventStatus" DEFAULT 'NEW'::public."KnowledgeRawEventStatus" NOT NULL,
    "conversationId" text,
    "messageId" text,
    "userMessage" text NOT NULL,
    "normalizedMessage" text NOT NULL,
    "redactedMessage" text,
    "operatorReply" text,
    "aiReply" text,
    "detectedIntent" text,
    problem text,
    "contextSummary" text,
    "suggestedResponse" text,
    confidence double precision,
    "relevanceScore" double precision,
    "dedupeHash" text,
    "clusterKey" text,
    "messageElements" jsonb,
    "messageContextOrigin" jsonb,
    attachments jsonb,
    metadata jsonb,
    "ingestionRunId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."KnowledgeRawEvent" OWNER TO postgres;

--
-- Name: KnowledgeSnapshot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."KnowledgeSnapshot" (
    id text NOT NULL,
    "tenantKey" text NOT NULL,
    scope public."KnowledgeDocumentScope" NOT NULL,
    status public."KnowledgeSnapshotStatus" DEFAULT 'BUILDING'::public."KnowledgeSnapshotStatus" NOT NULL,
    version integer NOT NULL,
    "generationReason" text NOT NULL,
    "summaryText" text,
    metrics jsonb,
    "coverageScore" double precision,
    metadata jsonb,
    "generatedByUserId" integer,
    "generatedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."KnowledgeSnapshot" OWNER TO postgres;

--
-- Name: KnowledgeSnapshotEntry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."KnowledgeSnapshotEntry" (
    id text NOT NULL,
    "snapshotId" text NOT NULL,
    "tenantKey" text NOT NULL,
    scope public."KnowledgeDocumentScope" NOT NULL,
    "entryType" public."KnowledgeSnapshotEntryType" NOT NULL,
    key text NOT NULL,
    title text NOT NULL,
    "plainText" text NOT NULL,
    "normalizedIntent" text,
    "topicKey" text,
    confidence double precision,
    priority text,
    "appliesToChannels" text[] DEFAULT ARRAY[]::text[],
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."KnowledgeSnapshotEntry" OWNER TO postgres;

--
-- Name: KnowledgeSnapshotSource; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."KnowledgeSnapshotSource" (
    id text NOT NULL,
    "snapshotEntryId" text NOT NULL,
    "sourceKind" public."KnowledgeSnapshotSourceKind" NOT NULL,
    "sourceId" text NOT NULL,
    "sourceVersion" integer,
    "sourceStatus" text,
    role public."KnowledgeSnapshotSourceRole" NOT NULL,
    excerpt text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."KnowledgeSnapshotSource" OWNER TO postgres;

--
-- Name: KnowledgeSuggestionFeedback; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."KnowledgeSuggestionFeedback" (
    id text NOT NULL,
    "tenantKey" text NOT NULL,
    "conversationId" text NOT NULL,
    "candidateId" text NOT NULL,
    "targetMessageId" text,
    "operatorMessageId" text,
    "actorUserId" integer,
    outcome public."KnowledgeSuggestionFeedbackOutcome" NOT NULL,
    "suggestedText" text,
    "finalText" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."KnowledgeSuggestionFeedback" OWNER TO postgres;

--
-- Name: Notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Notification" (
    id integer NOT NULL,
    "eventType" public."NotificationEventType",
    audience public."NotificationAudience",
    channel public."NotificationChannel",
    "deliveryStatus" public."NotificationDeliveryStatus" DEFAULT 'PENDING'::public."NotificationDeliveryStatus" NOT NULL,
    "recipientId" integer,
    "customerId" integer,
    "orderId" integer,
    "paymentId" integer,
    title text,
    body text,
    metadata jsonb,
    "idempotencyKey" text,
    "readAt" timestamp(3) without time zone,
    readed boolean DEFAULT false NOT NULL,
    target text,
    description text,
    type integer DEFAULT 0 NOT NULL,
    image text,
    location text,
    "locationLabel" text,
    status text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Notification" OWNER TO postgres;

--
-- Name: NotificationSetting; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."NotificationSetting" (
    id integer NOT NULL,
    "eventType" public."NotificationEventType" NOT NULL,
    audience public."NotificationAudience" NOT NULL,
    channel public."NotificationChannel" NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    roles text[] DEFAULT ARRAY[]::text[],
    "templateKey" text,
    "localeOverrides" jsonb,
    "emailSubject" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."NotificationSetting" OWNER TO postgres;

--
-- Name: NotificationSetting_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."NotificationSetting_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."NotificationSetting_id_seq" OWNER TO postgres;

--
-- Name: NotificationSetting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."NotificationSetting_id_seq" OWNED BY public."NotificationSetting".id;


--
-- Name: Notification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Notification_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Notification_id_seq" OWNER TO postgres;

--
-- Name: Notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Notification_id_seq" OWNED BY public."Notification".id;


--
-- Name: Order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Order" (
    id integer NOT NULL,
    uuid text NOT NULL,
    "documentType" public."DocumentType" DEFAULT 'ORDER'::public."DocumentType" NOT NULL,
    "customerId" integer NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "paymentMethodId" integer,
    "shippingAddress1" text,
    "shippingAddress2" text,
    "shippingCity" text,
    "shippingDepartment" text,
    "shippingState" text,
    "shippingNeighborhood" text,
    "shippingZip" text,
    "shippingCountry" text,
    "billingAddress1" text,
    "billingAddress2" text,
    "billingCity" text,
    "billingDepartment" text,
    "billingState" text,
    "billingNeighborhood" text,
    "billingZip" text,
    "billingCountry" text,
    "billingSameAsShipping" boolean DEFAULT false NOT NULL,
    "shippingVendor" text,
    "deliveryFees" numeric(18,2) DEFAULT 0,
    "estimatedMin" integer DEFAULT 1,
    "estimatedMax" integer DEFAULT 3,
    comment text,
    disclaimer text,
    metadata jsonb,
    "statusId" integer,
    "subTotal" numeric(18,2) DEFAULT 0 NOT NULL,
    tax numeric(18,2) DEFAULT 0 NOT NULL,
    "grandTotal" numeric(18,2) DEFAULT 0 NOT NULL,
    "minimumDepositType" public."DepositRequirementType" DEFAULT 'PERCENTAGE'::public."DepositRequirementType" NOT NULL,
    "minimumDepositValue" numeric(18,2) DEFAULT 0 NOT NULL,
    "confirmedAt" timestamp(3) without time zone,
    "depositSatisfiedAt" timestamp(3) without time zone,
    "customerCredit" numeric(18,2) DEFAULT 0 NOT NULL,
    "orderCurrency" text DEFAULT 'UYU'::text NOT NULL,
    "fxBase" text,
    "fxRates" jsonb,
    "currencySnapshot" text,
    "taxRateSnapshot" numeric(18,4),
    "priceListIdSnapshot" integer,
    "exchangeRateSnapshot" jsonb,
    "validUntil" timestamp(3) without time zone,
    "activityId" integer,
    "originId" integer,
    "convertedOrderId" integer,
    "convertedAt" timestamp(3) without time zone,
    "convertedBy" integer,
    session_id text,
    user_id text,
    utm_source text,
    utm_medium text,
    utm_campaign text,
    referrer text,
    "documentFilePath" text,
    "documentFileName" text,
    "documentFileMime" text,
    "documentFileSize" integer,
    "documentGeneratedAt" timestamp(3) without time zone,
    "documentPdf" bytea,
    version integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Order" OWNER TO postgres;

--
-- Name: OrderItem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."OrderItem" (
    id integer NOT NULL,
    "orderId" integer NOT NULL,
    "productId" integer,
    "variantId" integer,
    name text NOT NULL,
    price numeric(18,2) DEFAULT 0 NOT NULL,
    qty integer DEFAULT 1 NOT NULL,
    img text,
    description text,
    comments text,
    "unitAmount" numeric(18,4),
    "unitCurrency" text,
    "unitAmountOrderCurrency" numeric(18,4),
    "conversionRate" numeric(18,8),
    "unitCostAmount" numeric(18,4),
    "unitCostCurrency" text,
    "unitCostOrderCurrency" numeric(18,4),
    "customAttributes" jsonb DEFAULT '{}'::jsonb,
    "pricingMethodSnapshot" public."SalesUnit",
    "unitPriceSnapshot" numeric(18,4),
    "skuSnapshot" text,
    "nameSnapshot" text,
    "specSummary" text,
    "specJson" jsonb DEFAULT '{}'::jsonb,
    "parametricConfig" jsonb,
    "parametricBreakdown" jsonb,
    "parametricReferenceDate" timestamp(3) without time zone,
    "parametricSource" text,
    "parametricVersion" text
);


ALTER TABLE public."OrderItem" OWNER TO postgres;

--
-- Name: OrderItem_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."OrderItem_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."OrderItem_id_seq" OWNER TO postgres;

--
-- Name: OrderItem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."OrderItem_id_seq" OWNED BY public."OrderItem".id;


--
-- Name: OrderTimelineEvent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."OrderTimelineEvent" (
    id integer NOT NULL,
    "eventId" text NOT NULL,
    "orderId" integer NOT NULL,
    type text NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    actor text,
    amount numeric(18,2),
    currency text,
    "paymentMethod" text,
    "remainingAmount" numeric(18,2),
    "estimateDate" timestamp(3) without time zone,
    "statusFrom" text,
    "statusTo" text,
    message text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."OrderTimelineEvent" OWNER TO postgres;

--
-- Name: OrderTimelineEvent_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."OrderTimelineEvent_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."OrderTimelineEvent_id_seq" OWNER TO postgres;

--
-- Name: OrderTimelineEvent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."OrderTimelineEvent_id_seq" OWNED BY public."OrderTimelineEvent".id;


--
-- Name: Order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Order_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Order_id_seq" OWNER TO postgres;

--
-- Name: Order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Order_id_seq" OWNED BY public."Order".id;


--
-- Name: PasswordResetToken; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PasswordResetToken" (
    id integer NOT NULL,
    "tokenHash" text NOT NULL,
    "userId" integer,
    "customerId" integer,
    channel public."PasswordResetChannel" DEFAULT 'EMAIL'::public."PasswordResetChannel" NOT NULL,
    "targetIdentifierHash" text,
    "signingKid" text,
    metadata jsonb,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone,
    "ipAddress" text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PasswordResetToken" OWNER TO postgres;

--
-- Name: PasswordResetToken_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PasswordResetToken_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."PasswordResetToken_id_seq" OWNER TO postgres;

--
-- Name: PasswordResetToken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PasswordResetToken_id_seq" OWNED BY public."PasswordResetToken".id;


--
-- Name: Payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Payment" (
    id integer NOT NULL,
    "orderId" integer NOT NULL,
    "paymentMethodId" integer,
    method text,
    amount numeric(18,2) NOT NULL,
    currency text NOT NULL,
    type public."PaymentType" DEFAULT 'BALANCE'::public."PaymentType" NOT NULL,
    status public."PaymentStatus" DEFAULT 'REGISTERED'::public."PaymentStatus" NOT NULL,
    reference text,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    notes text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Payment" OWNER TO postgres;

--
-- Name: PaymentAttachment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PaymentAttachment" (
    id integer NOT NULL,
    "paymentId" integer NOT NULL,
    name text NOT NULL,
    "mimeType" text,
    size integer,
    content bytea NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PaymentAttachment" OWNER TO postgres;

--
-- Name: PaymentAttachment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PaymentAttachment_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."PaymentAttachment_id_seq" OWNER TO postgres;

--
-- Name: PaymentAttachment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PaymentAttachment_id_seq" OWNED BY public."PaymentAttachment".id;


--
-- Name: PaymentPlan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PaymentPlan" (
    id integer NOT NULL,
    "orderId" integer NOT NULL,
    name text,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PaymentPlan" OWNER TO postgres;

--
-- Name: PaymentPlanMilestone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PaymentPlanMilestone" (
    id integer NOT NULL,
    "paymentPlanId" integer NOT NULL,
    name text NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "requirementType" public."DepositRequirementType" DEFAULT 'PERCENTAGE'::public."DepositRequirementType" NOT NULL,
    value numeric(18,4) DEFAULT 0 NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PaymentPlanMilestone" OWNER TO postgres;

--
-- Name: PaymentPlanMilestone_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PaymentPlanMilestone_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."PaymentPlanMilestone_id_seq" OWNER TO postgres;

--
-- Name: PaymentPlanMilestone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PaymentPlanMilestone_id_seq" OWNED BY public."PaymentPlanMilestone".id;


--
-- Name: PaymentPlan_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PaymentPlan_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."PaymentPlan_id_seq" OWNER TO postgres;

--
-- Name: PaymentPlan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PaymentPlan_id_seq" OWNED BY public."PaymentPlan".id;


--
-- Name: Payment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Payment_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Payment_id_seq" OWNER TO postgres;

--
-- Name: Payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Payment_id_seq" OWNED BY public."Payment".id;


--
-- Name: Product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Product" (
    id integer NOT NULL,
    name text NOT NULL,
    "productCode" text,
    img text,
    description text,
    specifications text,
    "seoTitle" text,
    "seoDescription" text,
    "seoImageUrl" text,
    "categoryId" integer,
    "installationResolutionMode" public."InstallationResolutionMode",
    "installationChargeScope" public."InstallationChargeScope",
    "installationPricePresentationMode" public."InstallationPricePresentationMode",
    "installServiceProductId" integer,
    "productType" public."ProductType" DEFAULT 'PHYSICAL'::public."ProductType" NOT NULL,
    mode public."ProductMode" DEFAULT 'SIMPLE'::public."ProductMode" NOT NULL,
    "calculationStrategy" text DEFAULT 'M2'::text NOT NULL,
    precio_venta numeric(12,2) DEFAULT 0 NOT NULL,
    precio_costo numeric(12,2) DEFAULT 0 NOT NULL,
    currency text DEFAULT 'UYU'::text NOT NULL,
    "unitOfMeasure" public."SalesUnit" DEFAULT 'UNIT'::public."SalesUnit" NOT NULL,
    "isBudgetCalculable" boolean DEFAULT false NOT NULL,
    stock integer DEFAULT 0 NOT NULL,
    "permanentStock" boolean DEFAULT false NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    "costPerItem" double precision,
    "bulkDiscountPrice" double precision,
    "taxRate" double precision DEFAULT 22,
    tags text[],
    brand text,
    vendor text,
    published boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "productCapabilities" jsonb,
    "productConfigSchema" jsonb
);


ALTER TABLE public."Product" OWNER TO postgres;

--
-- Name: ProductCategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductCategory" (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    image text,
    "seoTitle" text,
    "seoDescription" text,
    "seoImageUrl" text,
    "parentId" integer,
    "installationResolutionMode" public."InstallationResolutionMode",
    "installationChargeScope" public."InstallationChargeScope",
    "installationPricePresentationMode" public."InstallationPricePresentationMode",
    "installServiceProductId" integer,
    "catalogExposureMode" public."CatalogExposureMode"
);


ALTER TABLE public."ProductCategory" OWNER TO postgres;

--
-- Name: ProductCategory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ProductCategory_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ProductCategory_id_seq" OWNER TO postgres;

--
-- Name: ProductCategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ProductCategory_id_seq" OWNED BY public."ProductCategory".id;


--
-- Name: ProductImage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductImage" (
    id integer NOT NULL,
    "productId" integer NOT NULL,
    "variantId" integer,
    name text,
    img text NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    alt text,
    "publicId" text,
    version integer DEFAULT 1 NOT NULL,
    "familyKey" text
);


ALTER TABLE public."ProductImage" OWNER TO postgres;

--
-- Name: ProductImage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ProductImage_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ProductImage_id_seq" OWNER TO postgres;

--
-- Name: ProductImage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ProductImage_id_seq" OWNED BY public."ProductImage".id;


--
-- Name: ProductOption; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductOption" (
    id integer NOT NULL,
    "productId" integer NOT NULL,
    type public."ProductAttributeType" NOT NULL,
    name text NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProductOption" OWNER TO postgres;

--
-- Name: ProductOptionValue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductOptionValue" (
    id integer NOT NULL,
    "optionId" integer NOT NULL,
    code text NOT NULL,
    label text NOT NULL,
    value text,
    "colorHex" text,
    "imageUrl" text,
    "imageAlt" text,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProductOptionValue" OWNER TO postgres;

--
-- Name: ProductOptionValue_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ProductOptionValue_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ProductOptionValue_id_seq" OWNER TO postgres;

--
-- Name: ProductOptionValue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ProductOptionValue_id_seq" OWNED BY public."ProductOptionValue".id;


--
-- Name: ProductOption_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ProductOption_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ProductOption_id_seq" OWNER TO postgres;

--
-- Name: ProductOption_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ProductOption_id_seq" OWNED BY public."ProductOption".id;


--
-- Name: ProductRelation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductRelation" (
    id integer NOT NULL,
    "productId" integer NOT NULL,
    "relatedProductId" integer NOT NULL,
    type public."ProductRelationType" NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProductRelation" OWNER TO postgres;

--
-- Name: ProductRelation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ProductRelation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ProductRelation_id_seq" OWNER TO postgres;

--
-- Name: ProductRelation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ProductRelation_id_seq" OWNED BY public."ProductRelation".id;


--
-- Name: ProductReview; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductReview" (
    id integer NOT NULL,
    "productId" integer NOT NULL,
    "customerId" integer NOT NULL,
    "orderItemId" integer,
    rating integer NOT NULL,
    title text,
    comment text NOT NULL,
    status public."ProductReviewStatus" DEFAULT 'PUBLISHED'::public."ProductReviewStatus" NOT NULL,
    "verifiedPurchase" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProductReview" OWNER TO postgres;

--
-- Name: ProductReview_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ProductReview_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ProductReview_id_seq" OWNER TO postgres;

--
-- Name: ProductReview_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ProductReview_id_seq" OWNED BY public."ProductReview".id;


--
-- Name: ProductVariant; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductVariant" (
    id integer NOT NULL,
    "productId" integer NOT NULL,
    key text NOT NULL,
    sku text,
    barcode text,
    label text,
    "salePrice" numeric(12,2),
    "costPrice" numeric(12,2),
    stock integer,
    "permanentStock" boolean,
    "isActive" boolean DEFAULT true NOT NULL,
    "inheritSalePrice" boolean DEFAULT true NOT NULL,
    "inheritCostPrice" boolean DEFAULT true NOT NULL,
    "inheritStock" boolean DEFAULT true NOT NULL,
    "inheritSku" boolean DEFAULT true NOT NULL,
    "inheritImages" boolean DEFAULT true NOT NULL,
    attributes jsonb DEFAULT '{}'::jsonb NOT NULL,
    "combinationKey" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProductVariant" OWNER TO postgres;

--
-- Name: ProductVariantSelection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductVariantSelection" (
    "variantId" integer NOT NULL,
    "optionValueId" integer NOT NULL
);


ALTER TABLE public."ProductVariantSelection" OWNER TO postgres;

--
-- Name: ProductVariant_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ProductVariant_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ProductVariant_id_seq" OWNER TO postgres;

--
-- Name: ProductVariant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ProductVariant_id_seq" OWNED BY public."ProductVariant".id;


--
-- Name: Product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Product_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Product_id_seq" OWNER TO postgres;

--
-- Name: Product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Product_id_seq" OWNED BY public."Product".id;


--
-- Name: ProductionOrder; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductionOrder" (
    id integer NOT NULL,
    "workOrderId" integer NOT NULL,
    "orderId" integer NOT NULL,
    status public."WorkOrderStatus" DEFAULT 'PENDING'::public."WorkOrderStatus" NOT NULL,
    priority integer DEFAULT 1 NOT NULL,
    "assignedToId" integer,
    "scheduledAt" timestamp(3) without time zone,
    "startedAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "deliveredAt" timestamp(3) without time zone,
    notes text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProductionOrder" OWNER TO postgres;

--
-- Name: ProductionOrder_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ProductionOrder_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ProductionOrder_id_seq" OWNER TO postgres;

--
-- Name: ProductionOrder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ProductionOrder_id_seq" OWNED BY public."ProductionOrder".id;


--
-- Name: Project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Project" (
    id integer NOT NULL,
    name text NOT NULL,
    code text,
    description text,
    "startDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP,
    "endDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Project" OWNER TO postgres;

--
-- Name: Project_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Project_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Project_id_seq" OWNER TO postgres;

--
-- Name: Project_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Project_id_seq" OWNED BY public."Project".id;


--
-- Name: RoleNotificationRule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RoleNotificationRule" (
    id integer NOT NULL,
    role public."Role" NOT NULL,
    categories public."EmailCategory"[],
    enabled boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."RoleNotificationRule" OWNER TO postgres;

--
-- Name: RoleNotificationRule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."RoleNotificationRule_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."RoleNotificationRule_id_seq" OWNER TO postgres;

--
-- Name: RoleNotificationRule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."RoleNotificationRule_id_seq" OWNED BY public."RoleNotificationRule".id;


--
-- Name: SecureConfig; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SecureConfig" (
    key text NOT NULL,
    value text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."SecureConfig" OWNER TO postgres;

--
-- Name: Setting; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Setting" (
    id integer NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL,
    environment text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Setting" OWNER TO postgres;

--
-- Name: Setting_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Setting_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Setting_id_seq" OWNER TO postgres;

--
-- Name: Setting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Setting_id_seq" OWNED BY public."Setting".id;


--
-- Name: ShippingOption; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ShippingOption" (
    id integer NOT NULL,
    name text NOT NULL,
    "deliveryFees" double precision DEFAULT 0,
    "estimatedMin" integer DEFAULT 0,
    "estimatedMax" integer DEFAULT 0,
    img text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ShippingOption" OWNER TO postgres;

--
-- Name: ShippingOption_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ShippingOption_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ShippingOption_id_seq" OWNER TO postgres;

--
-- Name: ShippingOption_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ShippingOption_id_seq" OWNED BY public."ShippingOption".id;


--
-- Name: StandardSize; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."StandardSize" (
    id integer NOT NULL,
    width numeric(10,4) NOT NULL,
    height numeric(10,4) NOT NULL,
    label text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."StandardSize" OWNER TO postgres;

--
-- Name: StandardSize_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."StandardSize_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."StandardSize_id_seq" OWNER TO postgres;

--
-- Name: StandardSize_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."StandardSize_id_seq" OWNED BY public."StandardSize".id;


--
-- Name: StorefrontOAuthSession; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."StorefrontOAuthSession" (
    id text NOT NULL,
    provider text NOT NULL,
    state text NOT NULL,
    "codeVerifier" text NOT NULL,
    nonce text NOT NULL,
    "redirectUri" text NOT NULL,
    "returnPath" text,
    purpose text DEFAULT 'login'::text,
    "expectedCustomerId" integer,
    scopes text NOT NULL,
    "ipAddress" text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "errorCode" text,
    "errorMessage" text
);


ALTER TABLE public."StorefrontOAuthSession" OWNER TO postgres;

--
-- Name: StorefrontPaymentIntent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."StorefrontPaymentIntent" (
    id text NOT NULL,
    provider text NOT NULL,
    "externalPaymentId" text,
    status text NOT NULL,
    "statusDetail" text,
    amount numeric(18,2) NOT NULL,
    currency text NOT NULL,
    installments integer,
    "paymentMethodId" text,
    "paymentTypeId" text,
    "cardBrand" text,
    "cardLastFour" text,
    "cardholderName" text,
    "statementDescriptor" text,
    description text,
    "cartId" text,
    "orderId" integer,
    "payerEmail" text,
    "payerIdentificationType" text,
    "payerIdentificationNumber" text,
    "payerFirstName" text,
    "payerLastName" text,
    "riskLevel" text,
    "fraudStatus" text,
    "captureMethod" text,
    "paymentMethodType" text,
    metadata jsonb,
    "rawResponse" jsonb,
    "rawError" jsonb,
    "idempotencyKey" text,
    "requestId" text,
    "liveMode" boolean,
    "refundsRaw" jsonb,
    "processedAt" timestamp(3) without time zone,
    "statusUpdatedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."StorefrontPaymentIntent" OWNER TO postgres;

--
-- Name: Story; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Story" (
    id text NOT NULL,
    slug text NOT NULL,
    title text NOT NULL,
    "coverPublicId" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "startsAt" timestamp(3) without time zone,
    "endsAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Story" OWNER TO postgres;

--
-- Name: StoryItem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."StoryItem" (
    id text NOT NULL,
    "storyId" text NOT NULL,
    "order" integer NOT NULL,
    type text NOT NULL,
    "publicId" text NOT NULL,
    duration integer,
    "ctaLabel" text,
    "ctaUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."StoryItem" OWNER TO postgres;

--
-- Name: SystemConfig; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SystemConfig" (
    key text NOT NULL,
    value text NOT NULL
);


ALTER TABLE public."SystemConfig" OWNER TO postgres;

--
-- Name: Task; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Task" (
    id integer NOT NULL,
    code text,
    subject text NOT NULL,
    description text,
    priority integer DEFAULT 1 NOT NULL,
    status text,
    "projectId" integer,
    "createdById" integer,
    "dueDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Task" OWNER TO postgres;

--
-- Name: TaskAssignee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TaskAssignee" (
    "taskId" integer NOT NULL,
    "userId" integer NOT NULL
);


ALTER TABLE public."TaskAssignee" OWNER TO postgres;

--
-- Name: Task_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Task_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Task_id_seq" OWNER TO postgres;

--
-- Name: Task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Task_id_seq" OWNED BY public."Task".id;


--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    name text,
    "lastName" text,
    email text NOT NULL,
    img text,
    role public."Role" DEFAULT 'USER'::public."Role" NOT NULL,
    "capabilityGroups" public."UserCapabilityGroup"[] DEFAULT ARRAY[]::public."UserCapabilityGroup"[],
    "directCapabilities" public."UserCapability"[] DEFAULT ARRAY[]::public."UserCapability"[],
    lang text DEFAULT 'en'::text NOT NULL,
    country text,
    "countryCode" text,
    city text,
    "passwordHash" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    phone text,
    status public."UserStatus" DEFAULT 'ACTIVE'::public."UserStatus" NOT NULL
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: UserActivity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."UserActivity" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    type public."UserActivityType" NOT NULL,
    description text,
    metadata jsonb,
    "ipAddress" text,
    "userAgent" text,
    "deviceId" integer,
    "performedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."UserActivity" OWNER TO postgres;

--
-- Name: UserActivity_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."UserActivity_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."UserActivity_id_seq" OWNER TO postgres;

--
-- Name: UserActivity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."UserActivity_id_seq" OWNED BY public."UserActivity".id;


--
-- Name: UserDevice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."UserDevice" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    fingerprint text NOT NULL,
    "displayName" text,
    "userAgent" text,
    location text,
    "lastIpAddress" text,
    "deviceType" text,
    "firstSeenAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastSeenAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."UserDevice" OWNER TO postgres;

--
-- Name: UserDevice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."UserDevice_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."UserDevice_id_seq" OWNER TO postgres;

--
-- Name: UserDevice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."UserDevice_id_seq" OWNED BY public."UserDevice".id;


--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."User_id_seq" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: Wishlist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Wishlist" (
    id integer NOT NULL,
    "customerId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Wishlist" OWNER TO postgres;

--
-- Name: WishlistItem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WishlistItem" (
    id integer NOT NULL,
    "wishlistId" integer NOT NULL,
    "productId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."WishlistItem" OWNER TO postgres;

--
-- Name: WishlistItem_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."WishlistItem_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."WishlistItem_id_seq" OWNER TO postgres;

--
-- Name: WishlistItem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."WishlistItem_id_seq" OWNED BY public."WishlistItem".id;


--
-- Name: Wishlist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Wishlist_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Wishlist_id_seq" OWNER TO postgres;

--
-- Name: Wishlist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Wishlist_id_seq" OWNED BY public."Wishlist".id;


--
-- Name: WorkOrder; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WorkOrder" (
    id integer NOT NULL,
    "orderId" integer NOT NULL,
    code text NOT NULL,
    status public."WorkOrderStatus" DEFAULT 'PENDING'::public."WorkOrderStatus" NOT NULL,
    "issuedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "startedAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "deliveredAt" timestamp(3) without time zone,
    "closedAt" timestamp(3) without time zone,
    notes text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."WorkOrder" OWNER TO postgres;

--
-- Name: WorkOrder_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."WorkOrder_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."WorkOrder_id_seq" OWNER TO postgres;

--
-- Name: WorkOrder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."WorkOrder_id_seq" OWNED BY public."WorkOrder".id;


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: abertura_glossary_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.abertura_glossary_items (
    id integer NOT NULL,
    category text NOT NULL,
    label text NOT NULL,
    value text NOT NULL,
    "adjustPct" numeric(8,3),
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.abertura_glossary_items OWNER TO postgres;

--
-- Name: abertura_glossary_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.abertura_glossary_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.abertura_glossary_items_id_seq OWNER TO postgres;

--
-- Name: abertura_glossary_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.abertura_glossary_items_id_seq OWNED BY public.abertura_glossary_items.id;


--
-- Name: analytics_ads_daily_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_ads_daily_metrics (
    id bigint NOT NULL,
    date date NOT NULL,
    campaign text NOT NULL,
    clicks integer DEFAULT 0 NOT NULL,
    impressions integer DEFAULT 0 NOT NULL,
    cost numeric(18,4) DEFAULT 0 NOT NULL,
    conversions integer DEFAULT 0 NOT NULL,
    conversion_value numeric(18,4) DEFAULT 0 NOT NULL,
    connection_id text,
    sync_run_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    has_conversion_data boolean DEFAULT false NOT NULL
);


ALTER TABLE public.analytics_ads_daily_metrics OWNER TO postgres;

--
-- Name: analytics_ads_daily_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.analytics_ads_daily_metrics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.analytics_ads_daily_metrics_id_seq OWNER TO postgres;

--
-- Name: analytics_ads_daily_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.analytics_ads_daily_metrics_id_seq OWNED BY public.analytics_ads_daily_metrics.id;


--
-- Name: analytics_ai_insights; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_ai_insights (
    id text NOT NULL,
    date date NOT NULL,
    summary text NOT NULL,
    insights_json jsonb NOT NULL,
    actions_json jsonb NOT NULL,
    confidence numeric(5,4) NOT NULL,
    bundle_json jsonb NOT NULL,
    response_json jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.analytics_ai_insights OWNER TO postgres;

--
-- Name: analytics_baseline_checks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_baseline_checks (
    id text NOT NULL,
    date date NOT NULL,
    source text NOT NULL,
    metric text NOT NULL,
    comparison_kind text NOT NULL,
    expected_value numeric(18,6) NOT NULL,
    actual_value numeric(18,6) NOT NULL,
    diff_pct numeric(10,4) NOT NULL,
    status text NOT NULL,
    snapshot_group text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.analytics_baseline_checks OWNER TO postgres;

--
-- Name: analytics_baseline_snapshots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_baseline_snapshots (
    id text NOT NULL,
    connection_id text,
    source text DEFAULT 'ga4'::text NOT NULL,
    report_key text NOT NULL,
    date date NOT NULL,
    metric_name text NOT NULL,
    dimension_hash text NOT NULL,
    dimension_values jsonb,
    value numeric(18,6) NOT NULL,
    query_hash text NOT NULL,
    raw jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    origin text DEFAULT 'api'::text NOT NULL,
    snapshot_group text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.analytics_baseline_snapshots OWNER TO postgres;

--
-- Name: analytics_connection_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_connection_credentials (
    connection_id text NOT NULL,
    refresh_token_encrypted text,
    access_token_encrypted text,
    expires_at timestamp(3) without time zone,
    scopes text[] DEFAULT ARRAY[]::text[] NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.analytics_connection_credentials OWNER TO postgres;

--
-- Name: analytics_connections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_connections (
    id text NOT NULL,
    source text NOT NULL,
    status text DEFAULT 'needs_auth'::text NOT NULL,
    external_account_id text,
    external_property_id text,
    display_name text NOT NULL,
    sync_interval_minutes integer DEFAULT 60 NOT NULL,
    last_synced_at timestamp(3) without time zone,
    next_sync_at timestamp(3) without time zone,
    needs_reauth boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    last_attempted_sync_at timestamp(3) without time zone,
    last_successful_sync_at timestamp(3) without time zone,
    last_sync_error_message text,
    last_sync_error_at timestamp(3) without time zone
);


ALTER TABLE public.analytics_connections OWNER TO postgres;

--
-- Name: analytics_data_anomalies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_data_anomalies (
    id text NOT NULL,
    type text NOT NULL,
    source text NOT NULL,
    metric text,
    description text NOT NULL,
    severity text NOT NULL,
    detected_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.analytics_data_anomalies OWNER TO postgres;

--
-- Name: analytics_data_parity_checks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_data_parity_checks (
    id text NOT NULL,
    source text NOT NULL,
    metric text NOT NULL,
    date_from date NOT NULL,
    date_to date NOT NULL,
    api_value numeric(18,6) NOT NULL,
    baseline_value numeric(18,6) NOT NULL,
    delta_abs numeric(18,6) NOT NULL,
    delta_percent numeric(10,4) NOT NULL,
    status text NOT NULL,
    snapshot_group text DEFAULT ''::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.analytics_data_parity_checks OWNER TO postgres;

--
-- Name: analytics_data_quality_checks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_data_quality_checks (
    id text NOT NULL,
    connection_id text NOT NULL,
    report_key text NOT NULL,
    date date NOT NULL,
    metric_name text NOT NULL,
    dimension_hash text NOT NULL,
    baseline_value numeric(18,6) NOT NULL,
    synced_value numeric(18,6) NOT NULL,
    diff numeric(18,6) NOT NULL,
    diff_percent numeric(10,4) NOT NULL,
    status text NOT NULL,
    baseline_snapshot_id text,
    sync_run_id text,
    query_hash text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.analytics_data_quality_checks OWNER TO postgres;

--
-- Name: analytics_data_trust_checks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_data_trust_checks (
    id text NOT NULL,
    environment text NOT NULL,
    check_name text NOT NULL,
    status text NOT NULL,
    metric_value numeric(18,6),
    expected_range text NOT NULL,
    details_json jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.analytics_data_trust_checks OWNER TO postgres;

--
-- Name: analytics_endpoint_usage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_endpoint_usage (
    id text NOT NULL,
    endpoint text NOT NULL,
    user_id text,
    status_code integer NOT NULL,
    duration_ms integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.analytics_endpoint_usage OWNER TO postgres;

--
-- Name: analytics_event_comparisons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_event_comparisons (
    id text NOT NULL,
    tenant_id text NOT NULL,
    event_id text NOT NULL,
    event_name text NOT NULL,
    direct_event_timestamp timestamp(3) without time zone,
    ga_event_timestamp timestamp(3) without time zone,
    exists_in_direct boolean DEFAULT false NOT NULL,
    exists_in_ga boolean DEFAULT false NOT NULL,
    payload_match boolean DEFAULT false NOT NULL,
    time_diff_ms integer,
    status text NOT NULL,
    direct_source text,
    ga_source text,
    comparison_date date,
    direct_payload jsonb,
    ga_payload jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.analytics_event_comparisons OWNER TO postgres;

--
-- Name: analytics_export_runs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_export_runs (
    id text NOT NULL,
    export_type text NOT NULL,
    source text,
    date_from date NOT NULL,
    date_to date NOT NULL,
    filters jsonb,
    row_count integer,
    file_format text NOT NULL,
    status text NOT NULL,
    error_message text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    duration_ms integer,
    file_size integer
);


ALTER TABLE public.analytics_export_runs OWNER TO postgres;

--
-- Name: analytics_ga4_daily_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_ga4_daily_metrics (
    id bigint NOT NULL,
    date date NOT NULL,
    source text NOT NULL,
    medium text,
    campaign text,
    sessions integer DEFAULT 0 NOT NULL,
    users integer DEFAULT 0 NOT NULL,
    event_count integer DEFAULT 0 NOT NULL,
    key_events integer DEFAULT 0 NOT NULL,
    purchases integer DEFAULT 0 NOT NULL,
    revenue numeric(18,4) DEFAULT 0 NOT NULL,
    connection_id text,
    sync_run_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.analytics_ga4_daily_metrics OWNER TO postgres;

--
-- Name: analytics_ga4_daily_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.analytics_ga4_daily_metrics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.analytics_ga4_daily_metrics_id_seq OWNER TO postgres;

--
-- Name: analytics_ga4_daily_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.analytics_ga4_daily_metrics_id_seq OWNED BY public.analytics_ga4_daily_metrics.id;


--
-- Name: analytics_health_alert_state; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_health_alert_state (
    id text NOT NULL,
    environment text NOT NULL,
    last_status text NOT NULL,
    last_signature text,
    last_alerted_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_summary_at timestamp(3) without time zone,
    last_digest_at timestamp(3) without time zone,
    last_digest_signature text
);


ALTER TABLE public.analytics_health_alert_state OWNER TO postgres;

--
-- Name: analytics_health_checks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_health_checks (
    id text NOT NULL,
    status text NOT NULL,
    environment text NOT NULL,
    summary text NOT NULL,
    details_json jsonb NOT NULL,
    duration_ms integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.analytics_health_checks OWNER TO postgres;

--
-- Name: analytics_insights; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_insights (
    id text NOT NULL,
    source text NOT NULL,
    metric text NOT NULL,
    dimension text,
    title text NOT NULL,
    description text NOT NULL,
    recommendation text NOT NULL,
    impact text NOT NULL,
    confidence numeric(5,4) NOT NULL,
    evidence jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    resolved_at timestamp(3) without time zone,
    status text DEFAULT 'open'::text NOT NULL
);


ALTER TABLE public.analytics_insights OWNER TO postgres;

--
-- Name: analytics_insights_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_insights_history (
    id text NOT NULL,
    date date NOT NULL,
    insight_type text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    impact text NOT NULL,
    recommendation text NOT NULL,
    confidence numeric(5,4) NOT NULL,
    evidence jsonb NOT NULL,
    source_report text,
    period_range jsonb NOT NULL,
    score numeric(10,4) NOT NULL,
    summary text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.analytics_insights_history OWNER TO postgres;

--
-- Name: analytics_report_catalog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_report_catalog (
    key text NOT NULL,
    source text DEFAULT 'ga4'::text NOT NULL,
    title text NOT NULL,
    description text,
    baseline_header text NOT NULL,
    baseline_title text,
    equivalence_status text DEFAULT 'exact'::text NOT NULL,
    row_key_strategy text DEFAULT 'row_index'::text NOT NULL,
    dimension_labels text[] DEFAULT ARRAY[]::text[] NOT NULL,
    metric_labels text[] DEFAULT ARRAY[]::text[] NOT NULL,
    api_definition jsonb,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.analytics_report_catalog OWNER TO postgres;

--
-- Name: analytics_report_reconciliations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_report_reconciliations (
    id text NOT NULL,
    report_key text NOT NULL,
    baseline_run_id text,
    sync_run_id text,
    status text NOT NULL,
    baseline_row_count integer DEFAULT 0 NOT NULL,
    sync_row_count integer DEFAULT 0 NOT NULL,
    matched_row_count integer DEFAULT 0 NOT NULL,
    baseline_only_row_count integer DEFAULT 0 NOT NULL,
    sync_only_row_count integer DEFAULT 0 NOT NULL,
    delta_percent numeric(10,4) DEFAULT 0 NOT NULL,
    summary text NOT NULL,
    evidence jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.analytics_report_reconciliations OWNER TO postgres;

--
-- Name: analytics_report_rows; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_report_rows (
    id bigint NOT NULL,
    report_run_id text NOT NULL,
    report_key text NOT NULL,
    source text NOT NULL,
    row_type text NOT NULL,
    row_index integer NOT NULL,
    row_key text NOT NULL,
    dimensions jsonb,
    metrics jsonb,
    raw jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.analytics_report_rows OWNER TO postgres;

--
-- Name: analytics_report_rows_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.analytics_report_rows_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.analytics_report_rows_id_seq OWNER TO postgres;

--
-- Name: analytics_report_rows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.analytics_report_rows_id_seq OWNED BY public.analytics_report_rows.id;


--
-- Name: analytics_report_runs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_report_runs (
    id text NOT NULL,
    report_key text NOT NULL,
    source text NOT NULL,
    status text NOT NULL,
    from_date timestamp(3) without time zone,
    to_date timestamp(3) without time zone,
    row_count integer DEFAULT 0 NOT NULL,
    error_message text,
    metadata jsonb,
    started_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    finished_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.analytics_report_runs OWNER TO postgres;

--
-- Name: analytics_reporting_daily; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_reporting_daily (
    id bigint NOT NULL,
    date date NOT NULL,
    channel text NOT NULL,
    source text,
    medium text,
    campaign text,
    product_id text,
    landing_page text,
    device text,
    country text,
    sessions integer DEFAULT 0 NOT NULL,
    users integer DEFAULT 0 NOT NULL,
    revenue numeric(18,4) DEFAULT 0 NOT NULL,
    orders integer DEFAULT 0 NOT NULL,
    cost numeric(18,4) DEFAULT 0 NOT NULL,
    impressions integer DEFAULT 0 NOT NULL,
    clicks integer DEFAULT 0 NOT NULL,
    views integer DEFAULT 0 NOT NULL,
    add_to_cart integer DEFAULT 0 NOT NULL,
    event_count integer DEFAULT 0 NOT NULL,
    key_events integer DEFAULT 0 NOT NULL,
    purchase integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ga4_purchase_proxy integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.analytics_reporting_daily OWNER TO postgres;

--
-- Name: analytics_reporting_daily_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.analytics_reporting_daily_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.analytics_reporting_daily_id_seq OWNER TO postgres;

--
-- Name: analytics_reporting_daily_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.analytics_reporting_daily_id_seq OWNED BY public.analytics_reporting_daily.id;


--
-- Name: analytics_search_console_daily_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_search_console_daily_metrics (
    id bigint NOT NULL,
    date date NOT NULL,
    query text NOT NULL,
    page text,
    clicks integer DEFAULT 0 NOT NULL,
    impressions integer DEFAULT 0 NOT NULL,
    ctr numeric(18,6) DEFAULT 0 NOT NULL,
    "position" numeric(18,6) DEFAULT 0 NOT NULL,
    connection_id text,
    sync_run_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.analytics_search_console_daily_metrics OWNER TO postgres;

--
-- Name: analytics_search_console_daily_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.analytics_search_console_daily_metrics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.analytics_search_console_daily_metrics_id_seq OWNER TO postgres;

--
-- Name: analytics_search_console_daily_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.analytics_search_console_daily_metrics_id_seq OWNED BY public.analytics_search_console_daily_metrics.id;


--
-- Name: analytics_sync_runs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_sync_runs (
    id text NOT NULL,
    connection_id text NOT NULL,
    job_type text NOT NULL,
    from_date timestamp(3) without time zone,
    to_date timestamp(3) without time zone,
    status text NOT NULL,
    records_fetched integer DEFAULT 0 NOT NULL,
    records_upserted integer DEFAULT 0 NOT NULL,
    error_message text,
    started_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    finished_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    queued_at timestamp(3) without time zone,
    retry_count integer DEFAULT 0 NOT NULL,
    partial_failure_flag boolean DEFAULT false NOT NULL,
    duration_ms integer
);


ALTER TABLE public.analytics_sync_runs OWNER TO postgres;

--
-- Name: analytics_usage_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_usage_events (
    id text NOT NULL,
    endpoint text NOT NULL,
    user_id integer,
    time_range text NOT NULL,
    filters jsonb,
    response_time_ms integer NOT NULL,
    response_size integer NOT NULL,
    trust_level text NOT NULL,
    has_data boolean NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.analytics_usage_events OWNER TO postgres;

--
-- Name: dimension_price_matrix; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dimension_price_matrix (
    id integer NOT NULL,
    "productId" integer NOT NULL,
    fingerprint character(64) NOT NULL,
    option_state text DEFAULT 'BASE'::text NOT NULL,
    "familyId" text NOT NULL,
    serie text NOT NULL,
    material text NOT NULL,
    color text NOT NULL,
    vidrio text NOT NULL,
    "widthMm" integer NOT NULL,
    "heightMm" integer NOT NULL,
    "hasMosquitero" boolean DEFAULT false NOT NULL,
    "hasShutterMonoblock" boolean DEFAULT false NOT NULL,
    "shutterSystem" text DEFAULT ''::text NOT NULL,
    price numeric(14,4) NOT NULL,
    "priceBase" numeric(14,4),
    "priceMosquitero" numeric(14,4),
    "priceMonoblock" numeric(14,4),
    "priceMonoblockMosquitero" numeric(14,4),
    "hasMosquiteroOption" boolean DEFAULT false NOT NULL,
    "hasMonoblockOption" boolean DEFAULT false NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "detailSnapshot" text,
    price_lineage jsonb,
    conflict_flags text[] DEFAULT ARRAY[]::text[],
    source text,
    reference_date timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.dimension_price_matrix OWNER TO postgres;

--
-- Name: dimension_price_matrix_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dimension_price_matrix_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dimension_price_matrix_id_seq OWNER TO postgres;

--
-- Name: dimension_price_matrix_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dimension_price_matrix_id_seq OWNED BY public.dimension_price_matrix.id;


--
-- Name: event_facts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.event_facts (
    id bigint NOT NULL,
    event_name text NOT NULL,
    event_timestamp timestamp(3) without time zone NOT NULL,
    event_date date NOT NULL,
    session_id text NOT NULL,
    user_id text,
    page text,
    path text,
    product_id text,
    category text,
    utm_source text,
    utm_medium text,
    utm_campaign text,
    referrer text,
    device text,
    country text,
    value numeric(18,4),
    source_event_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    event_category text,
    source text,
    measurement_status text,
    event_id text,
    fbp text,
    fbc text,
    external_targets jsonb,
    meta_sent_at timestamp(3) without time zone,
    meta_event_id text,
    meta_status text,
    conversion_flag boolean DEFAULT false NOT NULL,
    utm_term text,
    utm_content text,
    landing_page text,
    tenant_id text NOT NULL,
    schema_version integer DEFAULT 1 NOT NULL,
    page_type text,
    component_type text,
    component_id text,
    cta_id text,
    cta_name text,
    cta_type text,
    cta_context text,
    cta_location text,
    "position" numeric(18,6),
    ingestion_source text DEFAULT 'direct'::text NOT NULL,
    ingestion_path text
);


ALTER TABLE public.event_facts OWNER TO postgres;

--
-- Name: event_facts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.event_facts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.event_facts_id_seq OWNER TO postgres;

--
-- Name: event_facts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.event_facts_id_seq OWNED BY public.event_facts.id;


--
-- Name: events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.events (
    id text NOT NULL,
    event_name text NOT NULL,
    session_id text NOT NULL,
    correlation_id text,
    user_id text,
    url text NOT NULL,
    referrer text,
    user_agent text NOT NULL,
    "timestamp" timestamp(3) without time zone NOT NULL,
    payload jsonb NOT NULL,
    processed boolean DEFAULT false NOT NULL,
    "processedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    event_category text,
    source text,
    measurement_status text,
    event_id text,
    fbp text,
    fbc text,
    external_targets jsonb,
    meta_sent_at timestamp(3) without time zone,
    meta_event_id text,
    meta_status text,
    conversion_flag boolean DEFAULT false NOT NULL,
    tenant_id text NOT NULL,
    schema_version integer DEFAULT 1 NOT NULL,
    page_type text,
    component_type text,
    component_id text,
    cta_id text,
    cta_name text,
    cta_type text,
    cta_context text,
    cta_location text,
    "position" numeric(18,6),
    ingestion_source text DEFAULT 'direct'::text NOT NULL,
    ingestion_path text
);


ALTER TABLE public.events OWNER TO postgres;

--
-- Name: otp_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.otp_codes (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "codeHash" text NOT NULL,
    type public."OtpCodeType" NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    "consumedAt" timestamp(3) without time zone,
    target text,
    channel text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.otp_codes OWNER TO postgres;

--
-- Name: otp_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.otp_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.otp_codes_id_seq OWNER TO postgres;

--
-- Name: otp_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.otp_codes_id_seq OWNED BY public.otp_codes.id;


--
-- Name: parametric_compatibility_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parametric_compatibility_rules (
    id integer NOT NULL,
    "productId" integer NOT NULL,
    type text NOT NULL,
    "ruleKey" text NOT NULL,
    "ruleValue" jsonb NOT NULL,
    note text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.parametric_compatibility_rules OWNER TO postgres;

--
-- Name: parametric_compatibility_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parametric_compatibility_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.parametric_compatibility_rules_id_seq OWNER TO postgres;

--
-- Name: parametric_compatibility_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.parametric_compatibility_rules_id_seq OWNED BY public.parametric_compatibility_rules.id;


--
-- Name: parametric_matrix_staging; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parametric_matrix_staging (
    id integer NOT NULL,
    "productId" integer NOT NULL,
    fingerprint character(64) NOT NULL,
    option_state text DEFAULT 'BASE'::text NOT NULL,
    "familyId" text NOT NULL,
    serie text NOT NULL,
    material text NOT NULL,
    color text NOT NULL,
    vidrio text NOT NULL,
    "widthMm" integer NOT NULL,
    "heightMm" integer NOT NULL,
    "hasMosquitero" boolean DEFAULT false NOT NULL,
    "hasShutterMonoblock" boolean DEFAULT false NOT NULL,
    "shutterSystem" text DEFAULT ''::text NOT NULL,
    "hasMosquiteroOption" boolean DEFAULT false NOT NULL,
    "hasMonoblockOption" boolean DEFAULT false NOT NULL,
    "priceBase" numeric(14,4),
    "priceMosquitero" numeric(14,4),
    "priceMonoblock" numeric(14,4),
    "priceMonoblockMosquitero" numeric(14,4),
    currency text DEFAULT 'USD'::text NOT NULL,
    specifications text,
    "sourceSystem" text NOT NULL,
    "sourceRecordId" text,
    source text,
    reference_date timestamp(3) without time zone,
    "ingestedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "processedAt" timestamp(3) without time zone,
    payload jsonb
);


ALTER TABLE public.parametric_matrix_staging OWNER TO postgres;

--
-- Name: parametric_matrix_staging_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parametric_matrix_staging_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.parametric_matrix_staging_id_seq OWNER TO postgres;

--
-- Name: parametric_matrix_staging_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.parametric_matrix_staging_id_seq OWNED BY public.parametric_matrix_staging.id;


--
-- Name: security_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.security_events (
    id integer NOT NULL,
    "userId" integer,
    "eventType" public."SecurityEventType" NOT NULL,
    channel text,
    "ipAddress" text,
    "userAgent" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.security_events OWNER TO postgres;

--
-- Name: security_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.security_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.security_events_id_seq OWNER TO postgres;

--
-- Name: security_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.security_events_id_seq OWNED BY public.security_events.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    first_seen timestamp(3) without time zone,
    last_seen timestamp(3) without time zone,
    utm_source text,
    utm_medium text,
    utm_campaign text,
    referrer text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: ActivityColumn id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ActivityColumn" ALTER COLUMN id SET DEFAULT nextval('public."ActivityColumn_id_seq"'::regclass);


--
-- Name: ActivityTicket id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ActivityTicket" ALTER COLUMN id SET DEFAULT nextval('public."ActivityTicket_id_seq"'::regclass);


--
-- Name: CalendarEvent id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CalendarEvent" ALTER COLUMN id SET DEFAULT nextval('public."CalendarEvent_id_seq"'::regclass);


--
-- Name: CalendarEventAttachment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CalendarEventAttachment" ALTER COLUMN id SET DEFAULT nextval('public."CalendarEventAttachment_id_seq"'::regclass);


--
-- Name: CalendarEventComment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CalendarEventComment" ALTER COLUMN id SET DEFAULT nextval('public."CalendarEventComment_id_seq"'::regclass);


--
-- Name: CalendarEventType id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CalendarEventType" ALTER COLUMN id SET DEFAULT nextval('public."CalendarEventType_id_seq"'::regclass);


--
-- Name: CanonicalConfiguration id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CanonicalConfiguration" ALTER COLUMN id SET DEFAULT nextval('public."CanonicalConfiguration_id_seq"'::regclass);


--
-- Name: CmsEntry id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsEntry" ALTER COLUMN id SET DEFAULT nextval('public."CmsEntry_id_seq"'::regclass);


--
-- Name: CmsEntryAsset id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsEntryAsset" ALTER COLUMN id SET DEFAULT nextval('public."CmsEntryAsset_id_seq"'::regclass);


--
-- Name: CmsMedia id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsMedia" ALTER COLUMN id SET DEFAULT nextval('public."CmsMedia_id_seq"'::regclass);


--
-- Name: CmsPage id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsPage" ALTER COLUMN id SET DEFAULT nextval('public."CmsPage_id_seq"'::regclass);


--
-- Name: CmsPageAlias id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsPageAlias" ALTER COLUMN id SET DEFAULT nextval('public."CmsPageAlias_id_seq"'::regclass);


--
-- Name: CmsPageBlock id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsPageBlock" ALTER COLUMN id SET DEFAULT nextval('public."CmsPageBlock_id_seq"'::regclass);


--
-- Name: CmsPageSection id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsPageSection" ALTER COLUMN id SET DEFAULT nextval('public."CmsPageSection_id_seq"'::regclass);


--
-- Name: CmsSection id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsSection" ALTER COLUMN id SET DEFAULT nextval('public."CmsSection_id_seq"'::regclass);


--
-- Name: CompanyProfile id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CompanyProfile" ALTER COLUMN id SET DEFAULT nextval('public."CompanyProfile_id_seq"'::regclass);


--
-- Name: CurrencyRate id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CurrencyRate" ALTER COLUMN id SET DEFAULT nextval('public."CurrencyRate_id_seq"'::regclass);


--
-- Name: Customer id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Customer" ALTER COLUMN id SET DEFAULT nextval('public."Customer_id_seq"'::regclass);


--
-- Name: CustomerAddress id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerAddress" ALTER COLUMN id SET DEFAULT nextval('public."CustomerAddress_id_seq"'::regclass);


--
-- Name: CustomerEmailVerificationToken id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerEmailVerificationToken" ALTER COLUMN id SET DEFAULT nextval('public."CustomerEmailVerificationToken_id_seq"'::regclass);


--
-- Name: CustomerOAuthAccount id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerOAuthAccount" ALTER COLUMN id SET DEFAULT nextval('public."CustomerOAuthAccount_id_seq"'::regclass);


--
-- Name: CustomerOtpChallenge id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerOtpChallenge" ALTER COLUMN id SET DEFAULT nextval('public."CustomerOtpChallenge_id_seq"'::regclass);


--
-- Name: CustomerPhone id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerPhone" ALTER COLUMN id SET DEFAULT nextval('public."CustomerPhone_id_seq"'::regclass);


--
-- Name: CustomerReauthToken id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerReauthToken" ALTER COLUMN id SET DEFAULT nextval('public."CustomerReauthToken_id_seq"'::regclass);


--
-- Name: CustomerSecurityEvent id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerSecurityEvent" ALTER COLUMN id SET DEFAULT nextval('public."CustomerSecurityEvent_id_seq"'::regclass);


--
-- Name: CustomerStatus id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerStatus" ALTER COLUMN id SET DEFAULT nextval('public."CustomerStatus_id_seq"'::regclass);


--
-- Name: EmailLog id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailLog" ALTER COLUMN id SET DEFAULT nextval('public."EmailLog_id_seq"'::regclass);


--
-- Name: EmailSetting id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailSetting" ALTER COLUMN id SET DEFAULT nextval('public."EmailSetting_id_seq"'::regclass);


--
-- Name: EmailTemplate id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailTemplate" ALTER COLUMN id SET DEFAULT nextval('public."EmailTemplate_id_seq"'::regclass);


--
-- Name: Expense id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Expense" ALTER COLUMN id SET DEFAULT nextval('public."Expense_id_seq"'::regclass);


--
-- Name: ExpenseAttachment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExpenseAttachment" ALTER COLUMN id SET DEFAULT nextval('public."ExpenseAttachment_id_seq"'::regclass);


--
-- Name: ExpenseCategory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExpenseCategory" ALTER COLUMN id SET DEFAULT nextval('public."ExpenseCategory_id_seq"'::regclass);


--
-- Name: ExpenseStatus id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExpenseStatus" ALTER COLUMN id SET DEFAULT nextval('public."ExpenseStatus_id_seq"'::regclass);


--
-- Name: InboxMessageEvent id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InboxMessageEvent" ALTER COLUMN id SET DEFAULT nextval('public."InboxMessageEvent_id_seq"'::regclass);


--
-- Name: Notification id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification" ALTER COLUMN id SET DEFAULT nextval('public."Notification_id_seq"'::regclass);


--
-- Name: NotificationSetting id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NotificationSetting" ALTER COLUMN id SET DEFAULT nextval('public."NotificationSetting_id_seq"'::regclass);


--
-- Name: Order id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order" ALTER COLUMN id SET DEFAULT nextval('public."Order_id_seq"'::regclass);


--
-- Name: OrderItem id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderItem" ALTER COLUMN id SET DEFAULT nextval('public."OrderItem_id_seq"'::regclass);


--
-- Name: OrderTimelineEvent id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderTimelineEvent" ALTER COLUMN id SET DEFAULT nextval('public."OrderTimelineEvent_id_seq"'::regclass);


--
-- Name: PasswordResetToken id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordResetToken" ALTER COLUMN id SET DEFAULT nextval('public."PasswordResetToken_id_seq"'::regclass);


--
-- Name: Payment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payment" ALTER COLUMN id SET DEFAULT nextval('public."Payment_id_seq"'::regclass);


--
-- Name: PaymentAttachment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PaymentAttachment" ALTER COLUMN id SET DEFAULT nextval('public."PaymentAttachment_id_seq"'::regclass);


--
-- Name: PaymentPlan id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PaymentPlan" ALTER COLUMN id SET DEFAULT nextval('public."PaymentPlan_id_seq"'::regclass);


--
-- Name: PaymentPlanMilestone id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PaymentPlanMilestone" ALTER COLUMN id SET DEFAULT nextval('public."PaymentPlanMilestone_id_seq"'::regclass);


--
-- Name: Product id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product" ALTER COLUMN id SET DEFAULT nextval('public."Product_id_seq"'::regclass);


--
-- Name: ProductCategory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductCategory" ALTER COLUMN id SET DEFAULT nextval('public."ProductCategory_id_seq"'::regclass);


--
-- Name: ProductImage id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductImage" ALTER COLUMN id SET DEFAULT nextval('public."ProductImage_id_seq"'::regclass);


--
-- Name: ProductOption id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductOption" ALTER COLUMN id SET DEFAULT nextval('public."ProductOption_id_seq"'::regclass);


--
-- Name: ProductOptionValue id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductOptionValue" ALTER COLUMN id SET DEFAULT nextval('public."ProductOptionValue_id_seq"'::regclass);


--
-- Name: ProductRelation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductRelation" ALTER COLUMN id SET DEFAULT nextval('public."ProductRelation_id_seq"'::regclass);


--
-- Name: ProductReview id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductReview" ALTER COLUMN id SET DEFAULT nextval('public."ProductReview_id_seq"'::regclass);


--
-- Name: ProductVariant id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductVariant" ALTER COLUMN id SET DEFAULT nextval('public."ProductVariant_id_seq"'::regclass);


--
-- Name: ProductionOrder id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductionOrder" ALTER COLUMN id SET DEFAULT nextval('public."ProductionOrder_id_seq"'::regclass);


--
-- Name: Project id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Project" ALTER COLUMN id SET DEFAULT nextval('public."Project_id_seq"'::regclass);


--
-- Name: RoleNotificationRule id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RoleNotificationRule" ALTER COLUMN id SET DEFAULT nextval('public."RoleNotificationRule_id_seq"'::regclass);


--
-- Name: Setting id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Setting" ALTER COLUMN id SET DEFAULT nextval('public."Setting_id_seq"'::regclass);


--
-- Name: ShippingOption id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ShippingOption" ALTER COLUMN id SET DEFAULT nextval('public."ShippingOption_id_seq"'::regclass);


--
-- Name: StandardSize id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StandardSize" ALTER COLUMN id SET DEFAULT nextval('public."StandardSize_id_seq"'::regclass);


--
-- Name: Task id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Task" ALTER COLUMN id SET DEFAULT nextval('public."Task_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Name: UserActivity id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserActivity" ALTER COLUMN id SET DEFAULT nextval('public."UserActivity_id_seq"'::regclass);


--
-- Name: UserDevice id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserDevice" ALTER COLUMN id SET DEFAULT nextval('public."UserDevice_id_seq"'::regclass);


--
-- Name: Wishlist id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Wishlist" ALTER COLUMN id SET DEFAULT nextval('public."Wishlist_id_seq"'::regclass);


--
-- Name: WishlistItem id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WishlistItem" ALTER COLUMN id SET DEFAULT nextval('public."WishlistItem_id_seq"'::regclass);


--
-- Name: WorkOrder id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WorkOrder" ALTER COLUMN id SET DEFAULT nextval('public."WorkOrder_id_seq"'::regclass);


--
-- Name: abertura_glossary_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.abertura_glossary_items ALTER COLUMN id SET DEFAULT nextval('public.abertura_glossary_items_id_seq'::regclass);


--
-- Name: analytics_ads_daily_metrics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_ads_daily_metrics ALTER COLUMN id SET DEFAULT nextval('public.analytics_ads_daily_metrics_id_seq'::regclass);


--
-- Name: analytics_ga4_daily_metrics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_ga4_daily_metrics ALTER COLUMN id SET DEFAULT nextval('public.analytics_ga4_daily_metrics_id_seq'::regclass);


--
-- Name: analytics_report_rows id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_report_rows ALTER COLUMN id SET DEFAULT nextval('public.analytics_report_rows_id_seq'::regclass);


--
-- Name: analytics_reporting_daily id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_reporting_daily ALTER COLUMN id SET DEFAULT nextval('public.analytics_reporting_daily_id_seq'::regclass);


--
-- Name: analytics_search_console_daily_metrics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_search_console_daily_metrics ALTER COLUMN id SET DEFAULT nextval('public.analytics_search_console_daily_metrics_id_seq'::regclass);


--
-- Name: dimension_price_matrix id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dimension_price_matrix ALTER COLUMN id SET DEFAULT nextval('public.dimension_price_matrix_id_seq'::regclass);


--
-- Name: event_facts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_facts ALTER COLUMN id SET DEFAULT nextval('public.event_facts_id_seq'::regclass);


--
-- Name: otp_codes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_codes ALTER COLUMN id SET DEFAULT nextval('public.otp_codes_id_seq'::regclass);


--
-- Name: parametric_compatibility_rules id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parametric_compatibility_rules ALTER COLUMN id SET DEFAULT nextval('public.parametric_compatibility_rules_id_seq'::regclass);


--
-- Name: parametric_matrix_staging id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parametric_matrix_staging ALTER COLUMN id SET DEFAULT nextval('public.parametric_matrix_staging_id_seq'::regclass);


--
-- Name: security_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.security_events ALTER COLUMN id SET DEFAULT nextval('public.security_events_id_seq'::regclass);


--
-- Data for Name: ActivityColumn; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ActivityColumn" (id, title, "sortOrder", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ActivityTicket; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ActivityTicket" (id, "columnId", name, description, priority, labels, "dueDate", "order", cover, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ActivityTicketMember; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ActivityTicketMember" ("ticketId", "userId") FROM stdin;
\.


--
-- Data for Name: CalendarEvent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CalendarEvent" (id, title, description, type, "startAt", "endAt", "allDay", location, color, metadata, "createdById", "projectId", "taskId", "eventTypeId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CalendarEventAttachment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CalendarEventAttachment" (id, "eventId", name, "mimeType", size, content, "createdAt") FROM stdin;
\.


--
-- Data for Name: CalendarEventComment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CalendarEventComment" (id, "eventId", "userId", message, "createdAt") FROM stdin;
\.


--
-- Data for Name: CalendarEventType; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CalendarEventType" (id, name, color, description, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CanonicalConfiguration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CanonicalConfiguration" (id, "tenantId", "baseProductId", "configurationRules", "canonicalName", "baseLabel", slug, indexable, "seoTitle", "seoDescription", "searchTerms", "visibilityRules", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CmsEntry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CmsEntry" (id, "sectionId", slug, title, subtitle, description, payload, locale, status, priority, "isActive", "publishedAt", "startsAt", "endsAt", "thumbnailUrl", "ctaLabel", "ctaUrl", "productId", "categoryId", "createdAt", "updatedAt") FROM stdin;
1	1	home-story-cortinas-de-enrollar	Cortinas de enrollar	Obra nueva o recambio	Persianas en PVC o aluminio con opción manual o motorizada según uso, exposición y mantenimiento.	\N	es	PUBLISHED	80	t	2026-05-03 16:26:41.071	\N	\N	/uploads/cms/legacy-assets/img/portfolio/catalanas/catalanas.png	Ver cortinas de enrollar	/productos/cortinas-de-enrollar.html	\N	\N	2026-05-03 16:26:40.624	2026-05-03 16:26:41.072
2	1	home-story-aberturas-aluminio	Aberturas en aluminio	Puertas, ventanas y DVH	Una familia para obra y recambio con opciones de vidrio simple o doble vidriado hermético.	\N	es	PUBLISHED	70	t	2026-05-03 16:26:41.071	\N	\N	/uploads/cms/legacy-assets/img/aberturas/images.jpg	Ver aberturas	/productos/aberturas-aluminio.html	\N	\N	2026-05-03 16:26:40.627	2026-05-03 16:26:41.073
3	1	home-story-toldos-cerramientos	Toldos y cerramientos	Protección solar exterior	Toldos verticales, de brazo y cerramientos en PVC para sumar sombra, confort y uso exterior.	\N	es	PUBLISHED	60	t	2026-05-03 16:26:41.071	\N	\N	/uploads/cms/legacy-assets/img/portfolio/toldos/toldo.jpg	Ver toldos	/productos/toldos-y-cerramientos.html	\N	\N	2026-05-03 16:26:40.628	2026-05-03 16:26:41.075
4	1	home-story-motores	Motores y automatismos	Comodidad y uso diario	Automatización para cortinas roller, persianas y cortinas metálicas con mayor confort diario.	\N	es	PUBLISHED	50	t	2026-05-03 16:26:41.071	\N	\N	/uploads/cms/legacy-assets/img/portfolio/motores/persianas_motorizadas.jpg	Ver motores	/productos/motores-cortinas-y-persianas.html	\N	\N	2026-05-03 16:26:40.629	2026-05-03 16:26:41.076
5	1	home-story-cortinas-roller	Cortinas Roller	Interior moderno y funcional	Solución interior para regular luz y privacidad con una estética limpia en hogar u oficina.	\N	es	PUBLISHED	40	t	2026-05-03 16:26:41.071	\N	\N	/uploads/cms/legacy-assets/img/portfolio/roller/rollers.png	Ver cortinas roller	/productos/cortinas-roller.html	\N	\N	2026-05-03 16:26:40.63	2026-05-03 16:26:41.077
6	1	home-story-bandas-verticales	Bandas verticales	Ventanales amplios	Versatilidad y elegancia para oficinas, living y ventanales amplios con control de luz.	\N	es	PUBLISHED	30	t	2026-05-03 16:26:41.071	\N	\N	/uploads/cms/legacy-assets/img/portfolio/bandas_verticales/bandas_verticales_3.jpeg	Ver bandas verticales	/productos/bandas-verticales.html	\N	\N	2026-05-03 16:26:40.631	2026-05-03 16:26:41.078
7	1	home-story-venecianas	Cortinas Venecianas	Lamas 16 mm y 25 mm	Control de luz y privacidad con una terminación limpia para dormitorios, oficinas y espacios de uso diario.	\N	es	PUBLISHED	20	t	2026-05-03 16:26:41.071	\N	\N	/uploads/cms/legacy-assets/img/portfolio/venecianas/cortina_veneciana_4.jpeg	Ver venecianas	/productos/venecianas.html	\N	\N	2026-05-03 16:26:40.632	2026-05-03 16:26:41.079
8	1	home-story-cortinas-metalicas	Cortinas metálicas	Seguridad para accesos	Máxima seguridad para locales y accesos con una línea pensada para uso intensivo.	\N	es	PUBLISHED	10	t	2026-05-03 16:26:41.071	\N	\N	/uploads/cms/legacy-assets/img/portfolio/cortinas_metalicas/cortina_metalica_1.jpg	Ver cortinas metálicas	/productos/cortinas-metalicas.html	\N	\N	2026-05-03 16:26:40.633	2026-05-03 16:26:41.08
9	2	home-highlight-compra-segura	Visita y toma de medidas	Acompañamiento comercial real	Podemos coordinar una visita a domicilio para tomar medidas y orientar tu compra. En Montevideo la visita es sin costo.	\N	es	PUBLISHED	40	t	2026-05-03 16:26:41.071	\N	\N	/uploads/cms/legacy-assets/img/servicios/reparacion-cortinas/reparacion-persiana.jpeg	Solicitar visita	/contact	\N	\N	2026-05-03 16:26:40.634	2026-05-03 16:26:41.081
10	2	home-highlight-entrega-coordinada	Pagos y financiación	Medios de pago vigentes	Aceptamos transferencia, efectivo, Mercado Pago y tarjetas. Con Mercado Pago se puede pagar en cuotas, y las cortinas de enrollar cuentan con garantía de 2 años.	\N	es	PUBLISHED	30	t	2026-05-03 16:26:41.071	\N	\N	/uploads/cms/legacy-assets/img/mercadopago-img.jpg	Ver formas de pago	/contacto.html	\N	\N	2026-05-03 16:26:40.635	2026-05-03 16:26:41.082
11	2	home-highlight-reparacion	Reparación y mantenimiento	Resolver antes de reemplazar	Si el sistema todavía tiene arreglo, te orientamos sobre la reparación más conveniente.	\N	es	PUBLISHED	20	t	2026-05-03 16:26:41.071	\N	\N	/uploads/cms/legacy-assets/img/servicios/reparacion-cortinas/reparacion-persiana.jpeg	Solicitar reparación	/servicios/reparacion-cortinas-y-persianas.html	\N	\N	2026-05-03 16:26:40.636	2026-05-03 16:26:41.083
12	2	home-highlight-trabajos-medida	Trabajos a medida	Soluciones según el espacio	Fabricamos y adaptamos la solución al espacio real, al tipo de abertura y al uso diario.	\N	es	PUBLISHED	10	t	2026-05-03 16:26:41.071	\N	\N	/uploads/cms/legacy-assets/img/intro-carousel/cerramiento-pvc.jpeg	Pedir presupuesto	/contacto.html	\N	\N	2026-05-03 16:26:40.637	2026-05-03 16:26:41.084
\.


--
-- Data for Name: CmsEntryAsset; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CmsEntryAsset" (id, "entryId", title, caption, "mediaType", "mediaUrl", "posterUrl", "externalUrl", "durationSec", "sortOrder", "isActive", "createdAt", "updatedAt") FROM stdin;
13	1	Cortinas de enrollar	Una solución práctica para frentes, hogares y comercios.	IMAGE	/uploads/cms/legacy-assets/img/portfolio/catalanas/catalanas.png	/uploads/cms/legacy-assets/img/portfolio/catalanas/catalanas.png	\N	\N	0	t	2026-05-03 16:26:41.073	2026-05-03 16:26:41.073
14	2	Aberturas en aluminio	Soluciones de alto uso para hogares, comercios y proyectos a medida.	IMAGE	/uploads/cms/legacy-assets/img/aberturas/images.jpg	/uploads/cms/legacy-assets/img/aberturas/images.jpg	\N	\N	0	t	2026-05-03 16:26:41.074	2026-05-03 16:26:41.074
15	3	Toldos y cerramientos	Protección solar y solución exterior para distintos usos.	IMAGE	/uploads/cms/legacy-assets/img/portfolio/toldos/toldo.jpg	/uploads/cms/legacy-assets/img/portfolio/toldos/toldo.jpg	\N	\N	0	t	2026-05-03 16:26:41.075	2026-05-03 16:26:41.075
16	4	Motores y automatismos	Automatización inteligente para más confort y uso diario.	IMAGE	/uploads/cms/legacy-assets/img/portfolio/motores/persianas_motorizadas.jpg	/uploads/cms/legacy-assets/img/portfolio/motores/persianas_motorizadas.jpg	\N	\N	0	t	2026-05-03 16:26:41.077	2026-05-03 16:26:41.077
17	5	Cortinas Roller	Soluciones para ambientes que necesitan control de luz y un acabado limpio.	IMAGE	/uploads/cms/legacy-assets/img/portfolio/roller/rollers.png	/uploads/cms/legacy-assets/img/portfolio/roller/rollers.png	\N	\N	0	t	2026-05-03 16:26:41.078	2026-05-03 16:26:41.078
18	6	Bandas verticales	Ideales para ventanales amplios, oficinas y living.	IMAGE	/uploads/cms/legacy-assets/img/portfolio/bandas_verticales/bandas_verticales_3.jpeg	/uploads/cms/legacy-assets/img/portfolio/bandas_verticales/bandas_verticales_3.jpeg	\N	\N	0	t	2026-05-03 16:26:41.079	2026-05-03 16:26:41.079
19	7	Cortinas Venecianas	Lamas de 16 mm y 25 mm para controlar luz y privacidad.	IMAGE	/uploads/cms/legacy-assets/img/portfolio/venecianas/cortina_veneciana_4.jpeg	/uploads/cms/legacy-assets/img/portfolio/venecianas/cortina_veneciana_4.jpeg	\N	\N	0	t	2026-05-03 16:26:41.08	2026-05-03 16:26:41.08
20	8	Cortinas metálicas	Máxima seguridad para locales y accesos.	IMAGE	/uploads/cms/legacy-assets/img/portfolio/cortinas_metalicas/cortina_metalica_1.jpg	/uploads/cms/legacy-assets/img/portfolio/cortinas_metalicas/cortina_metalica_1.jpg	\N	\N	0	t	2026-05-03 16:26:41.081	2026-05-03 16:26:41.081
21	9	Visita y toma de medidas	Coordinamos la visita a domicilio para tomar medidas y revisar el producto adecuado antes de avanzar.	IMAGE	/uploads/cms/legacy-assets/img/servicios/reparacion-cortinas/reparacion-persiana.jpeg	/uploads/cms/legacy-assets/img/servicios/reparacion-cortinas/reparacion-persiana.jpeg	\N	\N	0	t	2026-05-03 16:26:41.082	2026-05-03 16:26:41.082
22	10	Pagos y garantía	Formas de pago flexibles y garantía clara para cortinas de enrollar y soluciones afines.	IMAGE	/uploads/cms/legacy-assets/img/mercadopago-img.jpg	/uploads/cms/legacy-assets/img/mercadopago-img.jpg	\N	\N	0	t	2026-05-03 16:26:41.083	2026-05-03 16:26:41.083
23	11	Reparación y mantenimiento	Recuperá la operatividad con una intervención clara y enfocada en el uso diario.	IMAGE	/uploads/cms/legacy-assets/img/servicios/reparacion-cortinas/reparacion-persiana.jpeg	/uploads/cms/legacy-assets/img/servicios/reparacion-cortinas/reparacion-persiana.jpeg	\N	\N	0	t	2026-05-03 16:26:41.084	2026-05-03 16:26:41.084
24	12	Trabajos a medida	La solución se adapta al espacio real y al uso diario.	IMAGE	/uploads/cms/legacy-assets/img/intro-carousel/cerramiento-pvc.jpeg	/uploads/cms/legacy-assets/img/intro-carousel/cerramiento-pvc.jpeg	\N	\N	0	t	2026-05-03 16:26:41.085	2026-05-03 16:26:41.085
\.


--
-- Data for Name: CmsMedia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CmsMedia" (id, url, type, alt, title, "mimeType", "fileName", "sizeBytes", width, height, source, metadata, "isActive", "createdAt", "updatedAt") FROM stdin;
4	/assets/images/banners/banner-14.jpg	IMAGE	Banner visual	Visual merchandising	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.612	2026-05-03 16:26:40.612
9	/assets/images/banners/long-banner.jpg	IMAGE	Banner largo	Full width visual	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.614	2026-05-03 16:26:40.614
10	/assets/images/categories/cat-1.jpg	IMAGE	Categoría 1	Categoría	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.615	2026-05-03 16:26:40.615
11	/assets/images/categories/cat-2.jpg	IMAGE	Categoría 2	Categoría	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.615	2026-05-03 16:26:40.615
12	/assets/images/categories/cat-3.jpg	IMAGE	Categoría 3	Categoría	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.616	2026-05-03 16:26:40.616
13	/assets/images/categories/cat-4.jpg	IMAGE	Categoría 4	Categoría	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.616	2026-05-03 16:26:40.616
14	/assets/images/categories/cat-5.jpg	IMAGE	Categoría 5	Categoría	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.617	2026-05-03 16:26:40.617
15	/assets/images/categories/cat-6.jpg	IMAGE	Categoría 6	Categoría	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.617	2026-05-03 16:26:40.617
20	/assets/images/products/mobile-1.png	IMAGE	Mobile phone	Mobile	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.619	2026-05-03 16:26:40.619
21	/assets/images/products/mobile-2.png	IMAGE	Mobile phone alt	Mobile alt	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.62	2026-05-03 16:26:40.62
23	/assets/images/products/smartwatch-2.png	IMAGE	Smartwatch	Smartwatch	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.62	2026-05-03 16:26:40.62
24	/assets/images/products/ring-1.png	IMAGE	Accessory	Accessory	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.621	2026-05-03 16:26:40.621
27	/assets/images/products/bg-gradient.png	IMAGE	Gradient background	Gradient	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.622	2026-05-03 16:26:40.622
31	/media/products/bandas-verticales/images/WhatsApp Image 2020-07-10 at 13.53.45.jpeg	IMAGE	Bandas verticales	Bandas verticales	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.649	2026-05-03 16:26:40.672
35	/uploads/cms/legacy-assets/img/mercadopago-img.jpg	IMAGE	Mercado Pago	Mercado Pago	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.653	2026-05-03 16:26:40.653
36	/uploads/cms/legacy-assets/img/portfolio/catalanas/catalana_2.jpeg	IMAGE	Garantía según producto	Garantía según producto	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.654	2026-05-03 16:26:40.654
34	/uploads/cms/legacy-assets/img/servicios/reparacion-cortinas/reparacion-persiana.jpeg	IMAGE	Instalación y mantenimiento	Instalación y mantenimiento	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.652	2026-05-03 16:26:40.654
37	/uploads/cms/legacy-assets/img/clientes/bostonclarks.png	IMAGE	Boston Clarks	Boston Clarks	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.656	2026-05-03 16:26:40.656
38	/uploads/cms/legacy-assets/img/clientes/eldorado.png	IMAGE	El Dorado	El Dorado	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.657	2026-05-03 16:26:40.657
39	/uploads/cms/legacy-assets/img/clientes/laespanola.jpg	IMAGE	La Española	La Española	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.658	2026-05-03 16:26:40.658
40	/uploads/cms/legacy-assets/img/clientes/montecon.png	IMAGE	Montecon	Montecon	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.659	2026-05-03 16:26:40.659
41	/uploads/cms/legacy-assets/img/clientes/cousa.jpg	IMAGE	Cousa	Cousa	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.659	2026-05-03 16:26:40.659
42	/uploads/cms/legacy-assets/img/clientes/conatel.png	IMAGE	Conatel	Conatel	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.66	2026-05-03 16:26:40.66
43	/uploads/cms/legacy-assets/img/clientes/suat.png	IMAGE	SUAT	SUAT	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.661	2026-05-03 16:26:40.661
28	/media/products/cortinas-de-enrollar-aluminio/images/catalana_1.jpeg	IMAGE	Instalación	Instalación	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.644	2026-05-03 16:26:40.798
29	/media/products/aberturas-aluminio/images/aberturas__32807525_580319532349310_975320518108381184_n.jpg	IMAGE	Alta prestación	Alta prestación	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.645	2026-05-03 16:26:40.721
25	/assets/images/products/clothes.png	IMAGE	Ventana Corrediza 20 Blanco 3mm 1500x1500 editorial	Ventana Corrediza 20 Blanco 3mm 1500x1500 editorial	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.621	2026-05-03 16:26:40.856
32	/media/products/venecianas/images/cortina_veneciana_1.jpeg	IMAGE	Cortinas Venecianas	Cortinas Venecianas	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.65	2026-05-03 16:26:40.672
17	/assets/images/stories/story-home-2.jpg	IMAGE	Diseño que se entiende rápido	Diseño	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.618	2026-05-03 16:26:40.828
33	/media/products/cortinas-metalicas/images/WhatsApp Image 2025-11-06 at 14.18.59.jpeg	IMAGE	Repuestos	Repuestos	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.651	2026-05-03 16:26:40.797
46	/uploads/cms/legacy-assets/img/aberturas/probba_sistema.png	IMAGE	Serie Probba de aberturas de aluminio	Serie Probba de aberturas de aluminio	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.724	2026-05-03 16:26:40.724
30	/media/products/cortinas-roller/images/20211218_193930.jpg	IMAGE	Diagnóstico	Diagnóstico	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.647	2026-05-03 16:26:40.796
16	/assets/images/stories/story-home-1.jpg	IMAGE	Diseño que se entiende rápido	Diseño	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.617	2026-05-03 16:26:40.818
7	/assets/images/banners/banner-18.jpg	IMAGE	Detalle secundario	Detalle secundario	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.613	2026-05-03 16:26:40.832
19	/assets/images/products/bghead-phone.png	IMAGE	Producto Variable QA API 2 editorial	Producto Variable QA API 2 editorial	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.619	2026-05-03 16:26:40.823
8	/assets/images/banners/banner-19.jpg	IMAGE	Ventana Corrediza 20 Blanco 3mm 1400x600 detalle	Ventana Corrediza 20 Blanco 3mm 1400x600 detalle	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.614	2026-05-03 16:26:40.845
18	/assets/images/stories/story-home-3.jpg	IMAGE	Diseño que se entiende rápido	Diseño	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.618	2026-05-03 16:26:40.838
3	/assets/images/banners/banner-21.jpg	IMAGE	Detalle secundario	Detalle secundario	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.611	2026-05-03 16:26:40.842
5	/assets/images/banners/banner-16.jpg	IMAGE	Ventana Corrediza 20 Blanco 3mm 1200x2000 detalle	Ventana Corrediza 20 Blanco 3mm 1200x2000 detalle	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.612	2026-05-03 16:26:40.834
1	/assets/images/banners/banner-23.jpg	IMAGE	Ventana Corrediza 20 Blanco 3mm 1500x1500 lifestyle	Ventana Corrediza 20 Blanco 3mm 1500x1500 lifestyle	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.61	2026-05-03 16:26:40.858
22	/assets/images/products/watch.png	IMAGE	Ventana Corrediza 20 Blanco 3mm 1400x600 editorial	Ventana Corrediza 20 Blanco 3mm 1400x600 editorial	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.62	2026-05-03 16:26:40.843
2	/assets/images/banners/banner-24.jpg	IMAGE	Ventana Corrediza 20 Blanco 3mm 1500x2000 detalle	Ventana Corrediza 20 Blanco 3mm 1500x2000 detalle	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.61	2026-05-03 16:26:40.867
47	/uploads/cms/legacy-assets/img/aberturas/probba_ventana_y_puerta_corrediza2.jpg	IMAGE	Ventana y puerta corrediza Probba	Ventana y puerta corrediza	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.727	2026-05-03 16:26:40.727
48	/uploads/cms/legacy-assets/img/aberturas/probba_ventana_batiente.jpg	IMAGE	Ventana batiente Probba	Ventana batiente	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.728	2026-05-03 16:26:40.728
49	/uploads/cms/legacy-assets/img/aberturas/probba_ventana_oscilobatiente.jpg	IMAGE	Ventana oscilobatiente Probba	Ventana oscilobatiente	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.729	2026-05-03 16:26:40.729
50	/uploads/cms/legacy-assets/img/aberturas/probba_ventana_banderola.jpg	IMAGE	Ventana banderola Probba	Ventana banderola	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.73	2026-05-03 16:26:40.73
51	/uploads/cms/legacy-assets/img/aberturas/probba_ventana_proyectante.jpg	IMAGE	Ventana proyectante Probba	Ventana proyectante	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.73	2026-05-03 16:26:40.73
52	/uploads/cms/legacy-assets/img/aberturas/probba_ventana_proyeccion_y_desliz.jpg	IMAGE	Ventana proyección y desliz Probba	Proyección y desliz	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.731	2026-05-03 16:26:40.731
53	/uploads/cms/legacy-assets/img/aberturas/probba_puerta_batiente.jpg	IMAGE	Puerta batiente Probba	Puerta batiente	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.732	2026-05-03 16:26:40.732
54	/uploads/cms/legacy-assets/img/aberturas/probba_pano_fijo.jpg	IMAGE	Paño fijo Probba	Paño fijo	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.733	2026-05-03 16:26:40.733
56	/uploads/cms/legacy-assets/img/aberturas/parrafo_gala-subsistema.jpg	IMAGE	Confort Gala	Confort y aislamiento	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.739	2026-05-03 16:26:40.739
55	/uploads/cms/legacy-assets/img/aberturas/gala_sistema.png	IMAGE	Terminación Gala	Terminación estética	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.737	2026-05-03 16:26:40.74
57	/uploads/cms/legacy-assets/img/aberturas/gala_cr_parrafo.jpg	IMAGE	Gala CR	Gala CR	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.74	2026-05-03 16:26:40.74
58	/uploads/cms/legacy-assets/img/aberturas/gala_bg_prod.jpg	IMAGE	Accesorios Gala	Accesorios europeos	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.741	2026-05-03 16:26:40.741
59	/uploads/cms/legacy-assets/img/aberturas/summa_sistema.png	IMAGE	Serie Summa de aberturas de aluminio	Serie Summa de aberturas de aluminio	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.745	2026-05-03 16:26:40.745
60	/uploads/cms/legacy-assets/img/aberturas/ventana_y_puerta_corrediza2.jpg	IMAGE	Corredizas Summa	Corredizas 2 y 3 rieles	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.747	2026-05-03 16:26:40.747
61	/uploads/cms/legacy-assets/img/aberturas/summa_alzante_parrafo.jpg	IMAGE	Summa Alzante	Summa Alzante	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.748	2026-05-03 16:26:40.748
62	/uploads/cms/legacy-assets/img/aberturas/summa_rpt.jpg	IMAGE	Summa Comfort RPT	Summa Comfort RPT	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.749	2026-05-03 16:26:40.749
63	/uploads/cms/legacy-assets/img/aberturas/summa_terminaciones_2025.jpg	IMAGE	Terminaciones Summa	Terminaciones disponibles	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.749	2026-05-03 16:26:40.749
75	/uploads/cms/legacy-assets/img/portfolio/roller/rollers.png	IMAGE	Cortinas Roller	Cortinas Roller	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.807	2026-05-03 16:26:40.807
67	/uploads/cms/legacy-assets/img/portfolio/motores/persianas_motorizadas.jpg	IMAGE	Motores y automatismos	Motores y automatismos	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.77	2026-05-03 16:26:40.809
65	/uploads/cms/legacy-assets/img/portfolio/roller/cortinas_roller_2.jpeg	IMAGE	Roller screen	Screen	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.765	2026-05-03 16:26:40.765
66	/uploads/cms/legacy-assets/img/portfolio/roller/cortinas_roller_3.jpeg	IMAGE	Roller blackout	Blackout	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.766	2026-05-03 16:26:40.766
64	/uploads/cms/legacy-assets/img/portfolio/roller/cortinas_roller_4.jpeg	IMAGE	Roller doble	Roller doble	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.763	2026-05-03 16:26:40.767
68	/uploads/cms/legacy-assets/img/portfolio/motores/motor_cortina_1.jpg	IMAGE	Control remoto	Control remoto	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.772	2026-05-03 16:26:40.772
69	/uploads/cms/legacy-assets/img/portfolio/motores/motor_cortina_2.png	IMAGE	Botonera	Botonera	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.773	2026-05-03 16:26:40.773
80	/assets/images/banners/banner-12.jpg	IMAGE	Producto Variable QA API 2 lifestyle	Producto Variable QA API 2 lifestyle	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.82	2026-05-03 16:26:40.825
71	/uploads/cms/legacy-assets/img/portfolio/bandas_verticales/banda_vertical_2.jpeg	IMAGE	Bandas blackout	Blackout	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.78	2026-05-03 16:26:40.78
76	/uploads/cms/legacy-assets/img/portfolio/toldos/toldo.jpg	IMAGE	Toldos y cerramientos	Toldos y cerramientos	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.811	2026-05-03 16:26:40.811
72	/uploads/cms/legacy-assets/img/portfolio/bandas_verticales/bandas_7.jpeg	IMAGE	Bandas poliéster	Poliéster	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.782	2026-05-03 16:26:40.782
45	/media/products/cortinas-de-enrollar-aluminio/images/IMG-20240826-WA0159.jpg	IMAGE	PVC	PVC	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.677	2026-05-03 16:26:40.788
73	/uploads/cms/legacy-assets/img/portfolio/cortinas_metalicas/cortina_metalica_1.jpg	IMAGE	Cortinas metálicas	Cortinas metálicas	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.801	2026-05-03 16:26:40.801
74	/uploads/cms/legacy-assets/img/portfolio/venecianas/cortina_veneciana_4.jpeg	IMAGE	Cortinas Venecianas	Cortinas Venecianas	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.803	2026-05-03 16:26:40.803
70	/uploads/cms/legacy-assets/img/portfolio/bandas_verticales/bandas_verticales_3.jpeg	IMAGE	Bandas verticales	Bandas verticales	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.778	2026-05-03 16:26:40.805
77	/uploads/cms/legacy-assets/img/aberturas/images.jpg	IMAGE	Aberturas en aluminio	Aberturas en aluminio	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.813	2026-05-03 16:26:40.813
78	/uploads/cms/legacy-assets/img/portfolio/catalanas/catalanas.png	IMAGE	Cortinas de enrollar	Cortinas de enrollar	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.815	2026-05-03 16:26:40.815
81	/assets/images/banners/banner-13.jpg	IMAGE	Detalle secundario	Detalle secundario	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.822	2026-05-03 16:26:40.822
79	/assets/images/banners/banner-11.jpg	IMAGE	Producto Variable QA API 2 detalle	Producto Variable QA API 2 detalle	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.819	2026-05-03 16:26:40.824
82	/assets/images/banners/banner-15.jpg	IMAGE	Ventana Corrediza 20 Blanco 3mm 1200x2000 editorial	Ventana Corrediza 20 Blanco 3mm 1200x2000 editorial	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.827	2026-05-03 16:26:40.833
6	/assets/images/banners/banner-17.jpg	IMAGE	Ventana Corrediza 20 Blanco 3mm 1200x2000 lifestyle	Ventana Corrediza 20 Blanco 3mm 1200x2000 lifestyle	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.613	2026-05-03 16:26:40.835
83	/assets/images/banners/banner-20.jpg	IMAGE	Ventana Corrediza 20 Blanco 3mm 1400x600 lifestyle	Ventana Corrediza 20 Blanco 3mm 1400x600 lifestyle	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.84	2026-05-03 16:26:40.846
84	/assets/images/banners/banner-22.jpg	IMAGE	Ventana Corrediza 20 Blanco 3mm 1500x1500 detalle	Ventana Corrediza 20 Blanco 3mm 1500x1500 detalle	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.85	2026-05-03 16:26:40.857
44	https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4	VIDEO	Ventana Corrediza 20 Blanco 3mm 1500x2000 en uso	Ventana Corrediza 20 Blanco 3mm 1500x2000 video	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.669	2026-05-03 16:26:40.864
86	/assets/images/banners/banner-1.png	IMAGE	Detalle secundario	Detalle secundario	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.865	2026-05-03 16:26:40.865
26	/assets/images/products/gaming-gear.png	IMAGE	Ventana Corrediza 20 Blanco 3mm 1500x2000 editorial	Ventana Corrediza 20 Blanco 3mm 1500x2000 editorial	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.622	2026-05-03 16:26:40.866
85	/assets/images/banners/banner-25.jpg	IMAGE	Ventana Corrediza 20 Blanco 3mm 1500x2000 lifestyle	Ventana Corrediza 20 Blanco 3mm 1500x2000 lifestyle	\N	\N	\N	\N	\N	marketing_cms_seed	null	t	2026-05-03 16:26:40.861	2026-05-03 16:26:40.868
\.


--
-- Data for Name: CmsPage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CmsPage" (id, path, title, summary, scope, locale, status, visible, "seoTitle", "seoDescription", "seoImageUrl", "layoutKey", "legacySource", "createdAt", "updatedAt") FROM stdin;
1		Urucortinas	Soluciones a medida en cortinas roller, persianas, toldos, aberturas y automatización con instalación, reparación y seguimiento comercial.	GENERAL_SITE	es	PUBLISHED	t	Urucortinas | Cortinas, persianas, toldos y aberturas a medida	Cortinas roller, cortinas de enrollar, bandas verticales, venecianas, toldos y aberturas en aluminio con instalación, mantenimiento y reparación.	/uploads/cms/legacy-assets/img/intro-carousel/roller-6.jpeg	landing-default	marketing_cms_seed	2026-05-03 16:26:40.64	2026-05-03 16:26:40.64
2	categories	Categorías para decidir más rápido	Una landing visual para entrar por necesidad, uso y contexto antes de avanzar al catálogo.	GENERAL_SITE	es	PUBLISHED	t	Categorías de productos | Urucortinas	Explorá cortinas de enrollar, aberturas, toldos, motores y soluciones para interior y exterior.	/media/products/aberturas-aluminio/images/aberturas__32807525_580319532349310_975320518108381184_n.jpg	landing-default	marketing_cms_seed	2026-05-03 16:26:40.663	2026-05-03 16:26:40.663
3	guias/cortinas-pvc-vs-aluminio	PVC vs aluminio en cortinas de enrollar	Comparativa clara para elegir entre practicidad, resistencia y mantenimiento.	GENERAL_SITE	es	PUBLISHED	t	PVC vs aluminio en cortinas de enrollar | Urucortinas	Compará cortinas de enrollar en PVC y aluminio para elegir la mejor opción según uso, exposición y mantenimiento.	/media/products/cortinas-de-enrollar-aluminio/images/catalana_1.jpeg	landing-default	marketing_cms_seed	2026-05-03 16:26:40.674	2026-05-03 16:26:40.674
4	guias/dvh	Qué es DVH y cuándo conviene	Una guía simple para entender el doble vidriado hermético en aberturas de aluminio.	GENERAL_SITE	es	PUBLISHED	t	Qué es DVH y cuándo conviene | Urucortinas	Descubrí qué aporta el doble vidriado hermético, en qué casos conviene y cómo impacta en confort térmico y acústico.	/media/products/aberturas-aluminio/images/aberturas__32807525_580319532349310_975320518108381184_n.jpg	landing-default	marketing_cms_seed	2026-05-03 16:26:40.681	2026-05-03 16:26:40.681
5	guias/probba-vs-gala	Probba, Gala y serie 25	Una guía breve para elegir la mejor abertura en aluminio sin ruido técnico innecesario.	GENERAL_SITE	es	PUBLISHED	t	Probba vs Gala | Serie 20 y 25 en aberturas de aluminio	Entendé cómo elegir entre Probba, Gala, Serie 20 y Serie 25 según uso, apertura y nivel de prestación.	/media/products/aberturas-aluminio/images/aberturas__32807525_580319532349310_975320518108381184_n.jpg	landing-default	marketing_cms_seed	2026-05-03 16:26:40.716	2026-05-03 16:26:40.716
6	guias/aberturas-probba	Serie Probba: tipologías y terminaciones	Guía informacional con tipologías, medidas y terminaciones de la serie Probba.	GENERAL_SITE	es	PUBLISHED	t	Serie Probba: tipologías, medidas y colores | Urucortinas	Conocé las tipologías, medidas y terminaciones de la serie Probba para elegir mejor según tu proyecto.	/uploads/cms/legacy-assets/img/aberturas/probba_sistema.png	landing-default	marketing_cms_seed	2026-05-03 16:26:40.723	2026-05-03 16:26:40.723
7	guias/aberturas-gala	Serie Gala: confort y terminaciones	Guía informacional sobre la serie Gala, su confort y su variante Gala CR.	GENERAL_SITE	es	PUBLISHED	t	Serie Gala: confort y terminaciones | Urucortinas	Conocé la serie Gala, su aislamiento térmico y acústico, la variante Gala CR y cómo leer sus terminaciones.	/uploads/cms/legacy-assets/img/aberturas/gala_sistema.png	landing-default	marketing_cms_seed	2026-05-03 16:26:40.735	2026-05-03 16:26:40.735
8	guias/aberturas-summa	Serie Summa: tipologías y terminaciones premium	Guía informacional con tipologías, terminaciones y variantes premium de Summa.	GENERAL_SITE	es	PUBLISHED	t	Serie Summa: tipologías y terminaciones premium | Urucortinas	Conocé la serie Summa, sus tipologías corredizas, terminaciones disponibles y las variantes Alzante y Comfort RPT.	/uploads/cms/legacy-assets/img/aberturas/summa_sistema.png	landing-default	marketing_cms_seed	2026-05-03 16:26:40.744	2026-05-03 16:26:40.744
9	guias/como-medir-ancho-y-alto	Cómo medir ancho y alto sin errores	Una guía práctica para pedir presupuesto con menos fricción y menos correcciones.	GENERAL_SITE	es	PUBLISHED	t	Cómo medir ancho y alto | Urucortinas	Aprendé a tomar medidas de ancho y alto para cortinas, persianas y aberturas antes de pedir presupuesto.	/media/products/cortinas-de-enrollar-aluminio/images/IMG-20240826-WA0159.jpg	landing-default	marketing_cms_seed	2026-05-03 16:26:40.752	2026-05-03 16:26:40.752
10	guias/cortinas-roller	Cortinas roller: screen, blackout y doble	Guía para elegir la variante roller que mejor encaja con cada ambiente.	GENERAL_SITE	es	PUBLISHED	t	Cortinas roller: screen, blackout y doble | Urucortinas	Elegí cortinas roller screen, blackout o doble según la luz, la privacidad y el uso real del ambiente.	/uploads/cms/legacy-assets/img/portfolio/roller/cortinas_roller_4.jpeg	landing-default	marketing_cms_seed	2026-05-03 16:26:40.761	2026-05-03 16:26:40.761
11	guias/motores-cortinas-y-persianas	Motores para cortinas y persianas	Guía para elegir automatización según rutina, tamaño y nivel de confort.	GENERAL_SITE	es	PUBLISHED	t	Motores para cortinas y persianas | Urucortinas	Descubrí cómo elegir motores para cortinas y persianas según control remoto, botonera, app o domótica.	/uploads/cms/legacy-assets/img/portfolio/motores/persianas_motorizadas.jpg	landing-default	marketing_cms_seed	2026-05-03 16:26:40.769	2026-05-03 16:26:40.769
12	guias/bandas-verticales	Bandas verticales: materiales y usos	Guía para elegir bandas verticales según luz, ancho del frente y uso real.	GENERAL_SITE	es	PUBLISHED	t	Bandas verticales | Materiales y usos - Urucortinas	Elegí bandas verticales en blackout, screen o poliéster según luz, superficie y nivel de privacidad.	/uploads/cms/legacy-assets/img/portfolio/bandas_verticales/bandas_verticales_3.jpeg	landing-default	marketing_cms_seed	2026-05-03 16:26:40.777	2026-05-03 16:26:40.777
13	precios/cortinas-de-enrollar	Precios de cortinas de enrollar	Una guía para entender por qué dos cortinas similares pueden cotizar distinto.	GENERAL_SITE	es	PUBLISHED	t	Precios de cortinas de enrollar | Urucortinas	Entendé qué influye en el precio de una cortina de enrollar: material, medidas, motorización e instalación.	/media/products/cortinas-de-enrollar-aluminio/images/catalana_1.jpeg	landing-default	marketing_cms_seed	2026-05-03 16:26:40.784	2026-05-03 16:26:40.784
14	servicios/reparacion-cortinas-y-persianas.html	Reparación de cortinas y persianas	Resolver antes de reemplazar cuando el sistema todavía tiene arreglo.	GENERAL_SITE	es	PUBLISHED	t	Reparación de cortinas y persianas | Urucortinas	Servicio de reparación de cortinas y persianas con diagnóstico, repuestos e instalación para resolver antes de reemplazar.	/media/products/cortinas-metalicas/images/WhatsApp Image 2025-11-06 at 14.18.59.jpeg	landing-default	marketing_cms_seed	2026-05-03 16:26:40.793	2026-05-03 16:26:40.793
15	stories/home-story-cortinas-metalicas	Cortinas metálicas	Seguridad para accesos	GENERAL_SITE	es	PUBLISHED	t	Cortinas metálicas | Historias	Máxima seguridad para locales y accesos con una línea pensada para uso intensivo.	/uploads/cms/legacy-assets/img/portfolio/cortinas_metalicas/cortina_metalica_1.jpg	landing-default	marketing_cms_seed	2026-05-03 16:26:40.8	2026-05-03 16:26:40.8
16	stories/home-story-venecianas	Cortinas Venecianas	Lamas 16 mm y 25 mm	GENERAL_SITE	es	PUBLISHED	t	Cortinas Venecianas | Historias	Control de luz y privacidad con una terminación limpia para dormitorios, oficinas y espacios de uso diario.	/uploads/cms/legacy-assets/img/portfolio/venecianas/cortina_veneciana_4.jpeg	landing-default	marketing_cms_seed	2026-05-03 16:26:40.802	2026-05-03 16:26:40.802
17	stories/home-story-bandas-verticales	Bandas verticales	Ventanales amplios	GENERAL_SITE	es	PUBLISHED	t	Bandas verticales | Historias	Versatilidad y elegancia para oficinas, living y ventanales amplios con control de luz.	/uploads/cms/legacy-assets/img/portfolio/bandas_verticales/bandas_verticales_3.jpeg	landing-default	marketing_cms_seed	2026-05-03 16:26:40.804	2026-05-03 16:26:40.804
18	stories/home-story-cortinas-roller	Cortinas Roller	Interior moderno y funcional	GENERAL_SITE	es	PUBLISHED	t	Cortinas Roller | Historias	Solución interior para regular luz y privacidad con una estética limpia en hogar u oficina.	/uploads/cms/legacy-assets/img/portfolio/roller/rollers.png	landing-default	marketing_cms_seed	2026-05-03 16:26:40.806	2026-05-03 16:26:40.806
19	stories/home-story-motores	Motores y automatismos	Comodidad y uso diario	GENERAL_SITE	es	PUBLISHED	t	Motores y automatismos | Historias	Automatización para cortinas roller, persianas y cortinas metálicas con mayor confort diario.	/uploads/cms/legacy-assets/img/portfolio/motores/persianas_motorizadas.jpg	landing-default	marketing_cms_seed	2026-05-03 16:26:40.808	2026-05-03 16:26:40.808
20	stories/home-story-toldos-cerramientos	Toldos y cerramientos	Protección solar exterior	GENERAL_SITE	es	PUBLISHED	t	Toldos y cerramientos | Historias	Toldos verticales, de brazo y cerramientos en PVC para sumar sombra, confort y uso exterior.	/uploads/cms/legacy-assets/img/portfolio/toldos/toldo.jpg	landing-default	marketing_cms_seed	2026-05-03 16:26:40.81	2026-05-03 16:26:40.81
21	stories/home-story-aberturas-aluminio	Aberturas en aluminio	Puertas, ventanas y DVH	GENERAL_SITE	es	PUBLISHED	t	Aberturas en aluminio | Historias	Una familia para obra y recambio con opciones de vidrio simple o doble vidriado hermético.	/uploads/cms/legacy-assets/img/aberturas/images.jpg	landing-default	marketing_cms_seed	2026-05-03 16:26:40.812	2026-05-03 16:26:40.812
22	stories/home-story-cortinas-de-enrollar	Cortinas de enrollar	Obra nueva o recambio	GENERAL_SITE	es	PUBLISHED	t	Cortinas de enrollar | Historias	Persianas en PVC o aluminio con opción manual o motorizada según uso, exposición y mantenimiento.	/uploads/cms/legacy-assets/img/portfolio/catalanas/catalanas.png	landing-default	marketing_cms_seed	2026-05-03 16:26:40.814	2026-05-03 16:26:40.814
23	product/qa-var-003	Producto Variable QA API 2	Landing de producto con foco en tecnología, detalle y prueba visual.	GENERAL_SITE	es	PUBLISHED	t	Producto Variable QA API 2 | Experiencia visual de producto	Landing de producto con foco en tecnología, detalle y prueba visual.	/assets/images/products/bghead-phone.png	landing-default	marketing_cms_seed	2026-05-03 16:26:40.816	2026-05-03 16:26:40.816
24	product/ventana-corrediza-20-blanco-3mm-1200x2000	Ventana Corrediza 20 Blanco 3mm 1200x2000	Landing de producto orientada a performance y credibilidad visual.	GENERAL_SITE	es	PUBLISHED	t	Ventana Corrediza 20 Blanco 3mm 1200x2000 | Experiencia visual de producto	Landing de producto orientada a performance y credibilidad visual.	/assets/images/banners/banner-15.jpg	landing-default	marketing_cms_seed	2026-05-03 16:26:40.826	2026-05-03 16:26:40.826
25	product/ventana-corrediza-20-blanco-3mm-1400x600	Ventana Corrediza 20 Blanco 3mm 1400x600	Landing de producto con foco premium y detalles de acabado.	GENERAL_SITE	es	PUBLISHED	t	Ventana Corrediza 20 Blanco 3mm 1400x600 | Experiencia visual de producto	Landing de producto con foco premium y detalles de acabado.	/assets/images/products/watch.png	landing-default	marketing_cms_seed	2026-05-03 16:26:40.836	2026-05-03 16:26:40.836
26	product/ventana-corrediza-20-blanco-3mm-1500x1500	Ventana Corrediza 20 Blanco 3mm 1500x1500	Landing de producto para moda, uso y comparación visual.	GENERAL_SITE	es	PUBLISHED	t	Ventana Corrediza 20 Blanco 3mm 1500x1500 | Experiencia visual de producto	Landing de producto para moda, uso y comparación visual.	/assets/images/products/clothes.png	landing-default	marketing_cms_seed	2026-05-03 16:26:40.847	2026-05-03 16:26:40.847
27	product/ventana-corrediza-20-blanco-3mm-1500x2000	Ventana Corrediza 20 Blanco 3mm 1500x2000	Landing de producto con foco en utilidad, estilo y portabilidad.	GENERAL_SITE	es	PUBLISHED	t	Ventana Corrediza 20 Blanco 3mm 1500x2000 | Experiencia visual de producto	Landing de producto con foco en utilidad, estilo y portabilidad.	/assets/images/products/gaming-gear.png	landing-default	marketing_cms_seed	2026-05-03 16:26:40.859	2026-05-03 16:26:40.859
\.


--
-- Data for Name: CmsPageAlias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CmsPageAlias" (id, "pageId", path, "createdAt", "updatedAt") FROM stdin;
1	9	guias/medicion	2026-05-03 16:26:40.753	2026-05-03 16:26:40.753
\.


--
-- Data for Name: CmsPageBlock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CmsPageBlock" (id, "sectionId", type, key, name, "sortOrder", visible, content, "mediaId", "createdAt", "updatedAt") FROM stdin;
1	4	CARD	\N	Cortinas de enrollar	0	t	{"href": "/productos/cortinas-de-enrollar.html", "badge": "Exterior", "title": "Cortinas de enrollar", "linkLabel": "Ver opciones", "description": "Persianas en PVC o aluminio con opción manual o motorizada según uso, exposición y mantenimiento.", "overlayText": true}	28	2026-05-03 16:26:40.644	2026-05-03 16:26:40.644
2	4	CARD	\N	Aberturas en aluminio	1	t	{"href": "/productos/aberturas-aluminio.html", "badge": "Obra y recambio", "title": "Aberturas en aluminio", "linkLabel": "Ver aberturas", "description": "Puertas, ventanas y monoblocks con vidrio simple o DVH para obra o recambio.", "overlayText": true}	29	2026-05-03 16:26:40.646	2026-05-03 16:26:40.646
3	4	CARD	\N	Toldos y cerramientos	2	t	{"href": "/productos/toldos-y-cerramientos.html", "badge": "Exterior", "title": "Toldos y cerramientos", "linkLabel": "Ver toldos", "description": "Protección solar, sombra y uso exterior con una solución a medida.", "overlayText": true}	2	2026-05-03 16:26:40.647	2026-05-03 16:26:40.647
4	4	CARD	\N	Motores y automatismos	3	t	{"href": "/productos/motores-cortinas-y-persianas.html", "badge": "Automatización", "title": "Motores y automatismos", "linkLabel": "Ver motores", "description": "Más confort en el uso diario con control remoto y automatización.", "overlayText": true}	30	2026-05-03 16:26:40.647	2026-05-03 16:26:40.647
5	4	CARD	\N	Cortinas Roller	4	t	{"href": "/productos/cortinas-roller.html", "badge": "Interior", "title": "Cortinas Roller", "linkLabel": "Más información", "description": "Solución interior moderna y funcional para regular luz y privacidad en hogar u oficina.", "overlayText": true}	30	2026-05-03 16:26:40.649	2026-05-03 16:26:40.649
6	4	CARD	\N	Bandas verticales	5	t	{"href": "/productos/bandas-verticales.html", "badge": "Amplios vidriados", "title": "Bandas verticales", "linkLabel": "Ver bandas verticales", "description": "Versatilidad y elegancia para oficinas, living y ventanales amplios con control de luz.", "overlayText": true}	31	2026-05-03 16:26:40.649	2026-05-03 16:26:40.649
7	4	CARD	\N	Cortinas Venecianas	6	t	{"href": "/productos/venecianas.html", "badge": "Control de luz", "title": "Cortinas Venecianas", "linkLabel": "Ver venecianas", "description": "Lamas de 16 mm y 25 mm para controlar luz y privacidad con una terminación limpia.", "overlayText": true}	32	2026-05-03 16:26:40.65	2026-05-03 16:26:40.65
8	4	CARD	\N	Cortinas metálicas	7	t	{"href": "/productos/cortinas-metalicas.html", "badge": "Seguridad", "title": "Cortinas metálicas", "linkLabel": "Ver cortinas metálicas", "description": "Máxima seguridad para locales y accesos.", "overlayText": true}	33	2026-05-03 16:26:40.651	2026-05-03 16:26:40.651
9	5	CARD	\N	Visita y toma de medidas	0	t	{"href": "/contact", "badge": "Acompañamiento", "title": "Visita y toma de medidas", "linkLabel": "Solicitar visita", "description": "Podemos coordinar una visita a domicilio para tomar medidas y orientar tu compra. En Montevideo la visita es sin costo."}	34	2026-05-03 16:26:40.652	2026-05-03 16:26:40.652
10	5	CARD	\N	Pagos y financiación	1	t	{"href": "/contacto.html", "badge": "Pagos", "title": "Pagos y financiación", "linkLabel": "Consultar medios de pago", "description": "Aceptamos transferencia, efectivo, Mercado Pago y tarjetas. Con Mercado Pago se puede pagar en cuotas."}	35	2026-05-03 16:26:40.653	2026-05-03 16:26:40.653
11	5	CARD	\N	Garantía según producto	2	t	{"href": "/preguntas-frecuentes", "badge": "Garantía", "title": "Garantía en todos nuestros productos y servicios", "linkLabel": "Ver garantía", "description": "Ofrecemos garantía en todos nuestros productos y servicios."}	36	2026-05-03 16:26:40.654	2026-05-03 16:26:40.654
12	5	CARD	\N	Instalación y mantenimiento	3	t	{"href": "/servicios/reparacion-cortinas-y-persianas.html", "badge": "Servicio", "title": "Instalación y mantenimiento", "linkLabel": "Ver servicios", "description": "Venta, instalación, mantenimiento y reparación para cortinas, persianas, toldos y aberturas."}	34	2026-05-03 16:26:40.655	2026-05-03 16:26:40.655
13	7	CARD	\N	Boston Clarks	0	t	{"href": "/contacto.html", "title": "Boston Clarks", "linkLabel": "Ver más", "description": "Proyecto comercial y de confianza."}	37	2026-05-03 16:26:40.657	2026-05-03 16:26:40.657
14	7	CARD	\N	El Dorado	1	t	{"href": "/contacto.html", "title": "El Dorado", "linkLabel": "Ver más", "description": "Cliente que confió en nuestro trabajo."}	38	2026-05-03 16:26:40.658	2026-05-03 16:26:40.658
15	7	CARD	\N	La Española	2	t	{"href": "/contacto.html", "title": "La Española", "linkLabel": "Ver más", "description": "Proyecto en el que aportamos soluciones a medida."}	39	2026-05-03 16:26:40.658	2026-05-03 16:26:40.658
16	7	CARD	\N	Montecon	3	t	{"href": "/contacto.html", "title": "Montecon", "linkLabel": "Ver más", "description": "Cliente institucional."}	40	2026-05-03 16:26:40.659	2026-05-03 16:26:40.659
17	7	CARD	\N	Cousa	4	t	{"href": "/contacto.html", "title": "Cousa", "linkLabel": "Ver más", "description": "Empresa que confió en nuestra propuesta."}	41	2026-05-03 16:26:40.66	2026-05-03 16:26:40.66
18	7	CARD	\N	Conatel	5	t	{"href": "/contacto.html", "title": "Conatel", "linkLabel": "Ver más", "description": "Confianza construida en proyectos reales."}	42	2026-05-03 16:26:40.661	2026-05-03 16:26:40.661
19	7	CARD	\N	SUAT	6	t	{"href": "/contacto.html", "title": "SUAT", "linkLabel": "Ver más", "description": "Otro cliente que acompañó nuestro trabajo."}	43	2026-05-03 16:26:40.662	2026-05-03 16:26:40.662
20	9	IMAGE	\N	Hero image	0	t	null	29	2026-05-03 16:26:40.664	2026-05-03 16:26:40.664
21	10	CARD	\N	Cortinas de enrollar	0	t	{"href": "/productos/cortinas-de-enrollar.html", "badge": "Exterior", "title": "Cortinas de enrollar", "linkLabel": "Ver opciones", "description": "PVC o aluminio según exposición, mantenimiento y nivel de robustez."}	28	2026-05-03 16:26:40.665	2026-05-03 16:26:40.665
22	10	CARD	\N	Aberturas en aluminio	1	t	{"href": "/productos/aberturas-aluminio.html", "badge": "Obra y recambio", "title": "Aberturas en aluminio", "linkLabel": "Ver aberturas", "description": "Serie 20, 25, alta prestación y DVH para obra o recambio."}	29	2026-05-03 16:26:40.666	2026-05-03 16:26:40.666
23	10	CARD	\N	Toldos y cerramientos	2	t	{"href": "/productos/toldos-y-cerramientos.html", "badge": "Exterior", "title": "Toldos y cerramientos", "linkLabel": "Ver toldos", "description": "Protección solar, sombra y uso exterior con una solución a medida."}	2	2026-05-03 16:26:40.667	2026-05-03 16:26:40.667
24	10	CARD	\N	Motores y automatismos	3	t	{"href": "/productos/motores-cortinas-y-persianas.html", "badge": "Automatización", "title": "Motores y automatismos", "linkLabel": "Ver motores", "description": "Más confort en el uso diario con control remoto y automatización."}	30	2026-05-03 16:26:40.668	2026-05-03 16:26:40.668
25	11	CARD	\N	Demo principal	0	t	{"title": "Ver el producto en contexto", "description": "Video breve para validar escala, uso y detalles antes de decidir."}	44	2026-05-03 16:26:40.669	2026-05-03 16:26:40.669
26	11	CARD	\N	Proceso	1	t	{"title": "Proceso y terminaciones", "description": "Una pieza editorial que muestra calidad y terminación."}	2	2026-05-03 16:26:40.67	2026-05-03 16:26:40.67
27	12	CARD	\N	Colección 1	0	t	{"href": "/productos/cortinas-roller.html", "badge": "Trend", "title": "Cortinas Roller", "linkLabel": "Ver producto", "description": "Solución interior moderna para regular luz y privacidad.", "overlayText": true}	30	2026-05-03 16:26:40.671	2026-05-03 16:26:40.671
28	12	CARD	\N	Colección 2	1	t	{"href": "/productos/bandas-verticales.html", "badge": "Focus", "title": "Bandas verticales", "linkLabel": "Ver bandas", "description": "Versatilidad y elegancia para ventanales amplios.", "overlayText": true}	31	2026-05-03 16:26:40.672	2026-05-03 16:26:40.672
29	12	CARD	\N	Colección 3	2	t	{"href": "/productos/venecianas.html", "badge": "Use case", "title": "Cortinas Venecianas", "linkLabel": "Ver venecianas", "description": "Control de luz con lamas de 16 mm y 25 mm.", "overlayText": true}	32	2026-05-03 16:26:40.673	2026-05-03 16:26:40.673
30	14	IMAGE	\N	Hero image	0	t	null	28	2026-05-03 16:26:40.675	2026-05-03 16:26:40.675
31	15	RICH_TEXT	\N	Intro copy	0	t	{"richText": [{"tag": "h2", "type": "element", "children": [{"type": "text", "value": "Cuándo conviene cada material"}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "El PVC prioriza practicidad y un costo más accesible, mientras que el aluminio suma firmeza y una respuesta más robusta para frentes expuestos."}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "La medida, la exposición al clima y el uso diario terminan de definir cuál conviene más en cada proyecto."}]}, {"tag": "h3", "type": "element", "children": [{"type": "text", "value": "Puntos clave"}]}, {"tag": "ul", "type": "element", "children": [{"tag": "li", "type": "element", "children": [{"type": "text", "value": "PVC = practicidad y menor mantenimiento"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Aluminio = más robustez para frentes expuestos"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "La exposición y el uso diario cambian la recomendación"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Podés pedir asesoramiento sin costo en Montevideo"}]}]}]}	\N	2026-05-03 16:26:40.676	2026-05-03 16:26:40.676
32	16	CARD	guias/cortinas-pvc-vs-aluminio-feature-1	PVC práctico	0	t	{"body": "Más accesible y fácil de mantener en usos donde la exposición no es extrema.", "href": "/productos/cortinas-de-enrollar-pvc.html", "badge": "Entry", "title": "PVC práctico", "linkLabel": "Ver más", "headingLevel": "h3"}	45	2026-05-03 16:26:40.677	2026-05-03 16:26:40.677
33	16	CARD	guias/cortinas-pvc-vs-aluminio-feature-2	Aluminio robusto	1	t	{"body": "Mejor para frentes expuestos y usos más intensivos.", "href": "/productos/cortinas-de-enrollar-aluminio.html", "badge": "Durable", "title": "Aluminio robusto", "linkLabel": "Ver más", "headingLevel": "h3"}	28	2026-05-03 16:26:40.678	2026-05-03 16:26:40.678
34	16	CARD	guias/cortinas-pvc-vs-aluminio-feature-3	Elegí según uso	2	t	{"body": "La frecuencia de uso, el clima y el mantenimiento esperado cambian la recomendación.", "href": "/contacto.html", "badge": "Decision", "title": "Elegí según uso", "linkLabel": "Ver más", "headingLevel": "h3"}	45	2026-05-03 16:26:40.679	2026-05-03 16:26:40.679
35	17	FAQ_ITEM	guias/cortinas-pvc-vs-aluminio-faq-1	¿Se pueden instalar sin obra?	0	t	{"question": "¿Se pueden instalar sin obra?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Sí. En muchos casos se instalan sin albañilería y se coordinan según el frente."}]}]}	\N	2026-05-03 16:26:40.68	2026-05-03 16:26:40.68
36	17	FAQ_ITEM	guias/cortinas-pvc-vs-aluminio-faq-2	¿Cuál conviene para frentes expuestos?	1	t	{"question": "¿Cuál conviene para frentes expuestos?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "En frentes más expuestos, el aluminio suele ofrecer una respuesta más robusta."}]}]}	\N	2026-05-03 16:26:40.68	2026-05-03 16:26:40.68
37	17	FAQ_ITEM	guias/cortinas-pvc-vs-aluminio-faq-3	¿Puedo pedir visita antes de decidir?	2	t	{"question": "¿Puedo pedir visita antes de decidir?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Sí. Podemos coordinar una visita y revisar medidas, uso y exposición antes de cotizar."}]}]}	\N	2026-05-03 16:26:40.68	2026-05-03 16:26:40.68
38	19	IMAGE	\N	Hero image	0	t	null	29	2026-05-03 16:26:40.683	2026-05-03 16:26:40.683
39	20	RICH_TEXT	\N	Intro copy	0	t	{"richText": [{"tag": "h2", "type": "element", "children": [{"type": "text", "value": "Qué aporta el doble vidriado hermético"}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "El DVH mejora el confort térmico y ayuda a reducir el ruido exterior. En obra nueva y en recambio puede marcar una diferencia clara en la percepción de calidad."}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "No siempre es obligatorio, pero sí suele ser una mejor inversión cuando buscás más confort o un cierre más completo."}]}, {"tag": "h3", "type": "element", "children": [{"type": "text", "value": "Puntos clave"}]}, {"tag": "ul", "type": "element", "children": [{"tag": "li", "type": "element", "children": [{"type": "text", "value": "Mejor confort térmico"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Menos ruido exterior"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Más valor percibido en la vivienda"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Ideal para obra nueva y recambio con más exigencia"}]}]}]}	\N	2026-05-03 16:26:40.683	2026-05-03 16:26:40.683
40	21	CARD	guias/dvh-feature-1	Confort térmico	0	t	{"body": "Ayuda a estabilizar mejor la temperatura interior.", "href": "/productos/aberturas-aluminio.html", "badge": "Comfort", "title": "Confort térmico", "linkLabel": "Ver más", "headingLevel": "h3"}	29	2026-05-03 16:26:40.691	2026-05-03 16:26:40.691
41	21	CARD	guias/dvh-feature-2	Aislamiento acústico	1	t	{"body": "Reduce la sensación de ruido en entornos más expuestos.", "href": "/productos/aberturas-aluminio.html", "badge": "Silence", "title": "Aislamiento acústico", "linkLabel": "Ver más", "headingLevel": "h3"}	29	2026-05-03 16:26:40.701	2026-05-03 16:26:40.701
42	21	CARD	guias/dvh-feature-3	Valor percibido	2	t	{"body": "Suma una lectura más premium en el proyecto final.", "href": "/contacto.html", "badge": "Value", "title": "Valor percibido", "linkLabel": "Ver más", "headingLevel": "h3"}	29	2026-05-03 16:26:40.708	2026-05-03 16:26:40.708
43	22	FAQ_ITEM	guias/dvh-faq-1	¿DVH siempre conviene?	0	t	{"question": "¿DVH siempre conviene?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "No siempre, pero sí suele aportar más valor cuando buscás confort y mejor cierre."}]}]}	\N	2026-05-03 16:26:40.714	2026-05-03 16:26:40.714
44	22	FAQ_ITEM	guias/dvh-faq-2	¿Sirve en obra nueva y recambio?	1	t	{"question": "¿Sirve en obra nueva y recambio?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Sí. En ambos casos puede mejorar el resultado final y la percepción de calidad."}]}]}	\N	2026-05-03 16:26:40.714	2026-05-03 16:26:40.714
149	85	CARD	\N	Grid item 3	2	t	{"href": "/categories", "badge": "Use case", "title": "Producto Variable QA API 2 lifestyle", "linkLabel": "Ir a categoría", "description": "El contexto de uso reduce la fricción de decisión.", "overlayText": true}	80	2026-05-03 16:26:40.825	2026-05-03 16:26:40.825
45	22	FAQ_ITEM	guias/dvh-faq-3	¿Con qué series se combina?	2	t	{"question": "¿Con qué series se combina?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Normalmente se evalúa junto a la serie, el tipo de apertura y el uso esperado del ambiente."}]}]}	\N	2026-05-03 16:26:40.715	2026-05-03 16:26:40.715
46	24	IMAGE	\N	Hero image	0	t	null	29	2026-05-03 16:26:40.717	2026-05-03 16:26:40.717
47	25	RICH_TEXT	\N	Intro copy	0	t	{"richText": [{"tag": "h2", "type": "element", "children": [{"type": "text", "value": "Series y criterios de elección"}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "La decisión no pasa solo por el nombre de la línea. También importa el tipo de apertura, el nivel de exposición y si el proyecto requiere más prestación o una solución estándar."}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "En obra nueva o recambio, el objetivo es ordenar la elección con criterios simples: uso, presupuesto y expectativa de terminación."}]}, {"tag": "h3", "type": "element", "children": [{"type": "text", "value": "Puntos clave"}]}, {"tag": "ul", "type": "element", "children": [{"tag": "li", "type": "element", "children": [{"type": "text", "value": "Serie 20 para múltiples usos"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Serie 25 para mayor prestación"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Alta prestación cuando importa más la robustez"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "DVH suma confort y valor percibido"}]}]}]}	\N	2026-05-03 16:26:40.718	2026-05-03 16:26:40.718
48	26	CARD	guias/probba-vs-gala-feature-1	Serie 20	0	t	{"body": "Sirve en múltiples usos cuando buscás una solución sólida pero estándar.", "href": "/productos/aberturas-aluminio.html", "badge": "Standard", "title": "Serie 20", "linkLabel": "Ver más", "headingLevel": "h3"}	29	2026-05-03 16:26:40.719	2026-05-03 16:26:40.719
49	26	CARD	guias/probba-vs-gala-feature-2	Serie 25	1	t	{"body": "Mejora la prestación cuando el proyecto necesita un poco más de respuesta.", "href": "/productos/aberturas-aluminio.html", "badge": "Better", "title": "Serie 25", "linkLabel": "Ver más", "headingLevel": "h3"}	29	2026-05-03 16:26:40.72	2026-05-03 16:26:40.72
50	26	CARD	guias/probba-vs-gala-feature-3	Alta prestación	2	t	{"body": "Conviene cuando la robustez y la terminación pesan más en la decisión.", "href": "/productos/aberturas-aluminio.html", "badge": "Premium", "title": "Alta prestación", "linkLabel": "Ver más", "headingLevel": "h3"}	29	2026-05-03 16:26:40.721	2026-05-03 16:26:40.721
51	27	FAQ_ITEM	guias/probba-vs-gala-faq-1	¿Probba o Gala?	0	t	{"question": "¿Probba o Gala?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "La elección depende de la serie, del nivel de prestación y del uso esperado del ambiente."}]}]}	\N	2026-05-03 16:26:40.722	2026-05-03 16:26:40.722
52	27	FAQ_ITEM	guias/probba-vs-gala-faq-2	¿Serie 20 o 25?	1	t	{"question": "¿Serie 20 o 25?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "La serie 25 suele ganar cuando buscás un poco más de respuesta y robustez."}]}]}	\N	2026-05-03 16:26:40.722	2026-05-03 16:26:40.722
53	27	FAQ_ITEM	guias/probba-vs-gala-faq-3	¿Se puede combinar con DVH?	2	t	{"question": "¿Se puede combinar con DVH?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Sí. Es una combinación habitual cuando el objetivo es sumar confort y percepción de calidad."}]}]}	\N	2026-05-03 16:26:40.722	2026-05-03 16:26:40.722
54	29	IMAGE	\N	Hero image	0	t	null	46	2026-05-03 16:26:40.725	2026-05-03 16:26:40.725
55	30	RICH_TEXT	\N	Intro copy	0	t	{"richText": [{"tag": "h2", "type": "element", "children": [{"type": "text", "value": "Qué ofrece la Serie Probba"}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "Probba es la opción de alta prestación de entrada dentro de las aberturas de aluminio."}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "Combina diseño renovado, accesorios de alta calidad, posibilidad de DVH y un abanico amplio de tipologías para obra nueva o recambio."}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "También conviene revisar terminaciones y colores antes de decidir, porque la serie acompaña mejor tanto frentes interiores como exteriores cuando la elección visual ya está definida."}]}, {"tag": "h3", "type": "element", "children": [{"type": "text", "value": "Puntos clave"}]}, {"tag": "ul", "type": "element", "children": [{"tag": "li", "type": "element", "children": [{"type": "text", "value": "Alta prestación de entrada"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Admite vidrio simple y DVH"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Soporta múltiples tipologías"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Terminaciones y colores a confirmar según proyecto"}]}]}]}	\N	2026-05-03 16:26:40.725	2026-05-03 16:26:40.725
56	31	CARD	guias/aberturas-probba-feature-1	Ventana y puerta corrediza	0	t	{"body": "Marco de 2 rieles, con opción de 2 o 4 hojas, doble felpilla y posibilidad de mosquitero.", "href": "/productos/aberturas-probba.html", "badge": "Corrediza", "title": "Ventana y puerta corrediza", "linkLabel": "Ver más", "headingLevel": "h3"}	47	2026-05-03 16:26:40.727	2026-05-03 16:26:40.727
57	31	CARD	guias/aberturas-probba-feature-2	Ventana batiente	1	t	{"body": "Apertura interior de 1 o 2 hojas, con falleba y varias opciones de cierre.", "href": "/productos/aberturas-probba.html", "badge": "Batiente", "title": "Ventana batiente", "linkLabel": "Ver más", "headingLevel": "h3"}	48	2026-05-03 16:26:40.728	2026-05-03 16:26:40.728
58	31	CARD	guias/aberturas-probba-feature-3	Ventana oscilobatiente	2	t	{"body": "Doble modalidad de apertura para sumar ventilación y comodidad de uso.", "href": "/productos/aberturas-probba.html", "badge": "Oscilobatiente", "title": "Ventana oscilobatiente", "linkLabel": "Ver más", "headingLevel": "h3"}	49	2026-05-03 16:26:40.729	2026-05-03 16:26:40.729
59	31	CARD	guias/aberturas-probba-feature-4	Ventana banderola	3	t	{"body": "Apertura interior con brazo limitador lateral y desenganche para limpieza.", "href": "/productos/aberturas-probba.html", "badge": "Banderola", "title": "Ventana banderola", "linkLabel": "Ver más", "headingLevel": "h3"}	50	2026-05-03 16:26:40.73	2026-05-03 16:26:40.73
60	31	CARD	guias/aberturas-probba-feature-5	Ventana proyectante	4	t	{"body": "Hoja única con proyección exterior y sistema de cierre pensado para uso práctico.", "href": "/productos/aberturas-probba.html", "badge": "Proyectante", "title": "Ventana proyectante", "linkLabel": "Ver más", "headingLevel": "h3"}	51	2026-05-03 16:26:40.731	2026-05-03 16:26:40.731
112	61	CARD	guias/bandas-verticales-feature-2	Screen	1	t	{"body": "Deja pasar luz y sirve para controlar el reflejo en uso diario.", "href": "/productos/bandas-verticales.html", "badge": "Light", "title": "Screen", "linkLabel": "Ver más", "headingLevel": "h3"}	70	2026-05-03 16:26:40.781	2026-05-03 16:26:40.781
61	31	CARD	guias/aberturas-probba-feature-6	Proyección y desliz	5	t	{"body": "Versión pensada para abrir hacia afuera con brazos a fricción y uso más técnico.", "href": "/productos/aberturas-probba.html", "badge": "Desliz", "title": "Proyección y desliz", "linkLabel": "Ver más", "headingLevel": "h3"}	52	2026-05-03 16:26:40.731	2026-05-03 16:26:40.731
62	31	CARD	guias/aberturas-probba-feature-7	Puerta batiente	6	t	{"body": "Puerta de 1 o 2 hojas con apertura interior o exterior, umbral inferior y opción de travesaño.", "href": "/productos/aberturas-probba.html", "badge": "Puerta", "title": "Puerta batiente", "linkLabel": "Ver más", "headingLevel": "h3"}	53	2026-05-03 16:26:40.732	2026-05-03 16:26:40.732
63	31	CARD	guias/aberturas-probba-feature-8	Paño fijo	7	t	{"body": "Marco de 76 mm con opción de travesaño horizontal o vertical y vidrio simple o DVH.", "href": "/productos/aberturas-probba.html", "badge": "Fijo", "title": "Paño fijo", "linkLabel": "Ver más", "headingLevel": "h3"}	54	2026-05-03 16:26:40.733	2026-05-03 16:26:40.733
64	32	FAQ_ITEM	guias/aberturas-probba-faq-1	¿Probba admite DVH?	0	t	{"question": "¿Probba admite DVH?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Sí. La serie puede configurarse con vidrio simple o doble vidriado hermético."}]}]}	\N	2026-05-03 16:26:40.734	2026-05-03 16:26:40.734
65	32	FAQ_ITEM	guias/aberturas-probba-faq-2	¿Qué conviene revisar además de la tipología?	1	t	{"question": "¿Qué conviene revisar además de la tipología?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Conviene revisar terminaciones, colores y el uso real del ambiente antes de cerrar la elección."}]}]}	\N	2026-05-03 16:26:40.734	2026-05-03 16:26:40.734
66	32	FAQ_ITEM	guias/aberturas-probba-faq-3	¿Para qué tipo de proyecto conviene?	2	t	{"question": "¿Para qué tipo de proyecto conviene?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Funciona muy bien cuando querés una alta prestación de entrada con más variedad de configuración."}]}]}	\N	2026-05-03 16:26:40.734	2026-05-03 16:26:40.734
67	34	IMAGE	\N	Hero image	0	t	null	55	2026-05-03 16:26:40.737	2026-05-03 16:26:40.737
68	35	RICH_TEXT	\N	Intro copy	0	t	{"richText": [{"tag": "h2", "type": "element", "children": [{"type": "text", "value": "Qué hace distinta a Gala"}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "Gala es una línea de alta prestación versátil y estética."}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "Se apoya en perfiles de aristas redondeadas, aislamiento térmico y acústico, y accesorios europeos pensados para necesidades distintas."}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "Si el proyecto busca mejor terminación y confort, Gala entra como una referencia clara."}]}, {"tag": "h3", "type": "element", "children": [{"type": "text", "value": "Puntos clave"}]}, {"tag": "ul", "type": "element", "children": [{"tag": "li", "type": "element", "children": [{"type": "text", "value": "Aristas redondeadas"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Aislamiento térmico y acústico"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Accesorios europeos"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Variante Gala CR con estanqueidad al agua"}]}]}]}	\N	2026-05-03 16:26:40.738	2026-05-03 16:26:40.738
69	36	CARD	guias/aberturas-gala-feature-1	Confort y aislamiento	0	t	{"body": "La serie suma aislamiento térmico y acústico para un uso más cómodo.", "href": "/productos/aberturas-gala.html", "badge": "Comfort", "title": "Confort y aislamiento", "linkLabel": "Ver más", "headingLevel": "h3"}	56	2026-05-03 16:26:40.739	2026-05-03 16:26:40.739
70	36	CARD	guias/aberturas-gala-feature-2	Terminación estética	1	t	{"body": "Las aristas redondeadas aportan una lectura visual más cuidada.", "href": "/productos/aberturas-gala.html", "badge": "Design", "title": "Terminación estética", "linkLabel": "Ver más", "headingLevel": "h3"}	55	2026-05-03 16:26:40.74	2026-05-03 16:26:40.74
71	36	CARD	guias/aberturas-gala-feature-3	Gala CR	2	t	{"body": "Versión con estanqueidad al agua para proyectos que necesitan más respuesta.", "href": "/productos/aberturas-gala.html", "badge": "CR", "title": "Gala CR", "linkLabel": "Ver más", "headingLevel": "h3"}	57	2026-05-03 16:26:40.741	2026-05-03 16:26:40.741
72	36	CARD	guias/aberturas-gala-feature-4	Accesorios europeos	3	t	{"body": "Accesorios específicos para ordenar mejor la respuesta según cada necesidad.", "href": "/productos/aberturas-gala.html", "badge": "Accessories", "title": "Accesorios europeos", "linkLabel": "Ver más", "headingLevel": "h3"}	58	2026-05-03 16:26:40.742	2026-05-03 16:26:40.742
73	37	FAQ_ITEM	guias/aberturas-gala-faq-1	¿Gala admite DVH?	0	t	{"question": "¿Gala admite DVH?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Sí. La línea permite sumar DVH cuando el proyecto pide más confort y aislamiento."}]}]}	\N	2026-05-03 16:26:40.742	2026-05-03 16:26:40.742
74	37	FAQ_ITEM	guias/aberturas-gala-faq-2	¿Qué diferencia a Gala CR?	1	t	{"question": "¿Qué diferencia a Gala CR?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Gala CR prioriza la estanqueidad al agua y suma una respuesta más completa en proyectos exigentes."}]}]}	\N	2026-05-03 16:26:40.743	2026-05-03 16:26:40.743
75	37	FAQ_ITEM	guias/aberturas-gala-faq-3	¿Cuándo conviene Gala frente a Probba?	2	t	{"question": "¿Cuándo conviene Gala frente a Probba?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Gala conviene cuando buscás una terminación más cuidada y una solución muy versátil."}]}]}	\N	2026-05-03 16:26:40.743	2026-05-03 16:26:40.743
76	39	IMAGE	\N	Hero image	0	t	null	59	2026-05-03 16:26:40.746	2026-05-03 16:26:40.746
110	60	RICH_TEXT	\N	Intro copy	0	t	{"richText": [{"tag": "h2", "type": "element", "children": [{"type": "text", "value": "Qué conviene mirar primero"}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "Las bandas verticales funcionan muy bien en ventanales grandes, oficinas y ambientes donde necesitás regular luz sin perder orden visual."}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "La decisión cambia según el material, la superficie y la forma de apertura que el ambiente necesita."}]}, {"tag": "h3", "type": "element", "children": [{"type": "text", "value": "Puntos clave"}]}, {"tag": "ul", "type": "element", "children": [{"tag": "li", "type": "element", "children": [{"type": "text", "value": "Blackout para más privacidad"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Screen para dejar pasar luz"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Poliéster para una solución versátil"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Aperturas normal, invertida o al centro"}]}]}]}	\N	2026-05-03 16:26:40.779	2026-05-03 16:26:40.779
77	40	RICH_TEXT	\N	Intro copy	0	t	{"richText": [{"tag": "h2", "type": "element", "children": [{"type": "text", "value": "Qué ofrece Summa"}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "Summa es la línea premium de aberturas en aluminio."}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "Está pensada para grandes dimensiones, mejor hermeticidad y una lectura más moderna del espacio."}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "La guía del proveedor suma tipologías, variantes y terminaciones para elegir mejor según obra y proyecto."}]}, {"tag": "h3", "type": "element", "children": [{"type": "text", "value": "Puntos clave"}]}, {"tag": "ul", "type": "element", "children": [{"tag": "li", "type": "element", "children": [{"type": "text", "value": "Hasta 2, 3, 4 o 6 hojas corredizas según configuración"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Admite DVH"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Variante Alzante"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Variante Comfort RPT"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Terminaciones disponibles"}]}]}]}	\N	2026-05-03 16:26:40.746	2026-05-03 16:26:40.746
78	41	CARD	guias/aberturas-summa-feature-1	Corredizas 2 y 3 rieles	0	t	{"body": "Permiten opciones de 2, 3, 4 o 6 hojas corredizas según configuración.", "href": "/productos/aberturas-summa.html", "badge": "Sliding", "title": "Corredizas 2 y 3 rieles", "linkLabel": "Ver más", "headingLevel": "h3"}	60	2026-05-03 16:26:40.748	2026-05-03 16:26:40.748
79	41	CARD	guias/aberturas-summa-feature-2	Summa Alzante	1	t	{"body": "Incorpora una solución corrediza alzante para proyectos más completos.", "href": "/productos/aberturas-summa.html", "badge": "Lift", "title": "Summa Alzante", "linkLabel": "Ver más", "headingLevel": "h3"}	61	2026-05-03 16:26:40.748	2026-05-03 16:26:40.748
80	41	CARD	guias/aberturas-summa-feature-3	Summa Comfort RPT	2	t	{"body": "Versión con ruptura de puente térmico para sumar más aislamiento y confort.", "href": "/productos/aberturas-summa.html", "badge": "RPT", "title": "Summa Comfort RPT", "linkLabel": "Ver más", "headingLevel": "h3"}	62	2026-05-03 16:26:40.749	2026-05-03 16:26:40.749
81	41	CARD	guias/aberturas-summa-feature-4	Terminaciones disponibles	3	t	{"body": "Una galería útil para revisar acabados y colores antes de cerrar la elección.", "href": "/productos/aberturas-summa.html", "badge": "Finish", "title": "Terminaciones disponibles", "linkLabel": "Ver más", "headingLevel": "h3"}	63	2026-05-03 16:26:40.75	2026-05-03 16:26:40.75
82	42	FAQ_ITEM	guias/aberturas-summa-faq-1	¿Summa admite DVH?	0	t	{"question": "¿Summa admite DVH?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Sí. La serie puede trabajar con doble vidriado hermético según el proyecto."}]}]}	\N	2026-05-03 16:26:40.75	2026-05-03 16:26:40.75
83	42	FAQ_ITEM	guias/aberturas-summa-faq-2	¿Cuándo conviene Summa?	1	t	{"question": "¿Cuándo conviene Summa?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Conviene cuando buscás mayor hermeticidad, más confort y una solución para grandes dimensiones."}]}]}	\N	2026-05-03 16:26:40.751	2026-05-03 16:26:40.751
84	42	FAQ_ITEM	guias/aberturas-summa-faq-3	¿Qué diferencia hay entre Alzante y Comfort RPT?	2	t	{"question": "¿Qué diferencia hay entre Alzante y Comfort RPT?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Alzante prioriza la apertura corrediza de mayor prestación y Comfort RPT suma ruptura de puente térmico."}]}]}	\N	2026-05-03 16:26:40.751	2026-05-03 16:26:40.751
85	44	IMAGE	\N	Hero image	0	t	null	45	2026-05-03 16:26:40.755	2026-05-03 16:26:40.755
86	45	RICH_TEXT	\N	Intro copy	0	t	{"richText": [{"tag": "h2", "type": "element", "children": [{"type": "text", "value": "Qué medir antes de cotizar"}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "Medir bien el ancho y el alto evita correcciones y acelera el presupuesto. Si además podés enviar una foto del frente, la recomendación mejora bastante."}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "La medida correcta no es solo una cifra: también importa la ubicación, los obstáculos y el tipo de producto que vas a instalar."}]}, {"tag": "h3", "type": "element", "children": [{"type": "text", "value": "Puntos clave"}]}, {"tag": "ul", "type": "element", "children": [{"tag": "li", "type": "element", "children": [{"type": "text", "value": "Ancho en tres puntos"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Alto en tres puntos"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Revisá obstáculos y terminaciones"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Sumá una foto del frente si podés"}]}]}]}	\N	2026-05-03 16:26:40.756	2026-05-03 16:26:40.756
87	46	CARD	guias/como-medir-ancho-y-alto-feature-1	Ancho	0	t	{"body": "Tomalo en varios puntos para detectar diferencias o desvíos.", "href": "/contact", "badge": "Width", "title": "Ancho", "linkLabel": "Ver más", "headingLevel": "h3"}	45	2026-05-03 16:26:40.757	2026-05-03 16:26:40.757
88	46	CARD	guias/como-medir-ancho-y-alto-feature-2	Alto	1	t	{"body": "Medí el alto total y revisá si hay remates, dinteles o interferencias.", "href": "/contact", "badge": "Height", "title": "Alto", "linkLabel": "Ver más", "headingLevel": "h3"}	28	2026-05-03 16:26:40.758	2026-05-03 16:26:40.758
89	46	CARD	guias/como-medir-ancho-y-alto-feature-3	Obstáculos	2	t	{"body": "Cableado, marcos, manijas o revoques pueden cambiar la recomendación.", "href": "/contact", "badge": "Context", "title": "Obstáculos", "linkLabel": "Ver más", "headingLevel": "h3"}	45	2026-05-03 16:26:40.759	2026-05-03 16:26:40.759
90	47	FAQ_ITEM	guias/como-medir-ancho-y-alto-faq-1	¿Hace falta medir perfecto?	0	t	{"question": "¿Hace falta medir perfecto?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "No hace falta perfección absoluta, pero sí una medida bien tomada y consistente."}]}]}	\N	2026-05-03 16:26:40.76	2026-05-03 16:26:40.76
91	47	FAQ_ITEM	guias/como-medir-ancho-y-alto-faq-2	¿Puedo pedir visita en lugar de medir yo?	1	t	{"question": "¿Puedo pedir visita en lugar de medir yo?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Sí. Podés coordinar una visita para tomar medidas y revisar el caso en persona."}]}]}	\N	2026-05-03 16:26:40.76	2026-05-03 16:26:40.76
92	47	FAQ_ITEM	guias/como-medir-ancho-y-alto-faq-3	¿Sirve para pedir precios online?	2	t	{"question": "¿Sirve para pedir precios online?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Sí. Una medida aproximada ya ayuda a orientar mejor el presupuesto inicial."}]}]}	\N	2026-05-03 16:26:40.76	2026-05-03 16:26:40.76
93	49	IMAGE	\N	Hero image	0	t	null	64	2026-05-03 16:26:40.763	2026-05-03 16:26:40.763
94	50	RICH_TEXT	\N	Intro copy	0	t	{"richText": [{"tag": "h2", "type": "element", "children": [{"type": "text", "value": "Qué define la elección"}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "Roller screen deja pasar luz y ayuda a mantener vista hacia el exterior. Blackout prioriza privacidad y oscurecimiento. Roller doble combina dos telas en una misma instalación para alternar según el momento."}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "La medida del frente, el uso diario y la luz que querés controlar terminan de definir la mejor opción."}]}, {"tag": "h3", "type": "element", "children": [{"type": "text", "value": "Puntos clave"}]}, {"tag": "ul", "type": "element", "children": [{"tag": "li", "type": "element", "children": [{"type": "text", "value": "Screen para luz natural y vista"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Blackout para privacidad y oscuridad"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Roller doble para combinar usos"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "La medida del frente cambia la recomendación"}]}]}]}	\N	2026-05-03 16:26:40.764	2026-05-03 16:26:40.764
95	51	CARD	guias/cortinas-roller-feature-1	Screen	0	t	{"body": "Deja pasar luz y funciona muy bien en livings, oficinas y espacios de uso diario.", "href": "/productos/cortinas-roller.html", "badge": "Luz", "title": "Screen", "linkLabel": "Ver más", "headingLevel": "h3"}	65	2026-05-03 16:26:40.765	2026-05-03 16:26:40.765
96	51	CARD	guias/cortinas-roller-feature-2	Blackout	1	t	{"body": "Reduce la entrada de luz y suma privacidad en dormitorios y ambientes de descanso.", "href": "/productos/cortinas-roller.html", "badge": "Privacidad", "title": "Blackout", "linkLabel": "Ver más", "headingLevel": "h3"}	66	2026-05-03 16:26:40.766	2026-05-03 16:26:40.766
97	51	CARD	guias/cortinas-roller-feature-3	Roller doble	2	t	{"body": "Combina dos telas para alternar luz y oscuridad en un mismo frente.", "href": "/productos/cortinas-roller.html", "badge": "Versatilidad", "title": "Roller doble", "linkLabel": "Ver más", "headingLevel": "h3"}	64	2026-05-03 16:26:40.767	2026-05-03 16:26:40.767
98	52	FAQ_ITEM	guias/cortinas-roller-faq-1	¿Qué variante conviene para un living?	0	t	{"question": "¿Qué variante conviene para un living?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Screen suele ser la alternativa más cómoda si querés luz natural y una lectura limpia del ambiente."}]}]}	\N	2026-05-03 16:26:40.768	2026-05-03 16:26:40.768
99	52	FAQ_ITEM	guias/cortinas-roller-faq-2	¿Cuál conviene para un dormitorio?	1	t	{"question": "¿Cuál conviene para un dormitorio?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Blackout suele ser la mejor opción si la prioridad es oscurecer y ganar privacidad."}]}]}	\N	2026-05-03 16:26:40.768	2026-05-03 16:26:40.768
100	52	FAQ_ITEM	guias/cortinas-roller-faq-3	¿Qué aporta el roller doble?	2	t	{"question": "¿Qué aporta el roller doble?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Permite alternar entre dos telas y ajustar mejor la luz según el momento del día."}]}]}	\N	2026-05-03 16:26:40.768	2026-05-03 16:26:40.768
101	54	IMAGE	\N	Hero image	0	t	null	67	2026-05-03 16:26:40.771	2026-05-03 16:26:40.771
102	55	RICH_TEXT	\N	Intro copy	0	t	{"richText": [{"tag": "h2", "type": "element", "children": [{"type": "text", "value": "Qué cambia al motorizar"}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "La motorización suma confort en cortinas, persianas y cortinas metálicas. También ayuda cuando el frente es grande o el uso diario ya justifica más comodidad."}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "El tipo de control define la experiencia: remoto, botonera, app o integración domótica."}]}, {"tag": "h3", "type": "element", "children": [{"type": "text", "value": "Puntos clave"}]}, {"tag": "ul", "type": "element", "children": [{"tag": "li", "type": "element", "children": [{"type": "text", "value": "Más confort en el uso diario"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Mejor experiencia en frentes grandes"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Control remoto, botonera o app"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Posible integración domótica"}]}]}]}	\N	2026-05-03 16:26:40.771	2026-05-03 16:26:40.771
103	56	CARD	guias/motores-cortinas-y-persianas-feature-1	Control remoto	0	t	{"body": "La opción más simple para subir o bajar sin esfuerzo físico.", "href": "/productos/motores-cortinas-y-persianas.html", "badge": "Remote", "title": "Control remoto", "linkLabel": "Ver más", "headingLevel": "h3"}	68	2026-05-03 16:26:40.773	2026-05-03 16:26:40.773
104	56	CARD	guias/motores-cortinas-y-persianas-feature-2	Botonera	1	t	{"body": "Ideal cuando querés un punto fijo y práctico de control.", "href": "/productos/motores-cortinas-y-persianas.html", "badge": "Button", "title": "Botonera", "linkLabel": "Ver más", "headingLevel": "h3"}	69	2026-05-03 16:26:40.773	2026-05-03 16:26:40.773
105	56	CARD	guias/motores-cortinas-y-persianas-feature-3	App y domótica	2	t	{"body": "Permite integrar automatización con más programación y rutina.", "href": "/productos/motores-cortinas-y-persianas.html", "badge": "Smart", "title": "App y domótica", "linkLabel": "Ver más", "headingLevel": "h3"}	67	2026-05-03 16:26:40.774	2026-05-03 16:26:40.774
106	57	FAQ_ITEM	guias/motores-cortinas-y-persianas-faq-1	¿Se puede motorizar una instalación existente?	0	t	{"question": "¿Se puede motorizar una instalación existente?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "En muchos casos sí, siempre que el sistema y el estado actual lo permitan."}]}]}	\N	2026-05-03 16:26:40.775	2026-05-03 16:26:40.775
107	57	FAQ_ITEM	guias/motores-cortinas-y-persianas-faq-2	¿Qué control conviene?	1	t	{"question": "¿Qué control conviene?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Depende de la comodidad que busques y de la forma en que usás el ambiente."}]}]}	\N	2026-05-03 16:26:40.775	2026-05-03 16:26:40.775
108	57	FAQ_ITEM	guias/motores-cortinas-y-persianas-faq-3	¿Cuándo conviene motorizar?	2	t	{"question": "¿Cuándo conviene motorizar?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Cuando el uso ya es frecuente o el frente es grande y querés más confort."}]}]}	\N	2026-05-03 16:26:40.776	2026-05-03 16:26:40.776
109	59	IMAGE	\N	Hero image	0	t	null	70	2026-05-03 16:26:40.778	2026-05-03 16:26:40.778
111	61	CARD	guias/bandas-verticales-feature-1	Blackout	0	t	{"body": "Conviene cuando querés más privacidad y mayor oscurecimiento.", "href": "/productos/bandas-verticales.html", "badge": "Privacy", "title": "Blackout", "linkLabel": "Ver más", "headingLevel": "h3"}	71	2026-05-03 16:26:40.781	2026-05-03 16:26:40.781
150	87	IMAGE	\N	Hero image	0	t	null	82	2026-05-03 16:26:40.827	2026-05-03 16:26:40.827
113	61	CARD	guias/bandas-verticales-feature-3	Poliéster	2	t	{"body": "Buena alternativa cuando buscás versatilidad y lectura prolija.", "href": "/productos/bandas-verticales.html", "badge": "Versatile", "title": "Poliéster", "linkLabel": "Ver más", "headingLevel": "h3"}	72	2026-05-03 16:26:40.782	2026-05-03 16:26:40.782
114	62	FAQ_ITEM	guias/bandas-verticales-faq-1	¿Dónde convienen más?	0	t	{"question": "¿Dónde convienen más?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Funcionan muy bien en ventanales amplios, oficinas, escritorios y living."}]}]}	\N	2026-05-03 16:26:40.783	2026-05-03 16:26:40.783
115	62	FAQ_ITEM	guias/bandas-verticales-faq-2	¿Qué apertura puedo elegir?	1	t	{"question": "¿Qué apertura puedo elegir?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Podés definir apertura normal, invertida, al centro o hacia ambos lados."}]}]}	\N	2026-05-03 16:26:40.783	2026-05-03 16:26:40.783
116	62	FAQ_ITEM	guias/bandas-verticales-faq-3	¿Qué material conviene?	2	t	{"question": "¿Qué material conviene?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Depende de cuánta luz querés dejar pasar y del nivel de privacidad que necesitás."}]}]}	\N	2026-05-03 16:26:40.784	2026-05-03 16:26:40.784
117	64	IMAGE	\N	Hero image	0	t	null	28	2026-05-03 16:26:40.786	2026-05-03 16:26:40.786
118	65	RICH_TEXT	\N	Intro copy	0	t	{"richText": [{"tag": "h2", "type": "element", "children": [{"type": "text", "value": "Qué mueve el precio"}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "El material, las medidas, el tipo de accionamiento y la exposición del frente cambian el valor final."}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "Una cortina más grande, motorizada o pensada para un uso más exigente va a tener un costo distinto a una solución más simple."}]}, {"tag": "h3", "type": "element", "children": [{"type": "text", "value": "Puntos clave"}]}, {"tag": "ul", "type": "element", "children": [{"tag": "li", "type": "element", "children": [{"type": "text", "value": "Material"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Medidas"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Manual o motorizada"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Exposición y terminaciones"}]}]}]}	\N	2026-05-03 16:26:40.787	2026-05-03 16:26:40.787
119	66	CARD	precios/cortinas-de-enrollar-feature-1	PVC	0	t	{"body": "Suele ser la alternativa más accesible cuando la prioridad es practicidad.", "href": "/productos/cortinas-de-enrollar-pvc.html", "badge": "Entry", "title": "PVC", "linkLabel": "Ver más", "headingLevel": "h3"}	45	2026-05-03 16:26:40.789	2026-05-03 16:26:40.789
120	66	CARD	precios/cortinas-de-enrollar-feature-2	Aluminio	1	t	{"body": "Suma robustez y suele subir cuando el frente está más expuesto.", "href": "/productos/cortinas-de-enrollar-aluminio.html", "badge": "Durable", "title": "Aluminio", "linkLabel": "Ver más", "headingLevel": "h3"}	28	2026-05-03 16:26:40.79	2026-05-03 16:26:40.79
121	66	CARD	precios/cortinas-de-enrollar-feature-3	Motorización	2	t	{"body": "La automatización agrega confort y una configuración más completa.", "href": "/productos/motores-cortinas-y-persianas.html", "badge": "Comfort", "title": "Motorización", "linkLabel": "Ver más", "headingLevel": "h3"}	30	2026-05-03 16:26:40.791	2026-05-03 16:26:40.791
122	67	FAQ_ITEM	precios/cortinas-de-enrollar-faq-1	¿Qué datos hacen falta para pedir precio?	0	t	{"question": "¿Qué datos hacen falta para pedir precio?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Con una medida aproximada y una foto del frente ya podemos orientar bastante mejor."}]}]}	\N	2026-05-03 16:26:40.791	2026-05-03 16:26:40.791
123	67	FAQ_ITEM	precios/cortinas-de-enrollar-faq-2	¿La visita en Montevideo tiene costo?	1	t	{"question": "¿La visita en Montevideo tiene costo?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "En Montevideo la visita es sin costo y ayuda a cerrar mejor la recomendación."}]}]}	\N	2026-05-03 16:26:40.792	2026-05-03 16:26:40.792
124	67	FAQ_ITEM	precios/cortinas-de-enrollar-faq-3	¿Puedo comparar PVC y aluminio antes de decidir?	2	t	{"question": "¿Puedo comparar PVC y aluminio antes de decidir?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Sí. Esa comparativa suele ser la más útil para un primer presupuesto."}]}]}	\N	2026-05-03 16:26:40.792	2026-05-03 16:26:40.792
125	69	IMAGE	\N	Hero image	0	t	null	33	2026-05-03 16:26:40.794	2026-05-03 16:26:40.794
126	70	RICH_TEXT	\N	Intro copy	0	t	{"richText": [{"tag": "h2", "type": "element", "children": [{"type": "text", "value": "Cuándo conviene reparar"}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "Antes de reemplazar, conviene revisar si el sistema todavía tiene una solución práctica. Muchas veces un diagnóstico correcto evita un gasto mayor."}]}, {"tag": "p", "type": "element", "children": [{"type": "text", "value": "Atascos, cintas, láminas, guías o motorización pueden requerir una intervención puntual y seguir funcionando bien."}]}, {"tag": "h3", "type": "element", "children": [{"type": "text", "value": "Puntos clave"}]}, {"tag": "ul", "type": "element", "children": [{"tag": "li", "type": "element", "children": [{"type": "text", "value": "Atascos y trabas"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Láminas o partes dañadas"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Cintas y mecanismos"}]}, {"tag": "li", "type": "element", "children": [{"type": "text", "value": "Motorización y automatismos"}]}]}]}	\N	2026-05-03 16:26:40.795	2026-05-03 16:26:40.795
127	71	CARD	servicios/reparacion-cortinas-y-persianas.html-feature-1	Diagnóstico	0	t	{"body": "Revisamos la falla y definimos si la reparación tiene sentido.", "href": "/contact", "badge": "Step 1", "title": "Diagnóstico", "linkLabel": "Ver más", "headingLevel": "h3"}	30	2026-05-03 16:26:40.796	2026-05-03 16:26:40.796
128	71	CARD	servicios/reparacion-cortinas-y-persianas.html-feature-2	Repuestos	1	t	{"body": "Cuando hace falta, buscamos la pieza o solución más cercana.", "href": "/contact", "badge": "Step 2", "title": "Repuestos", "linkLabel": "Ver más", "headingLevel": "h3"}	33	2026-05-03 16:26:40.797	2026-05-03 16:26:40.797
129	71	CARD	servicios/reparacion-cortinas-y-persianas.html-feature-3	Instalación	2	t	{"body": "Dejamos el sistema funcionando y con una lectura comercial clara.", "href": "/contact", "badge": "Step 3", "title": "Instalación", "linkLabel": "Ver más", "headingLevel": "h3"}	28	2026-05-03 16:26:40.798	2026-05-03 16:26:40.798
130	72	FAQ_ITEM	servicios/reparacion-cortinas-y-persianas.html-faq-1	¿Se puede reparar en obra?	0	t	{"question": "¿Se puede reparar en obra?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Sí, muchas reparaciones se hacen sin reemplazar todo el sistema."}]}]}	\N	2026-05-03 16:26:40.799	2026-05-03 16:26:40.799
131	72	FAQ_ITEM	servicios/reparacion-cortinas-y-persianas.html-faq-2	¿Cuándo conviene cambiar en lugar de reparar?	1	t	{"question": "¿Cuándo conviene cambiar en lugar de reparar?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Cuando la falla es estructural, hay desgaste excesivo o el sistema quedó fuera de uso."}]}]}	\N	2026-05-03 16:26:40.799	2026-05-03 16:26:40.799
132	72	FAQ_ITEM	servicios/reparacion-cortinas-y-persianas.html-faq-3	¿Atienden Montevideo y el interior?	2	t	{"question": "¿Atienden Montevideo y el interior?", "answerRichText": [{"tag": "p", "type": "element", "children": [{"type": "text", "value": "Sí. Coordinamos el alcance según el tipo de trabajo y la ubicación."}]}]}	\N	2026-05-03 16:26:40.799	2026-05-03 16:26:40.799
133	74	IMAGE	0	Cortinas metálicas 1	0	t	{"alt": "Cortinas metálicas", "title": "Cortinas metálicas", "ctaUrl": "/productos/cortinas-metalicas.html", "caption": "Máxima seguridad para locales y accesos.", "ctaLabel": "Ver cortinas metálicas", "mediaUrl": "/uploads/cms/legacy-assets/img/portfolio/cortinas_metalicas/cortina_metalica_1.jpg", "mediaType": "image", "description": "Máxima seguridad para locales y accesos con una línea pensada para uso intensivo.", "mediaPublicId": "/uploads/cms/legacy-assets/img/portfolio/cortinas_metalicas/cortina_metalica_1.jpg"}	73	2026-05-03 16:26:40.802	2026-05-03 16:26:40.802
134	75	IMAGE	0	Cortinas Venecianas 1	0	t	{"alt": "Cortinas Venecianas", "title": "Cortinas Venecianas", "ctaUrl": "/productos/venecianas.html", "caption": "Lamas de 16 mm y 25 mm para controlar luz y privacidad.", "ctaLabel": "Ver venecianas", "mediaUrl": "/uploads/cms/legacy-assets/img/portfolio/venecianas/cortina_veneciana_4.jpeg", "mediaType": "image", "description": "Control de luz y privacidad con una terminación limpia para dormitorios, oficinas y espacios de uso diario.", "mediaPublicId": "/uploads/cms/legacy-assets/img/portfolio/venecianas/cortina_veneciana_4.jpeg"}	74	2026-05-03 16:26:40.804	2026-05-03 16:26:40.804
135	76	IMAGE	0	Bandas verticales 1	0	t	{"alt": "Bandas verticales", "title": "Bandas verticales", "ctaUrl": "/productos/bandas-verticales.html", "caption": "Ideales para ventanales amplios, oficinas y living.", "ctaLabel": "Ver bandas verticales", "mediaUrl": "/uploads/cms/legacy-assets/img/portfolio/bandas_verticales/bandas_verticales_3.jpeg", "mediaType": "image", "description": "Versatilidad y elegancia para oficinas, living y ventanales amplios con control de luz.", "mediaPublicId": "/uploads/cms/legacy-assets/img/portfolio/bandas_verticales/bandas_verticales_3.jpeg"}	70	2026-05-03 16:26:40.806	2026-05-03 16:26:40.806
136	77	IMAGE	0	Cortinas Roller 1	0	t	{"alt": "Cortinas Roller", "title": "Cortinas Roller", "ctaUrl": "/productos/cortinas-roller.html", "caption": "Soluciones para ambientes que necesitan control de luz y un acabado limpio.", "ctaLabel": "Ver cortinas roller", "mediaUrl": "/uploads/cms/legacy-assets/img/portfolio/roller/rollers.png", "mediaType": "image", "description": "Solución interior para regular luz y privacidad con una estética limpia en hogar u oficina.", "mediaPublicId": "/uploads/cms/legacy-assets/img/portfolio/roller/rollers.png"}	75	2026-05-03 16:26:40.808	2026-05-03 16:26:40.808
137	78	IMAGE	0	Motores y automatismos 1	0	t	{"alt": "Motores y automatismos", "title": "Motores y automatismos", "ctaUrl": "/productos/motores-cortinas-y-persianas.html", "caption": "Automatización inteligente para más confort y uso diario.", "ctaLabel": "Ver motores", "mediaUrl": "/uploads/cms/legacy-assets/img/portfolio/motores/persianas_motorizadas.jpg", "mediaType": "image", "description": "Automatización para cortinas roller, persianas y cortinas metálicas con mayor confort diario.", "mediaPublicId": "/uploads/cms/legacy-assets/img/portfolio/motores/persianas_motorizadas.jpg"}	67	2026-05-03 16:26:40.81	2026-05-03 16:26:40.81
138	79	IMAGE	0	Toldos y cerramientos 1	0	t	{"alt": "Toldos y cerramientos", "title": "Toldos y cerramientos", "ctaUrl": "/productos/toldos-y-cerramientos.html", "caption": "Protección solar y solución exterior para distintos usos.", "ctaLabel": "Ver toldos", "mediaUrl": "/uploads/cms/legacy-assets/img/portfolio/toldos/toldo.jpg", "mediaType": "image", "description": "Toldos verticales, de brazo y cerramientos en PVC para sumar sombra, confort y uso exterior.", "mediaPublicId": "/uploads/cms/legacy-assets/img/portfolio/toldos/toldo.jpg"}	76	2026-05-03 16:26:40.812	2026-05-03 16:26:40.812
139	80	IMAGE	0	Aberturas en aluminio 1	0	t	{"alt": "Aberturas en aluminio", "title": "Aberturas en aluminio", "ctaUrl": "/productos/aberturas-aluminio.html", "caption": "Soluciones de alto uso para hogares, comercios y proyectos a medida.", "ctaLabel": "Ver aberturas", "mediaUrl": "/uploads/cms/legacy-assets/img/aberturas/images.jpg", "mediaType": "image", "description": "Una familia para obra y recambio con opciones de vidrio simple o doble vidriado hermético.", "mediaPublicId": "/uploads/cms/legacy-assets/img/aberturas/images.jpg"}	77	2026-05-03 16:26:40.814	2026-05-03 16:26:40.814
140	81	IMAGE	0	Cortinas de enrollar 1	0	t	{"alt": "Cortinas de enrollar", "title": "Cortinas de enrollar", "ctaUrl": "/productos/cortinas-de-enrollar.html", "caption": "Una solución práctica para frentes, hogares y comercios.", "ctaLabel": "Ver cortinas de enrollar", "mediaUrl": "/uploads/cms/legacy-assets/img/portfolio/catalanas/catalanas.png", "mediaType": "image", "description": "Persianas en PVC o aluminio con opción manual o motorizada según uso, exposición y mantenimiento.", "mediaPublicId": "/uploads/cms/legacy-assets/img/portfolio/catalanas/catalanas.png"}	78	2026-05-03 16:26:40.815	2026-05-03 16:26:40.815
141	82	IMAGE	\N	Hero image	0	t	null	19	2026-05-03 16:26:40.817	2026-05-03 16:26:40.817
142	83	CARD	\N	Benefit 1	0	t	{"href": "/product/qa-var-003", "badge": "UX", "title": "Diseño que se entiende rápido", "linkLabel": "Seguir", "description": "La primera lectura queda clara en menos de un scroll."}	16	2026-05-03 16:26:40.818	2026-05-03 16:26:40.818
143	83	CARD	\N	Benefit 2	1	t	{"href": "/product/qa-var-003", "badge": "Proof", "title": "Prueba visual", "linkLabel": "Ver detalle", "description": "Más contexto, menos fricción y mejor lectura del producto."}	79	2026-05-03 16:26:40.819	2026-05-03 16:26:40.819
144	83	CARD	\N	Benefit 3	2	t	{"href": "/product/qa-var-003", "badge": "Conversion", "title": "Compra más segura", "linkLabel": "Ir al checkout", "description": "Narrativa de marca + media + CTA en la misma superficie."}	80	2026-05-03 16:26:40.82	2026-05-03 16:26:40.82
145	84	CARD	\N	Primary video	0	t	{"title": "Producto Variable QA API 2 en uso", "description": "El video principal refuerza la intención de compra."}	44	2026-05-03 16:26:40.821	2026-05-03 16:26:40.821
146	84	CARD	\N	Secondary visual	1	t	{"title": "Detalle secundario", "description": "Apoyo editorial para completar la historia visual."}	81	2026-05-03 16:26:40.822	2026-05-03 16:26:40.822
147	85	CARD	\N	Grid item 1	0	t	{"href": "/categories", "badge": "Editorial", "title": "Producto Variable QA API 2 editorial", "linkLabel": "Explorar", "description": "Una pieza de marca para elevar percepción.", "overlayText": true}	19	2026-05-03 16:26:40.823	2026-05-03 16:26:40.823
148	85	CARD	\N	Grid item 2	1	t	{"href": "/product/qa-var-003", "badge": "Detail", "title": "Producto Variable QA API 2 detalle", "linkLabel": "Ver más", "description": "Más peso visual sobre terminaciones y escala.", "overlayText": true}	79	2026-05-03 16:26:40.824	2026-05-03 16:26:40.824
151	88	CARD	\N	Benefit 1	0	t	{"href": "/product/ventana-corrediza-20-blanco-3mm-1200x2000", "badge": "UX", "title": "Diseño que se entiende rápido", "linkLabel": "Seguir", "description": "La primera lectura queda clara en menos de un scroll."}	17	2026-05-03 16:26:40.828	2026-05-03 16:26:40.828
152	88	CARD	\N	Benefit 2	1	t	{"href": "/product/ventana-corrediza-20-blanco-3mm-1200x2000", "badge": "Proof", "title": "Prueba visual", "linkLabel": "Ver detalle", "description": "Más contexto, menos fricción y mejor lectura del producto."}	5	2026-05-03 16:26:40.829	2026-05-03 16:26:40.829
153	88	CARD	\N	Benefit 3	2	t	{"href": "/product/ventana-corrediza-20-blanco-3mm-1200x2000", "badge": "Conversion", "title": "Compra más segura", "linkLabel": "Ir al checkout", "description": "Narrativa de marca + media + CTA en la misma superficie."}	6	2026-05-03 16:26:40.83	2026-05-03 16:26:40.83
154	89	CARD	\N	Primary video	0	t	{"title": "Ventana Corrediza 20 Blanco 3mm 1200x2000 en uso", "description": "El video principal refuerza la intención de compra."}	44	2026-05-03 16:26:40.831	2026-05-03 16:26:40.831
155	89	CARD	\N	Secondary visual	1	t	{"title": "Detalle secundario", "description": "Apoyo editorial para completar la historia visual."}	7	2026-05-03 16:26:40.832	2026-05-03 16:26:40.832
156	90	CARD	\N	Grid item 1	0	t	{"href": "/categories", "badge": "Editorial", "title": "Ventana Corrediza 20 Blanco 3mm 1200x2000 editorial", "linkLabel": "Explorar", "description": "Una pieza de marca para elevar percepción.", "overlayText": true}	82	2026-05-03 16:26:40.833	2026-05-03 16:26:40.833
157	90	CARD	\N	Grid item 2	1	t	{"href": "/product/ventana-corrediza-20-blanco-3mm-1200x2000", "badge": "Detail", "title": "Ventana Corrediza 20 Blanco 3mm 1200x2000 detalle", "linkLabel": "Ver más", "description": "Más peso visual sobre terminaciones y escala.", "overlayText": true}	5	2026-05-03 16:26:40.834	2026-05-03 16:26:40.834
158	90	CARD	\N	Grid item 3	2	t	{"href": "/categories", "badge": "Use case", "title": "Ventana Corrediza 20 Blanco 3mm 1200x2000 lifestyle", "linkLabel": "Ir a categoría", "description": "El contexto de uso reduce la fricción de decisión.", "overlayText": true}	6	2026-05-03 16:26:40.835	2026-05-03 16:26:40.835
159	92	IMAGE	\N	Hero image	0	t	null	22	2026-05-03 16:26:40.837	2026-05-03 16:26:40.837
160	93	CARD	\N	Benefit 1	0	t	{"href": "/product/ventana-corrediza-20-blanco-3mm-1400x600", "badge": "UX", "title": "Diseño que se entiende rápido", "linkLabel": "Seguir", "description": "La primera lectura queda clara en menos de un scroll."}	18	2026-05-03 16:26:40.839	2026-05-03 16:26:40.839
161	93	CARD	\N	Benefit 2	1	t	{"href": "/product/ventana-corrediza-20-blanco-3mm-1400x600", "badge": "Proof", "title": "Prueba visual", "linkLabel": "Ver detalle", "description": "Más contexto, menos fricción y mejor lectura del producto."}	8	2026-05-03 16:26:40.84	2026-05-03 16:26:40.84
162	93	CARD	\N	Benefit 3	2	t	{"href": "/product/ventana-corrediza-20-blanco-3mm-1400x600", "badge": "Conversion", "title": "Compra más segura", "linkLabel": "Ir al checkout", "description": "Narrativa de marca + media + CTA en la misma superficie."}	83	2026-05-03 16:26:40.841	2026-05-03 16:26:40.841
163	94	CARD	\N	Primary video	0	t	{"title": "Ventana Corrediza 20 Blanco 3mm 1400x600 en uso", "description": "El video principal refuerza la intención de compra."}	44	2026-05-03 16:26:40.842	2026-05-03 16:26:40.842
164	94	CARD	\N	Secondary visual	1	t	{"title": "Detalle secundario", "description": "Apoyo editorial para completar la historia visual."}	3	2026-05-03 16:26:40.843	2026-05-03 16:26:40.843
165	95	CARD	\N	Grid item 1	0	t	{"href": "/categories", "badge": "Editorial", "title": "Ventana Corrediza 20 Blanco 3mm 1400x600 editorial", "linkLabel": "Explorar", "description": "Una pieza de marca para elevar percepción.", "overlayText": true}	22	2026-05-03 16:26:40.844	2026-05-03 16:26:40.844
166	95	CARD	\N	Grid item 2	1	t	{"href": "/product/ventana-corrediza-20-blanco-3mm-1400x600", "badge": "Detail", "title": "Ventana Corrediza 20 Blanco 3mm 1400x600 detalle", "linkLabel": "Ver más", "description": "Más peso visual sobre terminaciones y escala.", "overlayText": true}	8	2026-05-03 16:26:40.845	2026-05-03 16:26:40.845
167	95	CARD	\N	Grid item 3	2	t	{"href": "/categories", "badge": "Use case", "title": "Ventana Corrediza 20 Blanco 3mm 1400x600 lifestyle", "linkLabel": "Ir a categoría", "description": "El contexto de uso reduce la fricción de decisión.", "overlayText": true}	83	2026-05-03 16:26:40.846	2026-05-03 16:26:40.846
168	97	IMAGE	\N	Hero image	0	t	null	25	2026-05-03 16:26:40.849	2026-05-03 16:26:40.849
169	98	CARD	\N	Benefit 1	0	t	{"href": "/product/ventana-corrediza-20-blanco-3mm-1500x1500", "badge": "UX", "title": "Diseño que se entiende rápido", "linkLabel": "Seguir", "description": "La primera lectura queda clara en menos de un scroll."}	84	2026-05-03 16:26:40.85	2026-05-03 16:26:40.85
170	98	CARD	\N	Benefit 2	1	t	{"href": "/product/ventana-corrediza-20-blanco-3mm-1500x1500", "badge": "Proof", "title": "Prueba visual", "linkLabel": "Ver detalle", "description": "Más contexto, menos fricción y mejor lectura del producto."}	84	2026-05-03 16:26:40.851	2026-05-03 16:26:40.851
171	98	CARD	\N	Benefit 3	2	t	{"href": "/product/ventana-corrediza-20-blanco-3mm-1500x1500", "badge": "Conversion", "title": "Compra más segura", "linkLabel": "Ir al checkout", "description": "Narrativa de marca + media + CTA en la misma superficie."}	1	2026-05-03 16:26:40.853	2026-05-03 16:26:40.853
172	99	CARD	\N	Primary video	0	t	{"title": "Ventana Corrediza 20 Blanco 3mm 1500x1500 en uso", "description": "El video principal refuerza la intención de compra."}	44	2026-05-03 16:26:40.854	2026-05-03 16:26:40.854
173	99	CARD	\N	Secondary visual	1	t	{"title": "Detalle secundario", "description": "Apoyo editorial para completar la historia visual."}	2	2026-05-03 16:26:40.855	2026-05-03 16:26:40.855
174	100	CARD	\N	Grid item 1	0	t	{"href": "/categories", "badge": "Editorial", "title": "Ventana Corrediza 20 Blanco 3mm 1500x1500 editorial", "linkLabel": "Explorar", "description": "Una pieza de marca para elevar percepción.", "overlayText": true}	25	2026-05-03 16:26:40.856	2026-05-03 16:26:40.856
175	100	CARD	\N	Grid item 2	1	t	{"href": "/product/ventana-corrediza-20-blanco-3mm-1500x1500", "badge": "Detail", "title": "Ventana Corrediza 20 Blanco 3mm 1500x1500 detalle", "linkLabel": "Ver más", "description": "Más peso visual sobre terminaciones y escala.", "overlayText": true}	84	2026-05-03 16:26:40.857	2026-05-03 16:26:40.857
176	100	CARD	\N	Grid item 3	2	t	{"href": "/categories", "badge": "Use case", "title": "Ventana Corrediza 20 Blanco 3mm 1500x1500 lifestyle", "linkLabel": "Ir a categoría", "description": "El contexto de uso reduce la fricción de decisión.", "overlayText": true}	1	2026-05-03 16:26:40.858	2026-05-03 16:26:40.858
177	102	IMAGE	\N	Hero image	0	t	null	26	2026-05-03 16:26:40.86	2026-05-03 16:26:40.86
178	103	CARD	\N	Benefit 1	0	t	{"href": "/product/ventana-corrediza-20-blanco-3mm-1500x2000", "badge": "UX", "title": "Diseño que se entiende rápido", "linkLabel": "Seguir", "description": "La primera lectura queda clara en menos de un scroll."}	85	2026-05-03 16:26:40.861	2026-05-03 16:26:40.861
179	103	CARD	\N	Benefit 2	1	t	{"href": "/product/ventana-corrediza-20-blanco-3mm-1500x2000", "badge": "Proof", "title": "Prueba visual", "linkLabel": "Ver detalle", "description": "Más contexto, menos fricción y mejor lectura del producto."}	2	2026-05-03 16:26:40.862	2026-05-03 16:26:40.862
180	103	CARD	\N	Benefit 3	2	t	{"href": "/product/ventana-corrediza-20-blanco-3mm-1500x2000", "badge": "Conversion", "title": "Compra más segura", "linkLabel": "Ir al checkout", "description": "Narrativa de marca + media + CTA en la misma superficie."}	85	2026-05-03 16:26:40.863	2026-05-03 16:26:40.863
181	104	CARD	\N	Primary video	0	t	{"title": "Ventana Corrediza 20 Blanco 3mm 1500x2000 en uso", "description": "El video principal refuerza la intención de compra."}	44	2026-05-03 16:26:40.864	2026-05-03 16:26:40.864
182	104	CARD	\N	Secondary visual	1	t	{"title": "Detalle secundario", "description": "Apoyo editorial para completar la historia visual."}	86	2026-05-03 16:26:40.865	2026-05-03 16:26:40.865
183	105	CARD	\N	Grid item 1	0	t	{"href": "/categories", "badge": "Editorial", "title": "Ventana Corrediza 20 Blanco 3mm 1500x2000 editorial", "linkLabel": "Explorar", "description": "Una pieza de marca para elevar percepción.", "overlayText": true}	26	2026-05-03 16:26:40.866	2026-05-03 16:26:40.866
184	105	CARD	\N	Grid item 2	1	t	{"href": "/product/ventana-corrediza-20-blanco-3mm-1500x2000", "badge": "Detail", "title": "Ventana Corrediza 20 Blanco 3mm 1500x2000 detalle", "linkLabel": "Ver más", "description": "Más peso visual sobre terminaciones y escala.", "overlayText": true}	2	2026-05-03 16:26:40.867	2026-05-03 16:26:40.867
185	105	CARD	\N	Grid item 3	2	t	{"href": "/categories", "badge": "Use case", "title": "Ventana Corrediza 20 Blanco 3mm 1500x2000 lifestyle", "linkLabel": "Ir a categoría", "description": "El contexto de uso reduce la fricción de decisión.", "overlayText": true}	85	2026-05-03 16:26:40.868	2026-05-03 16:26:40.868
\.


--
-- Data for Name: CmsPageSection; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CmsPageSection" (id, "pageId", type, key, name, "sortOrder", visible, settings, "createdAt", "updatedAt") FROM stdin;
1	1	SITE_HEADER	site-header	\N	0	t	{"items": [{"href": "/", "label": "Inicio"}, {"href": "/shop", "label": "Tienda"}, {"href": "/shop", "items": [{"href": "/productos/cortinas-roller.html", "label": "Cortinas Roller"}, {"href": "/productos/cortinas-de-enrollar.html", "label": "Cortinas de enrollar"}, {"href": "/productos/bandas-verticales.html", "label": "Bandas verticales"}, {"href": "/productos/venecianas.html", "label": "Venecianas"}, {"href": "/productos/aberturas-aluminio.html", "label": "Aberturas en aluminio"}, {"href": "/productos/toldos-y-cerramientos.html", "label": "Toldos y cerramientos"}, {"href": "/productos/motores-cortinas-y-persianas.html", "label": "Motores y automatismos"}, {"href": "/productos/cortinas-metalicas.html", "label": "Cortinas metálicas"}], "label": "Productos"}, {"href": "/servicios/reparacion-cortinas-y-persianas.html", "items": [{"href": "/servicios/reparacion-cortinas-y-persianas.html", "label": "Reparación"}, {"href": "/servicios/reparacion-urgente", "label": "Reparación urgente"}, {"href": "/servicios/instalacion-aberturas.html", "label": "Instalación de aberturas"}], "label": "Servicios"}, {"href": "/guias/cortinas-pvc-vs-aluminio", "items": [{"href": "/guias/cortinas-pvc-vs-aluminio", "items": [{"href": "/guias/cortinas-pvc-vs-aluminio", "label": "PVC vs aluminio"}, {"href": "/guias/medicion", "label": "Medición"}, {"href": "/guias/cortinas-roller", "label": "Cortinas roller"}, {"href": "/guias/bandas-verticales", "label": "Bandas verticales"}, {"href": "/guias/motores-cortinas-y-persianas", "label": "Motores"}, {"href": "/precios/cortinas-de-enrollar", "label": "Precios de cortinas"}, {"href": "/productos/dvh.html", "label": "Qué es DVH"}], "label": "Guías"}, {"href": "/quienes-somos", "label": "Quiénes somos"}, {"href": "/preguntas-frecuentes", "label": "Preguntas frecuentes"}], "label": "Información"}, {"href": "/contacto.html", "label": "Contacto"}]}	2026-05-03 16:26:40.642	2026-05-03 16:26:40.642
2	1	HERO	home-hero	\N	1	t	{"title": "Soluciones a medida para hogar, comercio y obra", "slides": [{"href": "/productos/cortinas-de-enrollar.html", "title": "Cortinas de enrollar para obra nueva o recambio", "imageAlt": "Cortinas de enrollar", "imageUrl": "/uploads/cms/legacy-assets/img/portfolio/catalanas/catalanas.png", "linkLabel": "Ver cortinas de enrollar", "description": "Una opción práctica para frentes, hogares y comercios que necesitan resistencia, control y mantenimiento simple."}, {"href": "/productos/aberturas-aluminio.html", "title": "Aberturas en aluminio con vidrio simple o DVH", "imageAlt": "Aberturas en aluminio", "imageUrl": "/uploads/cms/legacy-assets/img/aberturas/images.jpg", "linkLabel": "Ver aberturas", "description": "Soluciones en serie 20 y 25 para obra y recambio con mejor aislamiento, terminación y durabilidad."}, {"href": "/productos/toldos-y-cerramientos.html", "title": "Toldos y cerramientos para exterior", "imageAlt": "Toldos y cerramientos", "imageUrl": "/uploads/cms/legacy-assets/img/portfolio/toldos/toldo.jpg", "linkLabel": "Ver toldos", "description": "Protección solar, sombra y uso exterior para resolver el espacio con una solución a medida."}, {"href": "/productos/motores-cortinas-y-persianas.html", "title": "Motores y automatismos para más confort", "imageAlt": "Motores y automatismos", "imageUrl": "/uploads/cms/legacy-assets/img/portfolio/motores/persianas_motorizadas.jpg", "linkLabel": "Ver motores", "description": "Automatización para cortinas roller, persianas y cortinas metálicas con más comodidad en el uso diario."}], "eyebrow": "Urucortinas", "description": "Cortinas de enrollar, aberturas, toldos y automatización con instalación, reparación y asesoramiento real.", "headingLevel": "h1", "primaryCtaHref": "/productos/cortinas-de-enrollar.html", "primaryCtaLabel": "Ver cortinas de enrollar", "secondaryCtaHref": "/shop", "secondaryCtaLabel": "Explorar catálogo", "backgroundImageUrl": "/uploads/cms/legacy-assets/img/intro-carousel/roller-6.jpeg"}	2026-05-03 16:26:40.643	2026-05-03 16:26:40.643
3	1	MEDIA_GRID_ENHANCED	home-shop-categories	\N	2	t	{"title": "Explorá nuestra tienda por categoría", "variant": "categories", "description": "Entrá por la línea que buscás y descubrí opciones reales para avanzar más rápido."}	2026-05-03 16:26:40.643	2026-05-03 16:26:40.643
4	1	MEDIA_GRID_ENHANCED	home-products-grid	\N	3	t	{"gap": 1.1, "title": "Informate sobre nuestros productos principales", "columns": 4, "aspectRatio": "4 / 5", "description": "Conocé las soluciones más buscadas para interior, exterior, obra, recambio y automatización."}	2026-05-03 16:26:40.643	2026-05-03 16:26:40.643
5	1	HIGHLIGHT_CARDS	home-commercial-support	\N	4	t	{"title": "Acompañamiento comercial real", "description": "Visitas, medidas, pagos y garantía para avanzar con más claridad antes de confirmar el trabajo."}	2026-05-03 16:26:40.651	2026-05-03 16:26:40.651
6	1	CTA_BANNER	home-aberturas-cta	\N	5	t	{"href": "/shop", "label": "Ir a la tienda", "title": "Explorá la tienda o pedí asesoramiento", "intent": "transactional", "description": "Si todavía estás comparando opciones, podés recorrer el catálogo, ver productos o escribirnos para decidir más rápido."}	2026-05-03 16:26:40.655	2026-05-03 16:26:40.655
7	1	MEDIA_CAROUSEL	home-clients-carousel	\N	6	t	{"title": "Clientes que confiaron en nuestro trabajo", "variant": "logos", "autoplay": true, "description": "Marcas e instituciones que nos eligieron para distintos proyectos.", "slidesToShow": 5, "spaceBetween": 18, "autoplaySpeed": 2800}	2026-05-03 16:26:40.656	2026-05-03 16:26:40.656
8	1	SITE_FOOTER	site-footer	\N	7	t	{"socials": [{"href": "https://instagram.com", "label": "Instagram", "external": true}, {"href": "https://facebook.com", "label": "Facebook", "external": true}], "helpLinks": [{"href": "/preguntas-frecuentes", "label": "Preguntas frecuentes"}, {"href": "/quienes-somos", "label": "Quiénes somos"}], "linkGroups": [[{"href": "/shop", "label": "Tienda"}, {"href": "/productos/cortinas-roller.html", "label": "Cortinas Roller"}, {"href": "/productos/cortinas-de-enrollar.html", "label": "Cortinas de enrollar"}, {"href": "/productos/bandas-verticales.html", "label": "Bandas verticales"}], [{"href": "/productos/venecianas.html", "label": "Venecianas"}, {"href": "/productos/aberturas-aluminio.html", "label": "Aberturas en aluminio"}, {"href": "/productos/toldos-y-cerramientos.html", "label": "Toldos y cerramientos"}, {"href": "/productos/motores-cortinas-y-persianas.html", "label": "Motores"}], [{"href": "/servicios/reparacion-cortinas-y-persianas.html", "label": "Reparación"}, {"href": "/guias/cortinas-pvc-vs-aluminio", "label": "Guía PVC vs aluminio"}, {"href": "/precios/cortinas-de-enrollar", "label": "Precios de cortinas"}, {"href": "/contacto.html", "label": "Contacto"}]]}	2026-05-03 16:26:40.662	2026-05-03 16:26:40.662
9	2	MEDIA_HERO	categories-hero	\N	0	t	{"title": "Elegí por necesidad y avanzá más rápido", "eyebrow": "Catálogo visual", "overlay": true, "mediaAlt": "Categorías Urucortinas", "subtitle": "Cortinas de enrollar, aberturas, toldos, motores y soluciones para interior y exterior con una lectura más clara.", "mediaType": "image", "primaryCta": {"href": "/shop", "label": "Explorar catálogo"}, "secondaryCta": {"href": "/productos/cortinas-de-enrollar.html", "label": "Ver cortinas de enrollar"}, "overlayOpacity": 0.62}	2026-05-03 16:26:40.663	2026-05-03 16:26:40.663
10	2	HIGHLIGHT_CARDS	categories-highlights	\N	1	t	{"title": "Accesos rápidos por necesidad", "description": "Bloques de navegación para entrar por uso, exposición o etapa de obra."}	2026-05-03 16:26:40.664	2026-05-03 16:26:40.664
11	2	VIDEO_SECTION	categories-video	\N	2	t	{"title": "Uso real y demostración", "layout": "contained", "autoplay": false, "controls": true, "description": "Un bloque corto para despejar dudas, reforzar terminaciones y acelerar la decisión."}	2026-05-03 16:26:40.668	2026-05-03 16:26:40.668
12	2	MEDIA_GRID_ENHANCED	categories-grid	\N	3	t	{"gap": 1.1, "title": "Selecciones visuales", "columns": 3, "aspectRatio": "4 / 5", "description": "Una grilla para inspirar y llevar tráfico a productos o categorías."}	2026-05-03 16:26:40.67	2026-05-03 16:26:40.67
13	2	CTA_BANNER	categories-cta	\N	4	t	{"href": "/shop", "label": "Ir al catálogo", "title": "Volvé al catálogo con una intención más clara", "intent": "navigation", "description": "La navegación visual reduce fricción y mejora la calidad de clic."}	2026-05-03 16:26:40.673	2026-05-03 16:26:40.673
14	3	MEDIA_HERO	guias/cortinas-pvc-vs-aluminio-hero	\N	0	t	{"title": "PVC o aluminio: elegí la cortina de enrollar correcta", "eyebrow": "Guía de decisión", "overlay": true, "mediaAlt": "Cortinas de enrollar en aluminio", "subtitle": "Compará durabilidad, mantenimiento y exposición para decidir con menos dudas.", "mediaType": "image", "primaryCta": {"href": "/productos/cortinas-de-enrollar.html", "label": "Ver cortinas de enrollar"}, "secondaryCta": {"href": "/precios/cortinas-de-enrollar", "label": "Ver precios"}, "overlayOpacity": 0.6}	2026-05-03 16:26:40.674	2026-05-03 16:26:40.674
46	9	FEATURE_GRID	guias/como-medir-ancho-y-alto-features	\N	2	t	{"title": "Tres cosas que no conviene olvidar", "description": "La cotización mejora cuando la medición llega completa.", "itemHeadingLevel": "h3"}	2026-05-03 16:26:40.756	2026-05-03 16:26:40.756
15	3	CONTENT_SPLIT	guias/cortinas-pvc-vs-aluminio-intro	\N	1	t	{"title": "", "gallery": [{"href": "", "imageAlt": "Cortinas de enrollar 1", "imageUrl": "/media/products/cortinas-de-enrollar-aluminio/images/catalana_1.jpeg", "linkLabel": ""}, {"href": "", "imageAlt": "Cortinas de enrollar 2", "imageUrl": "/media/products/cortinas-de-enrollar-aluminio/images/IMG-20240826-WA0159.jpg", "linkLabel": ""}, {"href": "", "imageAlt": "Cortinas de enrollar 3", "imageUrl": "/media/products/cortinas-de-enrollar-aluminio/images/catalana_1.jpeg", "linkLabel": ""}], "variant": "media-gallery-content", "imageAlt": "Cortinas de enrollar en uso", "imageUrl": "/media/products/cortinas-de-enrollar-aluminio/images/IMG-20240826-WA0159.jpg", "description": "", "mediaPosition": "start"}	2026-05-03 16:26:40.675	2026-05-03 16:26:40.675
16	3	FEATURE_GRID	guias/cortinas-pvc-vs-aluminio-features	\N	2	t	{"title": "Qué mirar antes de elegir", "description": "Tres criterios simples para decidir sin perder tiempo.", "itemHeadingLevel": "h3"}	2026-05-03 16:26:40.676	2026-05-03 16:26:40.676
17	3	FAQ	guias/cortinas-pvc-vs-aluminio-faq	\N	3	t	{"title": "Preguntas frecuentes", "description": "Respuestas cortas para avanzar con más seguridad."}	2026-05-03 16:26:40.679	2026-05-03 16:26:40.679
18	3	CTA_BANNER	guias/cortinas-pvc-vs-aluminio-cta	\N	4	t	{"title": "Pedí una orientación comercial y compará opciones reales", "intent": "transactional", "actions": [{"href": "/contact", "label": "Solicitar visita"}, {"href": "/precios/cortinas-de-enrollar", "label": "Ver precios"}, {"href": "/multimedia", "label": "Ver fotos y videos"}], "description": "Te ayudamos a bajar la decisión a medidas, uso y presupuesto."}	2026-05-03 16:26:40.681	2026-05-03 16:26:40.681
19	4	MEDIA_HERO	guias/dvh-hero	\N	0	t	{"title": "DVH: más confort, menos ruido y mejor percepción de valor", "eyebrow": "Guía técnica", "overlay": true, "mediaAlt": "Aberturas en aluminio con DVH", "subtitle": "Una explicación breve para decidir con más claridad en obra o recambio.", "mediaType": "image", "primaryCta": {"href": "/productos/aberturas-aluminio.html", "label": "Ver aberturas"}, "secondaryCta": {"href": "/guias/probba-vs-gala", "label": "Ver serie 20 y 25"}, "overlayOpacity": 0.6}	2026-05-03 16:26:40.682	2026-05-03 16:26:40.682
20	4	CONTENT_SPLIT	guias/dvh-intro	\N	1	t	{"title": "", "gallery": [{"href": "", "imageAlt": "DVH 1", "imageUrl": "/media/products/aberturas-aluminio/images/aberturas__32807525_580319532349310_975320518108381184_n.jpg", "linkLabel": ""}, {"href": "", "imageAlt": "DVH 2", "imageUrl": "/media/products/aberturas-aluminio/images/aberturas__32807525_580319532349310_975320518108381184_n.jpg", "linkLabel": ""}, {"href": "", "imageAlt": "DVH 3", "imageUrl": "/media/products/aberturas-aluminio/images/aberturas__32807525_580319532349310_975320518108381184_n.jpg", "linkLabel": ""}], "variant": "media-gallery-content", "imageAlt": "Doble vidriado hermético", "imageUrl": "/media/products/aberturas-aluminio/images/aberturas__32807525_580319532349310_975320518108381184_n.jpg", "description": "", "mediaPosition": "start"}	2026-05-03 16:26:40.683	2026-05-03 16:26:40.683
21	4	FEATURE_GRID	guias/dvh-features	\N	2	t	{"title": "Beneficios más claros del DVH", "description": "Tres motivos frecuentes para sumar doble vidrio hermético.", "itemHeadingLevel": "h3"}	2026-05-03 16:26:40.684	2026-05-03 16:26:40.684
22	4	FAQ	guias/dvh-faq	\N	3	t	{"title": "Preguntas frecuentes", "description": "Respuestas cortas para decidir si conviene sumar DVH."}	2026-05-03 16:26:40.708	2026-05-03 16:26:40.708
23	4	CTA_BANNER	guias/dvh-cta	\N	4	t	{"title": "Pedí asesoramiento para combinar serie y vidrio", "intent": "transactional", "actions": [{"href": "/productos/aberturas-aluminio.html", "label": "Ver aberturas"}, {"href": "/contacto.html", "label": "Consultar medidas"}, {"href": "/guias/probba-vs-gala", "label": "Ver guía de series"}], "description": "Te ayudamos a elegir la abertura correcta según uso, exposición y presupuesto."}	2026-05-03 16:26:40.715	2026-05-03 16:26:40.715
24	5	MEDIA_HERO	guias/probba-vs-gala-hero	\N	0	t	{"title": "Probba, Gala y serie 25: cómo elegir la abertura correcta", "eyebrow": "Comparativa técnica", "overlay": true, "mediaAlt": "Series de aberturas de aluminio", "subtitle": "Una guía corta para entender las diferencias sin perder tiempo.", "mediaType": "image", "primaryCta": {"href": "/productos/aberturas-aluminio.html", "label": "Ver aberturas"}, "secondaryCta": {"href": "/guias/dvh", "label": "Ver DVH"}, "overlayOpacity": 0.6}	2026-05-03 16:26:40.716	2026-05-03 16:26:40.716
25	5	CONTENT_SPLIT	guias/probba-vs-gala-intro	\N	1	t	{"title": "", "gallery": [{"href": "", "imageAlt": "Serie 20", "imageUrl": "/media/products/aberturas-aluminio/images/aberturas__32807525_580319532349310_975320518108381184_n.jpg", "linkLabel": ""}, {"href": "", "imageAlt": "Serie 25", "imageUrl": "/media/products/aberturas-aluminio/images/aberturas__32807525_580319532349310_975320518108381184_n.jpg", "linkLabel": ""}, {"href": "", "imageAlt": "Alta prestación", "imageUrl": "/media/products/aberturas-aluminio/images/aberturas__32807525_580319532349310_975320518108381184_n.jpg", "linkLabel": ""}], "variant": "media-gallery-content", "imageAlt": "Series de aluminio", "imageUrl": "/media/products/aberturas-aluminio/images/aberturas__32807525_580319532349310_975320518108381184_n.jpg", "description": "", "mediaPosition": "start"}	2026-05-03 16:26:40.718	2026-05-03 16:26:40.718
26	5	FEATURE_GRID	guias/probba-vs-gala-features	\N	2	t	{"title": "Cómo pensar la elección", "description": "Tres niveles de lectura para elegir sin fricción.", "itemHeadingLevel": "h3"}	2026-05-03 16:26:40.718	2026-05-03 16:26:40.718
27	5	FAQ	guias/probba-vs-gala-faq	\N	3	t	{"title": "Preguntas frecuentes", "description": "Respuestas breves para bajar el ruido de decisión."}	2026-05-03 16:26:40.721	2026-05-03 16:26:40.721
28	5	CTA_BANNER	guias/probba-vs-gala-cta	\N	4	t	{"title": "Te ayudamos a elegir la serie correcta", "intent": "transactional", "actions": [{"href": "/productos/aberturas-aluminio.html", "label": "Ver aberturas"}, {"href": "/contacto.html", "label": "Consultar medidas"}, {"href": "/guias/dvh", "label": "Ver guía DVH"}], "description": "Si ya tenés medidas aproximadas, te orientamos más rápido con una propuesta concreta."}	2026-05-03 16:26:40.723	2026-05-03 16:26:40.723
29	6	MEDIA_HERO	guias/aberturas-probba-hero	\N	0	t	{"title": "Serie Probba: qué tipologías ofrece y cómo leer sus terminaciones", "eyebrow": "Guía de aberturas", "overlay": true, "mediaAlt": "Serie Probba de aberturas de aluminio", "subtitle": "Una guía práctica para entender la alta prestación de entrada sin ruido técnico.", "mediaType": "image", "primaryCta": {"href": "/productos/aberturas-probba.html", "label": "Ver serie Probba"}, "secondaryCta": {"href": "/guias/dvh", "label": "Ver guía DVH"}, "overlayOpacity": 0.6}	2026-05-03 16:26:40.724	2026-05-03 16:26:40.724
47	9	FAQ	guias/como-medir-ancho-y-alto-faq	\N	3	t	{"title": "Preguntas frecuentes", "description": "Respuestas simples para reducir dudas antes de cotizar."}	2026-05-03 16:26:40.759	2026-05-03 16:26:40.759
48	9	CTA_BANNER	guias/como-medir-ancho-y-alto-cta	\N	4	t	{"title": "Si ya tenés una medida aproximada, seguimos desde ahí", "intent": "transactional", "actions": [{"href": "/contact", "label": "Solicitar visita"}, {"href": "/precios/cortinas-de-enrollar", "label": "Ver precios"}, {"href": "/multimedia", "label": "Ver multimedia"}], "description": "Podemos revisar el dato y orientarte con mayor precisión."}	2026-05-03 16:26:40.761	2026-05-03 16:26:40.761
30	6	CONTENT_SPLIT	guias/aberturas-probba-intro	\N	1	t	{"title": "", "gallery": [{"href": "", "imageAlt": "Probba sistema", "imageUrl": "/uploads/cms/legacy-assets/img/aberturas/probba_sistema.png", "linkLabel": ""}, {"href": "", "imageAlt": "Terminación Probba", "imageUrl": "/uploads/cms/legacy-assets/img/aberturas/probba_terminacion_registrada1.jpg", "linkLabel": ""}, {"href": "", "imageAlt": "Probba corrediza", "imageUrl": "/uploads/cms/legacy-assets/img/aberturas/probba_ventana_y_puerta_corrediza2.jpg", "linkLabel": ""}], "variant": "media-gallery-content", "imageAlt": "Terminación registrada Probba", "imageUrl": "/uploads/cms/legacy-assets/img/aberturas/probba_terminacion_registrada1.jpg", "description": "", "mediaPosition": "start"}	2026-05-03 16:26:40.725	2026-05-03 16:26:40.725
31	6	FEATURE_GRID	guias/aberturas-probba-features	\N	2	t	{"title": "Tipologías de Probba", "description": "Las tipologías más usadas en la serie Probba y su lectura comercial.", "itemHeadingLevel": "h3"}	2026-05-03 16:26:40.726	2026-05-03 16:26:40.726
32	6	FAQ	guias/aberturas-probba-faq	\N	3	t	{"title": "Preguntas frecuentes", "description": "Respuestas rápidas para elegir mejor la serie Probba."}	2026-05-03 16:26:40.733	2026-05-03 16:26:40.733
33	6	CTA_BANNER	guias/aberturas-probba-cta	\N	4	t	{"title": "Si ya definiste la serie, te ayudamos a bajar el presupuesto", "intent": "transactional", "actions": [{"href": "/productos/aberturas-probba.html", "label": "Ver serie Probba"}, {"href": "/contacto.html", "label": "Consultar medidas"}, {"href": "/guias/dvh", "label": "Ver guía DVH"}], "description": "Podemos orientar la elección según medidas, uso y terminación."}	2026-05-03 16:26:40.735	2026-05-03 16:26:40.735
34	7	MEDIA_HERO	guias/aberturas-gala-hero	\N	0	t	{"title": "Serie Gala: más confort y mejor terminación", "eyebrow": "Guía de aberturas", "overlay": true, "mediaAlt": "Serie Gala de aberturas de aluminio", "subtitle": "Una guía simple para entender cuándo conviene la línea Gala y cuándo mirar Gala CR.", "mediaType": "image", "primaryCta": {"href": "/productos/aberturas-gala.html", "label": "Ver serie Gala"}, "secondaryCta": {"href": "/guias/dvh", "label": "Ver guía DVH"}, "overlayOpacity": 0.6}	2026-05-03 16:26:40.736	2026-05-03 16:26:40.736
35	7	CONTENT_SPLIT	guias/aberturas-gala-intro	\N	1	t	{"title": "", "gallery": [{"href": "", "imageAlt": "Gala sistema", "imageUrl": "/uploads/cms/legacy-assets/img/aberturas/gala_sistema.png", "linkLabel": ""}, {"href": "", "imageAlt": "Gala CR", "imageUrl": "/uploads/cms/legacy-assets/img/aberturas/gala_cr_parrafo.jpg", "linkLabel": ""}, {"href": "", "imageAlt": "Gala terminación", "imageUrl": "/uploads/cms/legacy-assets/img/aberturas/gala_bg_prod.jpg", "linkLabel": ""}], "variant": "media-gallery-content", "imageAlt": "Serie Gala", "imageUrl": "/uploads/cms/legacy-assets/img/aberturas/parrafo_gala-subsistema.jpg", "description": "", "mediaPosition": "start"}	2026-05-03 16:26:40.737	2026-05-03 16:26:40.737
36	7	FEATURE_GRID	guias/aberturas-gala-features	\N	2	t	{"title": "Cómo leer la serie Gala", "description": "Tres lecturas simples para decidir mejor.", "itemHeadingLevel": "h3"}	2026-05-03 16:26:40.738	2026-05-03 16:26:40.738
37	7	FAQ	guias/aberturas-gala-faq	\N	3	t	{"title": "Preguntas frecuentes", "description": "Respuestas breves para decidir sin perder foco."}	2026-05-03 16:26:40.742	2026-05-03 16:26:40.742
38	7	CTA_BANNER	guias/aberturas-gala-cta	\N	4	t	{"title": "Si buscás confort y terminación, seguimos por Gala", "intent": "transactional", "actions": [{"href": "/productos/aberturas-gala.html", "label": "Ver serie Gala"}, {"href": "/contacto.html", "label": "Consultar medidas"}, {"href": "/guias/dvh", "label": "Ver guía DVH"}], "description": "Te ayudamos a definir medidas, apertura y combinación con DVH."}	2026-05-03 16:26:40.743	2026-05-03 16:26:40.743
39	8	MEDIA_HERO	guias/aberturas-summa-hero	\N	0	t	{"title": "Serie Summa: más transparencia, confort y prestación", "eyebrow": "Guía premium", "overlay": true, "mediaAlt": "Serie Summa de aberturas de aluminio", "subtitle": "Una guía para proyectos que necesitan más dimensión, más hermeticidad y mejor integración visual.", "mediaType": "image", "primaryCta": {"href": "/productos/aberturas-summa.html", "label": "Ver serie Summa"}, "secondaryCta": {"href": "/guias/dvh", "label": "Ver guía DVH"}, "overlayOpacity": 0.6}	2026-05-03 16:26:40.745	2026-05-03 16:26:40.745
40	8	CONTENT_SPLIT	guias/aberturas-summa-intro	\N	1	t	{"title": "", "gallery": [{"href": "", "imageAlt": "Summa sistema", "imageUrl": "/uploads/cms/legacy-assets/img/aberturas/summa_sistema.png", "linkLabel": ""}, {"href": "", "imageAlt": "Terminaciones Summa", "imageUrl": "/uploads/cms/legacy-assets/img/aberturas/summa_terminaciones_2025.jpg", "linkLabel": ""}, {"href": "", "imageAlt": "Summa Alzante", "imageUrl": "/uploads/cms/legacy-assets/img/aberturas/summa_alzante_parrafo.jpg", "linkLabel": ""}], "variant": "media-gallery-content", "imageAlt": "Terminaciones Summa", "imageUrl": "/uploads/cms/legacy-assets/img/aberturas/summa_terminaciones_2025.jpg", "description": "", "mediaPosition": "start"}	2026-05-03 16:26:40.746	2026-05-03 16:26:40.746
41	8	FEATURE_GRID	guias/aberturas-summa-features	\N	2	t	{"title": "Lecturas útiles de la serie", "description": "Las variantes que ordenan la decisión en proyectos más exigentes.", "itemHeadingLevel": "h3"}	2026-05-03 16:26:40.747	2026-05-03 16:26:40.747
42	8	FAQ	guias/aberturas-summa-faq	\N	3	t	{"title": "Preguntas frecuentes", "description": "Respuestas cortas para elegir mejor en obras más exigentes."}	2026-05-03 16:26:40.75	2026-05-03 16:26:40.75
43	8	CTA_BANNER	guias/aberturas-summa-cta	\N	4	t	{"title": "Si el proyecto pide más prestación, seguimos por Summa", "intent": "transactional", "actions": [{"href": "/productos/aberturas-summa.html", "label": "Ver serie Summa"}, {"href": "/contacto.html", "label": "Consultar medidas"}, {"href": "/guias/dvh", "label": "Ver guía DVH"}], "description": "Te ayudamos a definir la variante correcta según medidas, confort y terminación."}	2026-05-03 16:26:40.752	2026-05-03 16:26:40.752
44	9	MEDIA_HERO	guias/como-medir-ancho-y-alto-hero	\N	0	t	{"title": "Cómo medir ancho y alto sin errores", "eyebrow": "Guía práctica", "overlay": true, "mediaAlt": "Cómo medir ancho y alto", "subtitle": "Una checklist simple para pedir presupuesto con más claridad.", "mediaType": "image", "primaryCta": {"href": "/contact", "label": "Solicitar visita"}, "secondaryCta": {"href": "/precios/cortinas-de-enrollar", "label": "Ver precios"}, "overlayOpacity": 0.6}	2026-05-03 16:26:40.753	2026-05-03 16:26:40.753
45	9	CONTENT_SPLIT	guias/como-medir-ancho-y-alto-intro	\N	1	t	{"title": "", "gallery": [{"href": "", "imageAlt": "Medición 1", "imageUrl": "/media/products/cortinas-de-enrollar-aluminio/images/IMG-20240826-WA0159.jpg", "linkLabel": ""}, {"href": "", "imageAlt": "Medición 2", "imageUrl": "/media/products/cortinas-de-enrollar-aluminio/images/catalana_1.jpeg", "linkLabel": ""}, {"href": "", "imageAlt": "Medición 3", "imageUrl": "/media/products/cortinas-de-enrollar-aluminio/images/IMG-20240826-WA0159.jpg", "linkLabel": ""}], "variant": "media-gallery-content", "imageAlt": "Toma de medidas", "imageUrl": "/media/products/cortinas-de-enrollar-aluminio/images/IMG-20240826-WA0159.jpg", "description": "", "mediaPosition": "start"}	2026-05-03 16:26:40.755	2026-05-03 16:26:40.755
49	10	MEDIA_HERO	guias/cortinas-roller-hero	\N	0	t	{"title": "Cortinas roller: cómo elegir Screen, Blackout o Roller doble", "eyebrow": "Guía de producto", "overlay": true, "mediaAlt": "Cortinas roller", "subtitle": "Una guía comercial para comparar luz, privacidad y uso antes de decidir.", "mediaType": "image", "primaryCta": {"href": "/productos/cortinas-roller.html", "label": "Ver cortinas roller"}, "secondaryCta": {"href": "/precios/cortinas-de-enrollar", "label": "Ver precios"}, "overlayOpacity": 0.6}	2026-05-03 16:26:40.762	2026-05-03 16:26:40.762
50	10	CONTENT_SPLIT	guias/cortinas-roller-intro	\N	1	t	{"title": "", "gallery": [{"href": "", "imageAlt": "Roller 1", "imageUrl": "/uploads/cms/legacy-assets/img/portfolio/roller/cortinas_roller_4.jpeg", "linkLabel": ""}, {"href": "", "imageAlt": "Roller 2", "imageUrl": "/uploads/cms/legacy-assets/img/portfolio/roller/cortinas_roller_2.jpeg", "linkLabel": ""}, {"href": "", "imageAlt": "Roller 3", "imageUrl": "/uploads/cms/legacy-assets/img/portfolio/roller/cortinas_roller_3.jpeg", "linkLabel": ""}], "variant": "media-gallery-content", "imageAlt": "Roller screen blackout y doble", "imageUrl": "/uploads/cms/legacy-assets/img/portfolio/roller/cortinas_roller_3.jpeg", "description": "", "mediaPosition": "start"}	2026-05-03 16:26:40.763	2026-05-03 16:26:40.763
51	10	FEATURE_GRID	guias/cortinas-roller-features	\N	2	t	{"title": "Las tres variantes más útiles", "description": "Una lectura rápida para comparar sin perder foco comercial.", "itemHeadingLevel": "h3"}	2026-05-03 16:26:40.764	2026-05-03 16:26:40.764
52	10	FAQ	guias/cortinas-roller-faq	\N	3	t	{"title": "Preguntas frecuentes", "description": "Respuestas simples para decidir más rápido."}	2026-05-03 16:26:40.767	2026-05-03 16:26:40.767
53	10	CTA_BANNER	guias/cortinas-roller-cta	\N	4	t	{"title": "Elegí la variante roller con más claridad", "intent": "transactional", "actions": [{"href": "/productos/cortinas-roller.html", "label": "Ver producto"}, {"href": "/contacto.html", "label": "Solicitar asesoramiento"}, {"href": "/precios/cortinas-de-enrollar", "label": "Ver precios"}], "description": "Si ya tenés medidas, te ayudamos a decidir entre screen, blackout o doble."}	2026-05-03 16:26:40.769	2026-05-03 16:26:40.769
54	11	MEDIA_HERO	guias/motores-cortinas-y-persianas-hero	\N	0	t	{"title": "Motores para cortinas y persianas: cómo elegir el control correcto", "eyebrow": "Guía de automatización", "overlay": true, "mediaAlt": "Motores para cortinas y persianas", "subtitle": "Una guía breve para definir qué tipo de automatización encaja mejor con tu rutina.", "mediaType": "image", "primaryCta": {"href": "/productos/motores-cortinas-y-persianas.html", "label": "Ver motores"}, "secondaryCta": {"href": "/contacto.html", "label": "Solicitar asesoramiento"}, "overlayOpacity": 0.6}	2026-05-03 16:26:40.77	2026-05-03 16:26:40.77
55	11	CONTENT_SPLIT	guias/motores-cortinas-y-persianas-intro	\N	1	t	{"title": "", "gallery": [{"href": "", "imageAlt": "Motor 1", "imageUrl": "/uploads/cms/legacy-assets/img/portfolio/motores/persianas_motorizadas.jpg", "linkLabel": ""}, {"href": "", "imageAlt": "Motor 2", "imageUrl": "/uploads/cms/legacy-assets/img/portfolio/motores/motor_cortina_1.jpg", "linkLabel": ""}, {"href": "", "imageAlt": "Motor 3", "imageUrl": "/uploads/cms/legacy-assets/img/portfolio/motores/motor_cortina_2.png", "linkLabel": ""}], "variant": "media-gallery-content", "imageAlt": "Persianas motorizadas", "imageUrl": "/uploads/cms/legacy-assets/img/portfolio/motores/persianas_motorizadas.jpg", "description": "", "mediaPosition": "start"}	2026-05-03 16:26:40.771	2026-05-03 16:26:40.771
56	11	FEATURE_GRID	guias/motores-cortinas-y-persianas-features	\N	2	t	{"title": "Formas de control", "description": "Elegí según comodidad y nivel de integración.", "itemHeadingLevel": "h3"}	2026-05-03 16:26:40.772	2026-05-03 16:26:40.772
57	11	FAQ	guias/motores-cortinas-y-persianas-faq	\N	3	t	{"title": "Preguntas frecuentes", "description": "Respuestas útiles para avanzar con menos vueltas."}	2026-05-03 16:26:40.775	2026-05-03 16:26:40.775
58	11	CTA_BANNER	guias/motores-cortinas-y-persianas-cta	\N	4	t	{"title": "Elegí la automatización que mejor encaja con tu rutina", "intent": "transactional", "actions": [{"href": "/productos/motores-cortinas-y-persianas.html", "label": "Ver motores"}, {"href": "/contacto.html", "label": "Solicitar asesoramiento"}, {"href": "/multimedia", "label": "Ver multimedia"}], "description": "Podemos ayudarte a definir si conviene remoto, botonera o app."}	2026-05-03 16:26:40.776	2026-05-03 16:26:40.776
59	12	MEDIA_HERO	guias/bandas-verticales-hero	\N	0	t	{"title": "Bandas verticales: materiales y aperturas según el espacio", "eyebrow": "Guía de producto", "overlay": true, "mediaAlt": "Bandas verticales", "subtitle": "Una guía breve para decidir si conviene blackout, screen o poliéster.", "mediaType": "image", "primaryCta": {"href": "/productos/bandas-verticales.html", "label": "Ver bandas verticales"}, "secondaryCta": {"href": "/multimedia/bandas-verticales", "label": "Ver fotos y videos"}, "overlayOpacity": 0.6}	2026-05-03 16:26:40.777	2026-05-03 16:26:40.777
60	12	CONTENT_SPLIT	guias/bandas-verticales-intro	\N	1	t	{"title": "", "gallery": [{"href": "", "imageAlt": "Bandas 1", "imageUrl": "/uploads/cms/legacy-assets/img/portfolio/bandas_verticales/bandas_verticales_3.jpeg", "linkLabel": ""}, {"href": "", "imageAlt": "Bandas 2", "imageUrl": "/uploads/cms/legacy-assets/img/portfolio/bandas_verticales/banda_vertical_1.jpeg", "linkLabel": ""}, {"href": "", "imageAlt": "Bandas 3", "imageUrl": "/uploads/cms/legacy-assets/img/portfolio/bandas_verticales/bandas_8.jpeg", "linkLabel": ""}], "variant": "media-gallery-content", "imageAlt": "Bandas verticales en uso", "imageUrl": "/uploads/cms/legacy-assets/img/portfolio/bandas_verticales/bandas_verticales_3.jpeg", "description": "", "mediaPosition": "start"}	2026-05-03 16:26:40.779	2026-05-03 16:26:40.779
61	12	FEATURE_GRID	guias/bandas-verticales-features	\N	2	t	{"title": "Los tres materiales más útiles", "description": "Una comparación simple para ordenar la decisión.", "itemHeadingLevel": "h3"}	2026-05-03 16:26:40.78	2026-05-03 16:26:40.78
62	12	FAQ	guias/bandas-verticales-faq	\N	3	t	{"title": "Preguntas frecuentes", "description": "Respuestas simples para cerrar la elección."}	2026-05-03 16:26:40.783	2026-05-03 16:26:40.783
63	12	CTA_BANNER	guias/bandas-verticales-cta	\N	4	t	{"title": "Elegí bandas verticales según el uso del espacio", "intent": "transactional", "actions": [{"href": "/productos/bandas-verticales.html", "label": "Ver bandas verticales"}, {"href": "/contacto.html", "label": "Solicitar asesoramiento"}, {"href": "/multimedia/bandas-verticales", "label": "Ver fotos y videos"}], "description": "Si tenés medidas aproximadas, te orientamos con más precisión."}	2026-05-03 16:26:40.784	2026-05-03 16:26:40.784
64	13	MEDIA_HERO	precios/cortinas-de-enrollar-hero	\N	0	t	{"title": "Cuánto influyen medidas, material y automatización en el precio", "eyebrow": "Guía comercial", "overlay": true, "mediaAlt": "Precios de cortinas de enrollar", "subtitle": "Una explicación corta para pedir presupuesto con expectativas más reales.", "mediaType": "image", "primaryCta": {"href": "/productos/cortinas-de-enrollar.html", "label": "Ver cortinas de enrollar"}, "secondaryCta": {"href": "/contacto.html", "label": "Solicitar presupuesto"}, "overlayOpacity": 0.6}	2026-05-03 16:26:40.785	2026-05-03 16:26:40.785
65	13	CONTENT_SPLIT	precios/cortinas-de-enrollar-intro	\N	1	t	{"title": "", "gallery": [{"href": "", "imageAlt": "Precio 1", "imageUrl": "/media/products/cortinas-de-enrollar-aluminio/images/catalana_1.jpeg", "linkLabel": ""}, {"href": "", "imageAlt": "Precio 2", "imageUrl": "/media/products/cortinas-de-enrollar-aluminio/images/IMG-20240826-WA0159.jpg", "linkLabel": ""}, {"href": "", "imageAlt": "Precio 3", "imageUrl": "/media/products/cortinas-de-enrollar-aluminio/images/catalana_1.jpeg", "linkLabel": ""}], "variant": "media-gallery-content", "imageAlt": "Precio de cortinas de enrollar", "imageUrl": "/media/products/cortinas-de-enrollar-aluminio/images/IMG-20240826-WA0159.jpg", "description": "", "mediaPosition": "start"}	2026-05-03 16:26:40.787	2026-05-03 16:26:40.787
66	13	FEATURE_GRID	precios/cortinas-de-enrollar-features	\N	2	t	{"title": "Tres factores que más pesan en el presupuesto", "description": "Una lectura comercial simple para reducir la fricción del primer contacto.", "itemHeadingLevel": "h3"}	2026-05-03 16:26:40.788	2026-05-03 16:26:40.788
67	13	FAQ	precios/cortinas-de-enrollar-faq	\N	3	t	{"title": "Preguntas frecuentes", "description": "Respuestas cortas para pedir una cotización mejor armada."}	2026-05-03 16:26:40.791	2026-05-03 16:26:40.791
68	13	CTA_BANNER	precios/cortinas-de-enrollar-cta	\N	4	t	{"title": "Pedí una cotización con medidas aproximadas", "intent": "transactional", "actions": [{"href": "/contacto.html", "label": "Solicitar presupuesto"}, {"href": "/guias/cortinas-pvc-vs-aluminio", "label": "Ver opciones"}, {"href": "/contact", "label": "Solicitar visita"}], "description": "Si ya tenés una referencia del frente, te ayudamos a bajar el presupuesto con más precisión."}	2026-05-03 16:26:40.792	2026-05-03 16:26:40.792
69	14	MEDIA_HERO	servicios/reparacion-cortinas-y-persianas.html-hero	\N	0	t	{"title": "Reparación de cortinas y persianas", "eyebrow": "Servicio", "overlay": true, "mediaAlt": "Reparación de cortinas y persianas", "subtitle": "Si todavía tiene arreglo, te orientamos sobre la reparación más conveniente.", "mediaType": "image", "primaryCta": {"href": "/contact", "label": "Solicitar reparación"}, "secondaryCta": {"href": "/multimedia", "label": "Ver fotos y videos"}, "overlayOpacity": 0.6}	2026-05-03 16:26:40.793	2026-05-03 16:26:40.793
70	14	CONTENT_SPLIT	servicios/reparacion-cortinas-y-persianas.html-intro	\N	1	t	{"title": "", "gallery": [{"href": "", "imageAlt": "Reparación 1", "imageUrl": "/media/products/cortinas-roller/images/20211218_193930.jpg", "linkLabel": ""}, {"href": "", "imageAlt": "Reparación 2", "imageUrl": "/media/products/cortinas-metalicas/images/WhatsApp Image 2025-11-06 at 14.18.59.jpeg", "linkLabel": ""}, {"href": "", "imageAlt": "Reparación 3", "imageUrl": "/media/products/cortinas-de-enrollar-aluminio/images/catalana_1.jpeg", "linkLabel": ""}], "variant": "media-gallery-content", "imageAlt": "Reparación de cortinas", "imageUrl": "/media/products/cortinas-roller/images/20211218_193930.jpg", "description": "", "mediaPosition": "start"}	2026-05-03 16:26:40.795	2026-05-03 16:26:40.795
71	14	FEATURE_GRID	servicios/reparacion-cortinas-y-persianas.html-features	\N	2	t	{"title": "Qué resolvemos con más frecuencia", "description": "Una lectura simple para saber si vale la pena reparar o reemplazar.", "itemHeadingLevel": "h3"}	2026-05-03 16:26:40.796	2026-05-03 16:26:40.796
72	14	FAQ	servicios/reparacion-cortinas-y-persianas.html-faq	\N	3	t	{"title": "Preguntas frecuentes", "description": "Respuestas útiles para pedir ayuda sin vueltas."}	2026-05-03 16:26:40.798	2026-05-03 16:26:40.798
73	14	CTA_BANNER	servicios/reparacion-cortinas-y-persianas.html-cta	\N	4	t	{"title": "Coordiná una revisión y te decimos si vale la pena reparar", "intent": "transactional", "actions": [{"href": "/contact", "label": "Solicitar reparación"}, {"href": "/servicios/reparacion-cortinas-y-persianas.html", "label": "Ver servicio"}, {"href": "/multimedia", "label": "Ver multimedia"}], "description": "Si todavía puede recuperarse, te lo vamos a decir claro."}	2026-05-03 16:26:40.8	2026-05-03 16:26:40.8
74	15	STORIES_CAROUSEL	story-items	Cortinas metálicas	0	t	{"autoplay": true, "interval": 5000, "showProgressBar": true}	2026-05-03 16:26:40.801	2026-05-03 16:26:40.801
75	16	STORIES_CAROUSEL	story-items	Cortinas Venecianas	0	t	{"autoplay": true, "interval": 5000, "showProgressBar": true}	2026-05-03 16:26:40.803	2026-05-03 16:26:40.803
76	17	STORIES_CAROUSEL	story-items	Bandas verticales	0	t	{"autoplay": true, "interval": 5000, "showProgressBar": true}	2026-05-03 16:26:40.805	2026-05-03 16:26:40.805
77	18	STORIES_CAROUSEL	story-items	Cortinas Roller	0	t	{"autoplay": true, "interval": 5000, "showProgressBar": true}	2026-05-03 16:26:40.807	2026-05-03 16:26:40.807
78	19	STORIES_CAROUSEL	story-items	Motores y automatismos	0	t	{"autoplay": true, "interval": 5000, "showProgressBar": true}	2026-05-03 16:26:40.809	2026-05-03 16:26:40.809
79	20	STORIES_CAROUSEL	story-items	Toldos y cerramientos	0	t	{"autoplay": true, "interval": 5000, "showProgressBar": true}	2026-05-03 16:26:40.811	2026-05-03 16:26:40.811
80	21	STORIES_CAROUSEL	story-items	Aberturas en aluminio	0	t	{"autoplay": true, "interval": 5000, "showProgressBar": true}	2026-05-03 16:26:40.813	2026-05-03 16:26:40.813
81	22	STORIES_CAROUSEL	story-items	Cortinas de enrollar	0	t	{"autoplay": true, "interval": 5000, "showProgressBar": true}	2026-05-03 16:26:40.815	2026-05-03 16:26:40.815
82	23	MEDIA_HERO	qa-var-003-hero	\N	0	t	{"title": "Producto Variable QA API 2 en contexto", "eyebrow": "New release", "overlay": true, "mediaAlt": "Producto Variable QA API 2 hero", "subtitle": "Diseño limpio, media dominante y conversiones más claras.", "mediaType": "image", "primaryCta": {"href": "/categories", "label": "Ver categoría"}, "secondaryCta": {"href": "/categories", "label": "Ver categorías"}, "overlayOpacity": 0.56}	2026-05-03 16:26:40.816	2026-05-03 16:26:40.816
83	23	HIGHLIGHT_CARDS	qa-var-003-benefits	\N	1	t	{"title": "Beneficios de Producto Variable QA API 2", "description": "Un bloque directo para reducir dudas y reforzar el valor percibido."}	2026-05-03 16:26:40.817	2026-05-03 16:26:40.817
84	23	VIDEO_SECTION	qa-var-003-video	\N	2	t	{"title": "Video de producto", "layout": "contained", "autoplay": false, "controls": true, "description": "Un bloque para demostración o prueba de uso."}	2026-05-03 16:26:40.82	2026-05-03 16:26:40.82
85	23	MEDIA_GRID_ENHANCED	qa-var-003-grid	\N	3	t	{"gap": 1.05, "title": "Galería visual", "columns": 3, "aspectRatio": "4 / 5", "description": "Una secuencia de imágenes para sostener el interés y el scroll."}	2026-05-03 16:26:40.822	2026-05-03 16:26:40.822
86	23	CTA_BANNER	qa-var-003-cta	\N	4	t	{"href": "/categories", "label": "Explorar catálogo", "title": "Listo para decidir", "intent": "conversion", "description": "La última CTA cierra la narrativa con una acción concreta."}	2026-05-03 16:26:40.825	2026-05-03 16:26:40.825
87	24	MEDIA_HERO	ventana-corrediza-20-blanco-3mm-1200x2000-hero	\N	0	t	{"title": "Ventana Corrediza 20 Blanco 3mm 1200x2000 en contexto", "eyebrow": "Performance", "overlay": true, "mediaAlt": "Ventana Corrediza 20 Blanco 3mm 1200x2000 hero", "subtitle": "Más contexto visual para una decisión de compra más rápida.", "mediaType": "image", "primaryCta": {"href": "/categories", "label": "Ver categoría"}, "secondaryCta": {"href": "/categories", "label": "Ver categorías"}, "overlayOpacity": 0.56}	2026-05-03 16:26:40.826	2026-05-03 16:26:40.826
88	24	HIGHLIGHT_CARDS	ventana-corrediza-20-blanco-3mm-1200x2000-benefits	\N	1	t	{"title": "Beneficios de Ventana Corrediza 20 Blanco 3mm 1200x2000", "description": "Un bloque directo para reducir dudas y reforzar el valor percibido."}	2026-05-03 16:26:40.828	2026-05-03 16:26:40.828
89	24	VIDEO_SECTION	ventana-corrediza-20-blanco-3mm-1200x2000-video	\N	2	t	{"title": "Video de producto", "layout": "contained", "autoplay": false, "controls": true, "description": "Un bloque para demostración o prueba de uso."}	2026-05-03 16:26:40.831	2026-05-03 16:26:40.831
90	24	MEDIA_GRID_ENHANCED	ventana-corrediza-20-blanco-3mm-1200x2000-grid	\N	3	t	{"gap": 1.05, "title": "Galería visual", "columns": 3, "aspectRatio": "4 / 5", "description": "Una secuencia de imágenes para sostener el interés y el scroll."}	2026-05-03 16:26:40.832	2026-05-03 16:26:40.832
91	24	CTA_BANNER	ventana-corrediza-20-blanco-3mm-1200x2000-cta	\N	4	t	{"href": "/categories", "label": "Explorar catálogo", "title": "Listo para decidir", "intent": "conversion", "description": "La última CTA cierra la narrativa con una acción concreta."}	2026-05-03 16:26:40.835	2026-05-03 16:26:40.835
92	25	MEDIA_HERO	ventana-corrediza-20-blanco-3mm-1400x600-hero	\N	0	t	{"title": "Ventana Corrediza 20 Blanco 3mm 1400x600 en contexto", "eyebrow": "Premium", "overlay": true, "mediaAlt": "Ventana Corrediza 20 Blanco 3mm 1400x600 hero", "subtitle": "Escala, brillo y percepción de valor en una sola secuencia.", "mediaType": "image", "primaryCta": {"href": "/categories", "label": "Ver categoría"}, "secondaryCta": {"href": "/categories", "label": "Ver categorías"}, "overlayOpacity": 0.56}	2026-05-03 16:26:40.837	2026-05-03 16:26:40.837
93	25	HIGHLIGHT_CARDS	ventana-corrediza-20-blanco-3mm-1400x600-benefits	\N	1	t	{"title": "Beneficios de Ventana Corrediza 20 Blanco 3mm 1400x600", "description": "Un bloque directo para reducir dudas y reforzar el valor percibido."}	2026-05-03 16:26:40.838	2026-05-03 16:26:40.838
94	25	VIDEO_SECTION	ventana-corrediza-20-blanco-3mm-1400x600-video	\N	2	t	{"title": "Video de producto", "layout": "contained", "autoplay": false, "controls": true, "description": "Un bloque para demostración o prueba de uso."}	2026-05-03 16:26:40.841	2026-05-03 16:26:40.841
95	25	MEDIA_GRID_ENHANCED	ventana-corrediza-20-blanco-3mm-1400x600-grid	\N	3	t	{"gap": 1.05, "title": "Galería visual", "columns": 3, "aspectRatio": "4 / 5", "description": "Una secuencia de imágenes para sostener el interés y el scroll."}	2026-05-03 16:26:40.843	2026-05-03 16:26:40.843
96	25	CTA_BANNER	ventana-corrediza-20-blanco-3mm-1400x600-cta	\N	4	t	{"href": "/categories", "label": "Explorar catálogo", "title": "Listo para decidir", "intent": "conversion", "description": "La última CTA cierra la narrativa con una acción concreta."}	2026-05-03 16:26:40.846	2026-05-03 16:26:40.846
97	26	MEDIA_HERO	ventana-corrediza-20-blanco-3mm-1500x1500-hero	\N	0	t	{"title": "Ventana Corrediza 20 Blanco 3mm 1500x1500 en contexto", "eyebrow": "Style", "overlay": true, "mediaAlt": "Ventana Corrediza 20 Blanco 3mm 1500x1500 hero", "subtitle": "La secuencia visual hace de puente entre inspiración y compra.", "mediaType": "image", "primaryCta": {"href": "/categories", "label": "Ver categoría"}, "secondaryCta": {"href": "/categories", "label": "Ver categorías"}, "overlayOpacity": 0.56}	2026-05-03 16:26:40.848	2026-05-03 16:26:40.848
98	26	HIGHLIGHT_CARDS	ventana-corrediza-20-blanco-3mm-1500x1500-benefits	\N	1	t	{"title": "Beneficios de Ventana Corrediza 20 Blanco 3mm 1500x1500", "description": "Un bloque directo para reducir dudas y reforzar el valor percibido."}	2026-05-03 16:26:40.849	2026-05-03 16:26:40.849
99	26	VIDEO_SECTION	ventana-corrediza-20-blanco-3mm-1500x1500-video	\N	2	t	{"title": "Video de producto", "layout": "contained", "autoplay": false, "controls": true, "description": "Un bloque para demostración o prueba de uso."}	2026-05-03 16:26:40.853	2026-05-03 16:26:40.853
100	26	MEDIA_GRID_ENHANCED	ventana-corrediza-20-blanco-3mm-1500x1500-grid	\N	3	t	{"gap": 1.05, "title": "Galería visual", "columns": 3, "aspectRatio": "4 / 5", "description": "Una secuencia de imágenes para sostener el interés y el scroll."}	2026-05-03 16:26:40.855	2026-05-03 16:26:40.855
101	26	CTA_BANNER	ventana-corrediza-20-blanco-3mm-1500x1500-cta	\N	4	t	{"href": "/categories", "label": "Explorar catálogo", "title": "Listo para decidir", "intent": "conversion", "description": "La última CTA cierra la narrativa con una acción concreta."}	2026-05-03 16:26:40.858	2026-05-03 16:26:40.858
102	27	MEDIA_HERO	ventana-corrediza-20-blanco-3mm-1500x2000-hero	\N	0	t	{"title": "Ventana Corrediza 20 Blanco 3mm 1500x2000 en contexto", "eyebrow": "Daily use", "overlay": true, "mediaAlt": "Ventana Corrediza 20 Blanco 3mm 1500x2000 hero", "subtitle": "Una narrativa más ligera para productos que se venden por contexto.", "mediaType": "image", "primaryCta": {"href": "/categories", "label": "Ver categoría"}, "secondaryCta": {"href": "/categories", "label": "Ver categorías"}, "overlayOpacity": 0.56}	2026-05-03 16:26:40.859	2026-05-03 16:26:40.859
103	27	HIGHLIGHT_CARDS	ventana-corrediza-20-blanco-3mm-1500x2000-benefits	\N	1	t	{"title": "Beneficios de Ventana Corrediza 20 Blanco 3mm 1500x2000", "description": "Un bloque directo para reducir dudas y reforzar el valor percibido."}	2026-05-03 16:26:40.861	2026-05-03 16:26:40.861
104	27	VIDEO_SECTION	ventana-corrediza-20-blanco-3mm-1500x2000-video	\N	2	t	{"title": "Video de producto", "layout": "contained", "autoplay": false, "controls": true, "description": "Un bloque para demostración o prueba de uso."}	2026-05-03 16:26:40.864	2026-05-03 16:26:40.864
105	27	MEDIA_GRID_ENHANCED	ventana-corrediza-20-blanco-3mm-1500x2000-grid	\N	3	t	{"gap": 1.05, "title": "Galería visual", "columns": 3, "aspectRatio": "4 / 5", "description": "Una secuencia de imágenes para sostener el interés y el scroll."}	2026-05-03 16:26:40.866	2026-05-03 16:26:40.866
106	27	CTA_BANNER	ventana-corrediza-20-blanco-3mm-1500x2000-cta	\N	4	t	{"href": "/categories", "label": "Explorar catálogo", "title": "Listo para decidir", "intent": "conversion", "description": "La última CTA cierra la narrativa con una acción concreta."}	2026-05-03 16:26:40.869	2026-05-03 16:26:40.869
\.


--
-- Data for Name: CmsSection; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CmsSection" (id, key, name, description, "isActive", "sortOrder", "createdAt", "updatedAt") FROM stdin;
1	HOME_STORIES	Home Stories	Stories destacadas del home storefront.	t	0	2026-05-03 16:26:40.623	2026-05-03 16:26:41.07
2	HOME_HIGHLIGHTS	Atención comercial	Visitas, pagos y garantía destacados del home storefront.	t	10	2026-05-03 16:26:40.623	2026-05-03 16:26:41.071
\.


--
-- Data for Name: CompanyProfile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CompanyProfile" (id, singleton, "legalName", "tradeName", "taxId", email, phone, website, "addressLine1", "addressLine2", "seoDescription", "seoAuthor", "seoImageUrl", "googleSiteVerification", logo, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Conversation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Conversation" (id, "tenantKey", scope, "conversationRole", channel, status, "controlMode", "needsHuman", subject, "customerId", "assignedToUserId", "inboxAccountId", "externalUserId", "externalThreadId", "externalChannelRef", metadata, "pinnedAt", "lastMessageAt", "lastInboundAt", "lastOutboundAt", "closedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ConversationExternalIdentity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ConversationExternalIdentity" (id, "conversationId", "tenantKey", channel, kind, value, "normalizedValue", metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ConversationHandoffEvent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ConversationHandoffEvent" (id, "conversationId", type, "actorUserId", "previousMode", "nextMode", notes, metadata, "createdAt") FROM stdin;
\.


--
-- Data for Name: ConversationMessage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ConversationMessage" (id, "conversationId", "authorType", kind, "authorUserId", "authorCustomerId", "externalMessageId", "inboxMessageId", body, "normalizedText", payload, metadata, "sentAt", "receivedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: ConversationParticipant; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ConversationParticipant" (id, "conversationId", role, "userId", "customerId", "externalUserId", "displayName", metadata, "createdAt") FROM stdin;
\.


--
-- Data for Name: ConversationReadState; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ConversationReadState" ("conversationId", "userId", "lastReadAt", "manualUnread", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ConversationToolCall; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ConversationToolCall" (id, "conversationId", "messageId", "toolName", status, "requestedBy", "requestedByUserId", "validatedPayload", "resultPayload", "errorCode", "errorMessage", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CurrencyRate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CurrencyRate" (id, base, quote, rate, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Customer" (id, name, "firstName", "lastName", email, "emailVerifiedAt", img, location, title, "phoneNumber", "passwordHash", "storefrontDefaultPasswordHash", "passwordAlgorithm", "passwordAlgVersion", "passwordUpdatedAt", "storefrontSessionVersion", birthday, facebook, twitter, pinterest, "linkedIn", "preferredLocale", "preferredCurrency", "createdAt", "updatedAt", "statusId") FROM stdin;
\.


--
-- Data for Name: CustomerAddress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CustomerAddress" (id, "customerId", street, number, corner, apartment, department, city, neighborhood, country, comments, label, "isPrimary", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CustomerEmailVerificationToken; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CustomerEmailVerificationToken" (id, "customerId", "tokenHash", "emailSnapshot", "expiresAt", "usedAt", "ipAddress", "userAgent", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CustomerOAuthAccount; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CustomerOAuthAccount" (id, "customerId", provider, "providerAccountId", email, name, "givenName", "familyName", picture, metadata, "createdAt", "updatedAt", "lastLoginAt") FROM stdin;
\.


--
-- Data for Name: CustomerOtpChallenge; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CustomerOtpChallenge" (id, "customerId", phone, "otpHash", "otpLength", "attemptCount", "maxAttempts", channel, "ipAddress", "userAgent", "expiresAt", "lastAttemptAt", "consumedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CustomerPhone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CustomerPhone" (id, "customerId", phone, label, "isPrimary", "createdAt") FROM stdin;
\.


--
-- Data for Name: CustomerReauthToken; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CustomerReauthToken" (id, "customerId", "tokenHash", method, factors, "ipAddress", "userAgent", "expiresAt", "usedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: CustomerSecurityEvent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CustomerSecurityEvent" (id, "customerId", "eventType", channel, "ipAddress", "userAgent", "deviceId", metadata, "createdAt") FROM stdin;
\.


--
-- Data for Name: CustomerStatus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CustomerStatus" (id, name, color) FROM stdin;
1	Activo	#10B981
2	Suspendido	#F59E0B
3	Bloqueado	#EF4444
\.


--
-- Data for Name: EmailLog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EmailLog" (id, category, "templateId", locale, "recipientType", "toAddress", "ccAddresses", "bccAddresses", subject, payload, "payloadHash", status, "providerMessageId", "errorMessage", attempts, "lastAttemptAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: EmailSetting; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EmailSetting" (id, category, "fromAddress", "fromName", "adminRecipients", cc, bcc, enabled, "createdAt", "updatedAt") FROM stdin;
1	ORDERS	no-reply@example.com	Sistema Administrativo	{}	{}	{}	t	2026-05-03 16:26:41.067	2026-05-03 16:26:41.067
2	PAYMENTS	no-reply@example.com	Sistema Administrativo	{}	{}	{}	t	2026-05-03 16:26:41.068	2026-05-03 16:26:41.068
3	AUTH	no-reply@example.com	Sistema Administrativo	{}	{}	{}	t	2026-05-03 16:26:41.068	2026-05-03 16:26:41.068
\.


--
-- Data for Name: EmailTemplate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EmailTemplate" (id, category, locale, variant, subject, body, version, active, "createdAt", "updatedAt") FROM stdin;
1	ORDERS	en	CUSTOMER	{{eventLabel payload.event}} {{#if payload.orderNumber}}#{{payload.orderNumber}}{{/if}}	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html dir="ltr" lang="en"><head><link rel="preload" as="image" href="{{companyLogo}}"/><meta content="text/html; charset=UTF-8" http-equiv="Content-Type"/><meta name="x-apple-disable-message-reformatting"/></head><body style="background-color:#F3F4F6;margin:0;padding:0"><table border="0" width="100%" cellPadding="0" cellSpacing="0" role="presentation" align="center"><tbody><tr><td style="background-color:#F3F4F6;margin:0;padding:24px 0"><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="max-width:640px;margin:0 auto"><tbody><tr style="width:100%"><td><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background:linear-gradient(135deg, #103B34 0%, #1F6F5F 58%, #D9A441 100%);padding:24px 28px;border-radius:24px 24px 0 0"><tbody><tr><td><img alt="{{companyName}}" src="{{companyLogo}}" style="display:block;outline:none;border:none;text-decoration:none;margin:0 auto 14px;max-width:144px;height:auto" width="144"/><p style="font-size:22px;line-height:24px;color:#ffffff;font-weight:700;text-align:center;margin:0;letter-spacing:0.02em;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyName}}</p></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#ffffff;padding:28px;border-left:1px solid #E5E7EB;border-right:1px solid #E5E7EB"><tbody><tr><td><div>\n<h1 style="margin:0 0 12px;color:#111827;font-size:22px;line-height:1.35;font-weight:700;">{{#if payload.customer.name}}{{payload.customer.name}}, {{/if}}{{eventLabel payload.event}}!{{#if payload.orderNumber}} <span style='display:inline-block;margin-left:8px;padding:4px 10px;border-radius:999px;background:#EEF2FF;color:#4338CA;font-size:12px;font-weight:700;'>#{{payload.orderNumber}}</span>{{/if}}</h1>\n<p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;">{{eventMessage payload}}</p>\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;"><tbody>\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Order number</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{default payload.orderNumber payload.orderId}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Order date</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.orderDate}}</td>\n  </tr>\n\n  {{#if payload.status}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Current status</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.status}}</td>\n  </tr>\n\n  {{/if}}\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Total</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.grandTotalRaw payload.totals.currency}}</td>\n  </tr>\n\n  {{#if payload.paymentMethod}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Payment method</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.paymentMethod}}</td>\n  </tr>\n\n  {{/if}}\n  {{#if payload.validUntil}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Valid until</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.validUntil}}</td>\n  </tr>\n\n  {{/if}}\n</tbody></table>\n<hr style="margin:24px 0;border:none;border-top:1px solid #E5E7EB;" />\n<h2 style="margin:0 0 12px;color:#111827;font-size:16px;line-height:1.4;font-weight:700;">Order summary</h2>\n\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;">\n  <thead>\n    <tr>\n      <th align="left" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Item</th>\n      <th align="center" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Qty</th>\n      <th align="right" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Amount</th>\n    </tr>\n  </thead>\n  <tbody>\n    {{#each payload.items}}\n      <tr>\n        <td style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">\n          <div>{{this.name}}</div>\n          {{#if this.description}}\n            <div style="margin-top:4px;color:#6B7280;font-size:12px;line-height:1.5;">{{this.description}}</div>\n          {{/if}}\n        </td>\n        <td align="center" style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">{{this.quantity}}</td>\n        <td align="right" style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">{{formatCurrency this.subtotalRaw ../payload.totals.currency}}</td>\n      </tr>\n    {{/each}}\n  </tbody>\n</table>\n\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;"><tbody>\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Subtotal</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.subtotalRaw payload.totals.currency}}</td>\n  </tr>\n\n    {{#if payload.totals.taxRaw}}\n      \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Tax</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.taxRaw payload.totals.currency}}</td>\n  </tr>\n\n    {{/if}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Total</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;"><strong>{{formatCurrency payload.totals.grandTotalRaw payload.totals.currency}}</strong></td>\n  </tr>\n\n  </tbody></table>\n{{#if (or payload.deliveryEstimateLabel payload.shippingVendor payload.shippingAddress payload.billingAddress)}}\n  <hr style="margin:24px 0;border:none;border-top:1px solid #E5E7EB;" />\n  <h2 style="margin:0 0 12px;color:#111827;font-size:16px;line-height:1.4;font-weight:700;">Delivery information</h2>\n  <table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;"><tbody>\n    {{#if payload.shippingVendor}}\n      \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Carrier</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.shippingVendor}}</td>\n  </tr>\n\n    {{/if}}\n    {{#if payload.deliveryEstimateLabel}}\n      \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Estimated delivery</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.deliveryEstimateLabel}}</td>\n  </tr>\n\n    {{/if}}\n  </tbody></table>\n  {{#if payload.shippingAddress}}\n    <p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;"><strong>Shipping address</strong><br/>{{#each payload.shippingAddress.lines}}{{this}}<br/>{{/each}}</p>\n  {{/if}}\n  {{#if payload.billingAddress}}\n    <p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;"><strong>Billing address</strong><br/>{{#each payload.billingAddress.lines}}{{this}}<br/>{{/each}}</p>\n  {{/if}}\n{{/if}}\n{{#if payload.notes}}\n  <hr style="margin:24px 0;border:none;border-top:1px solid #E5E7EB;" />\n  <p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;"><strong>Notes:</strong> {{payload.notes}}</p>\n{{/if}}\n<hr style="margin:24px 0;border:none;border-top:1px solid #E5E7EB;" />\n\n{{#if (or payload.links.customer payload.portalUrl)}}\n  {{#if (eq payload.documentType 'BUDGET')}}\n    {{#if (eq payload.event 'budget.created')}}\n      \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{default (default payload.links.customer payload.portalUrl) '#'}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Review quote</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n    {{else}}\n      {{#if (eq payload.event 'budget.status.accepted')}}\n        \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{default (default payload.links.customer payload.portalUrl) '#'}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">View confirmation</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n      {{else}}\n        \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{default (default payload.links.customer payload.portalUrl) '#'}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Open quote</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n      {{/if}}\n    {{/if}}\n  {{else}}\n    {{#if (eq payload.event 'order.received')}}\n      \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{default (default payload.links.customer payload.portalUrl) '#'}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">View order</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n    {{else}}\n      {{#if (eq payload.event 'order.status.delivered')}}\n        \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{default (default payload.links.customer payload.portalUrl) '#'}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Share feedback</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n      {{else}}\n        \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{default (default payload.links.customer payload.portalUrl) '#'}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Track order</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n      {{/if}}\n    {{/if}}\n  {{/if}}\n{{/if}}\n\n<p style="margin:0;color:#6B7280;font-size:12px;line-height:1.6;">Need help? Reply to this email or contact us at {{companyFooter}}.</p>\n</div></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#F9FAFB;padding:18px 22px;border-radius:0 0 24px 24px;border:1px solid #E5E7EB;border-top:0"><tbody><tr><td><p style="font-size:12px;line-height:1.5;color:#6B7280;margin:0;text-align:center;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyFooter}}</p></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></body></html>	7	t	2026-05-03 16:26:42.037	2026-05-03 16:26:42.037
2	ORDERS	es	CUSTOMER	{{eventLabel payload.event}} {{#if payload.orderNumber}}#{{payload.orderNumber}}{{/if}}	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html dir="ltr" lang="en"><head><link rel="preload" as="image" href="{{companyLogo}}"/><meta content="text/html; charset=UTF-8" http-equiv="Content-Type"/><meta name="x-apple-disable-message-reformatting"/></head><body style="background-color:#F3F4F6;margin:0;padding:0"><table border="0" width="100%" cellPadding="0" cellSpacing="0" role="presentation" align="center"><tbody><tr><td style="background-color:#F3F4F6;margin:0;padding:24px 0"><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="max-width:640px;margin:0 auto"><tbody><tr style="width:100%"><td><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background:linear-gradient(135deg, #103B34 0%, #1F6F5F 58%, #D9A441 100%);padding:24px 28px;border-radius:24px 24px 0 0"><tbody><tr><td><img alt="{{companyName}}" src="{{companyLogo}}" style="display:block;outline:none;border:none;text-decoration:none;margin:0 auto 14px;max-width:144px;height:auto" width="144"/><p style="font-size:22px;line-height:24px;color:#ffffff;font-weight:700;text-align:center;margin:0;letter-spacing:0.02em;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyName}}</p></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#ffffff;padding:28px;border-left:1px solid #E5E7EB;border-right:1px solid #E5E7EB"><tbody><tr><td><div>\n<h1 style="margin:0 0 12px;color:#111827;font-size:22px;line-height:1.35;font-weight:700;">{{#if payload.customer.name}}{{payload.customer.name}}, {{/if}}{{eventLabel payload.event}}!{{#if payload.orderNumber}} <span style='display:inline-block;margin-left:8px;padding:4px 10px;border-radius:999px;background:#EEF2FF;color:#4338CA;font-size:12px;font-weight:700;'>#{{payload.orderNumber}}</span>{{/if}}</h1>\n<p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;">{{eventMessage payload}}</p>\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;"><tbody>\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Número de pedido</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{default payload.orderNumber payload.orderId}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Fecha del pedido</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.orderDate}}</td>\n  </tr>\n\n  {{#if payload.status}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Estado actual</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.status}}</td>\n  </tr>\n\n  {{/if}}\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Total</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.grandTotalRaw payload.totals.currency}}</td>\n  </tr>\n\n  {{#if payload.paymentMethod}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Método de pago</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.paymentMethod}}</td>\n  </tr>\n\n  {{/if}}\n  {{#if payload.validUntil}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Válido hasta</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.validUntil}}</td>\n  </tr>\n\n  {{/if}}\n</tbody></table>\n<hr style="margin:24px 0;border:none;border-top:1px solid #E5E7EB;" />\n<h2 style="margin:0 0 12px;color:#111827;font-size:16px;line-height:1.4;font-weight:700;">Resumen del pedido</h2>\n\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;">\n  <thead>\n    <tr>\n      <th align="left" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Producto</th>\n      <th align="center" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Cant.</th>\n      <th align="right" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Importe</th>\n    </tr>\n  </thead>\n  <tbody>\n    {{#each payload.items}}\n      <tr>\n        <td style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">\n          <div>{{this.name}}</div>\n          {{#if this.description}}\n            <div style="margin-top:4px;color:#6B7280;font-size:12px;line-height:1.5;">{{this.description}}</div>\n          {{/if}}\n        </td>\n        <td align="center" style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">{{this.quantity}}</td>\n        <td align="right" style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">{{formatCurrency this.subtotalRaw ../payload.totals.currency}}</td>\n      </tr>\n    {{/each}}\n  </tbody>\n</table>\n\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;"><tbody>\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Subtotal</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.subtotalRaw payload.totals.currency}}</td>\n  </tr>\n\n    {{#if payload.totals.taxRaw}}\n      \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Impuestos</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.taxRaw payload.totals.currency}}</td>\n  </tr>\n\n    {{/if}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Total</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;"><strong>{{formatCurrency payload.totals.grandTotalRaw payload.totals.currency}}</strong></td>\n  </tr>\n\n  </tbody></table>\n{{#if (or payload.deliveryEstimateLabel payload.shippingVendor payload.shippingAddress payload.billingAddress)}}\n  <hr style="margin:24px 0;border:none;border-top:1px solid #E5E7EB;" />\n  <h2 style="margin:0 0 12px;color:#111827;font-size:16px;line-height:1.4;font-weight:700;">Información de entrega</h2>\n  <table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;"><tbody>\n    {{#if payload.shippingVendor}}\n      \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Transportista</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.shippingVendor}}</td>\n  </tr>\n\n    {{/if}}\n    {{#if payload.deliveryEstimateLabel}}\n      \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Tiempo estimado</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.deliveryEstimateLabel}}</td>\n  </tr>\n\n    {{/if}}\n  </tbody></table>\n  {{#if payload.shippingAddress}}\n    <p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;"><strong>Dirección de envío</strong><br/>{{#each payload.shippingAddress.lines}}{{this}}<br/>{{/each}}</p>\n  {{/if}}\n  {{#if payload.billingAddress}}\n    <p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;"><strong>Dirección de facturación</strong><br/>{{#each payload.billingAddress.lines}}{{this}}<br/>{{/each}}</p>\n  {{/if}}\n{{/if}}\n{{#if payload.notes}}\n  <hr style="margin:24px 0;border:none;border-top:1px solid #E5E7EB;" />\n  <p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;"><strong>Notas:</strong> {{payload.notes}}</p>\n{{/if}}\n<hr style="margin:24px 0;border:none;border-top:1px solid #E5E7EB;" />\n\n{{#if (or payload.links.customer payload.portalUrl)}}\n  {{#if (eq payload.documentType 'BUDGET')}}\n    {{#if (eq payload.event 'budget.created')}}\n      \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{default (default payload.links.customer payload.portalUrl) '#'}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Ver presupuesto</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n    {{else}}\n      {{#if (eq payload.event 'budget.status.accepted')}}\n        \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{default (default payload.links.customer payload.portalUrl) '#'}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Ver confirmación</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n      {{else}}\n        \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{default (default payload.links.customer payload.portalUrl) '#'}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Abrir presupuesto</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n      {{/if}}\n    {{/if}}\n  {{else}}\n    {{#if (eq payload.event 'order.received')}}\n      \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{default (default payload.links.customer payload.portalUrl) '#'}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Ver pedido</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n    {{else}}\n      {{#if (eq payload.event 'order.status.delivered')}}\n        \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{default (default payload.links.customer payload.portalUrl) '#'}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Compartir comentario</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n      {{else}}\n        \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{default (default payload.links.customer payload.portalUrl) '#'}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Seguir pedido</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n      {{/if}}\n    {{/if}}\n  {{/if}}\n{{/if}}\n\n<p style="margin:0;color:#6B7280;font-size:12px;line-height:1.6;">¿Necesitás ayuda? Respondé este correo o escribinos a {{companyFooter}}.</p>\n</div></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#F9FAFB;padding:18px 22px;border-radius:0 0 24px 24px;border:1px solid #E5E7EB;border-top:0"><tbody><tr><td><p style="font-size:12px;line-height:1.5;color:#6B7280;margin:0;text-align:center;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyFooter}}</p></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></body></html>	7	t	2026-05-03 16:26:42.04	2026-05-03 16:26:42.04
3	ORDERS	en	ADMIN	[{{companyName}} - Admin] New order received {{#if payload.orderNumber}}#{{payload.orderNumber}}{{/if}}	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html dir="ltr" lang="en"><head><link rel="preload" as="image" href="{{companyLogo}}"/><meta content="text/html; charset=UTF-8" http-equiv="Content-Type"/><meta name="x-apple-disable-message-reformatting"/></head><body style="background-color:#F3F4F6;margin:0;padding:0"><table border="0" width="100%" cellPadding="0" cellSpacing="0" role="presentation" align="center"><tbody><tr><td style="background-color:#F3F4F6;margin:0;padding:24px 0"><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="max-width:640px;margin:0 auto"><tbody><tr style="width:100%"><td><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background:linear-gradient(135deg, #103B34 0%, #1F6F5F 58%, #D9A441 100%);padding:24px 28px;border-radius:24px 24px 0 0"><tbody><tr><td><img alt="{{companyName}}" src="{{companyLogo}}" style="display:block;outline:none;border:none;text-decoration:none;margin:0 auto 14px;max-width:144px;height:auto" width="144"/><p style="font-size:22px;line-height:24px;color:#ffffff;font-weight:700;text-align:center;margin:0;letter-spacing:0.02em;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyName}}</p></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#ffffff;padding:28px;border-left:1px solid #E5E7EB;border-right:1px solid #E5E7EB"><tbody><tr><td><div>\n<h1 style="margin:0 0 12px;color:#111827;font-size:22px;line-height:1.35;font-weight:700;">{{eventLabel payload.event}}{{#if payload.orderNumber}} <span style='display:inline-block;margin-left:8px;padding:4px 10px;border-radius:999px;background:#EEF2FF;color:#4338CA;font-size:12px;font-weight:700;'>#{{payload.orderNumber}}</span>{{/if}}</h1>\n<p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;">{{eventAdminMessage payload}}</p>\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;"><tbody>\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Order number</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{default payload.orderNumber payload.orderId}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Customer</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{default payload.customer.name payload.customer.email}} ({{payload.customer.email}})</td>\n  </tr>\n\n  {{#if payload.customer.phone}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Phone</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.customer.phone}}</td>\n  </tr>\n\n  {{/if}}\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Order date</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.orderDate}}</td>\n  </tr>\n\n  {{#if payload.status}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Status</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.status}}</td>\n  </tr>\n\n  {{/if}}\n  {{#if payload.previousStatus}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Previous status</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.previousStatus}}</td>\n  </tr>\n\n  {{/if}}\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Total</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.grandTotalRaw payload.totals.currency}}</td>\n  </tr>\n\n  {{#if payload.paymentMethod}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Payment method</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.paymentMethod}}</td>\n  </tr>\n\n  {{/if}}\n</tbody></table>\n<hr style="margin:24px 0;border:none;border-top:1px solid #E5E7EB;" />\n<h2 style="margin:0 0 12px;color:#111827;font-size:16px;line-height:1.4;font-weight:700;">Order summary</h2>\n\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;">\n  <thead>\n    <tr>\n      <th align="left" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Item</th>\n      <th align="center" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Qty</th>\n      <th align="right" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Amount</th>\n    </tr>\n  </thead>\n  <tbody>\n    {{#each payload.items}}\n      <tr>\n        <td style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">\n          <div>{{this.name}}</div>\n          {{#if this.description}}\n            <div style="margin-top:4px;color:#6B7280;font-size:12px;line-height:1.5;">{{this.description}}</div>\n          {{/if}}\n        </td>\n        <td align="center" style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">{{this.quantity}}</td>\n        <td align="right" style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">{{formatCurrency this.subtotalRaw ../payload.totals.currency}}</td>\n      </tr>\n    {{/each}}\n  </tbody>\n</table>\n\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;"><tbody>\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Subtotal</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.subtotalRaw payload.totals.currency}}</td>\n  </tr>\n\n    {{#if payload.totals.taxRaw}}\n      \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Tax</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.taxRaw payload.totals.currency}}</td>\n  </tr>\n\n    {{/if}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Total</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;"><strong>{{formatCurrency payload.totals.grandTotalRaw payload.totals.currency}}</strong></td>\n  </tr>\n\n  </tbody></table>\n{{#if (or payload.deliveryEstimateLabel payload.shippingVendor payload.shippingAddress payload.billingAddress)}}\n  <hr style="margin:24px 0;border:none;border-top:1px solid #E5E7EB;" />\n  <h2 style="margin:0 0 12px;color:#111827;font-size:16px;line-height:1.4;font-weight:700;">Delivery & addresses</h2>\n  <table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;"><tbody>\n    {{#if payload.shippingVendor}}\n      \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Carrier</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.shippingVendor}}</td>\n  </tr>\n\n    {{/if}}\n    {{#if payload.deliveryEstimateLabel}}\n      \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Estimated delivery</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.deliveryEstimateLabel}}</td>\n  </tr>\n\n    {{/if}}\n  </tbody></table>\n  {{#if payload.shippingAddress}}\n    <p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;"><strong>Shipping address</strong><br/>{{#each payload.shippingAddress.lines}}{{this}}<br/>{{/each}}</p>\n  {{/if}}\n  {{#if payload.billingAddress}}\n    <p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;"><strong>Billing address</strong><br/>{{#each payload.billingAddress.lines}}{{this}}<br/>{{/each}}</p>\n  {{/if}}\n{{/if}}\n{{#if payload.notes}}\n  <hr style="margin:24px 0;border:none;border-top:1px solid #E5E7EB;" />\n  <p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;"><strong>Notes:</strong> {{payload.notes}}</p>\n{{/if}}\n<hr style="margin:24px 0;border:none;border-top:1px solid #E5E7EB;" />\n\n{{#if (or payload.links.admin payload.adminUrl)}}\n  \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{default (default payload.links.admin payload.adminUrl) '#'}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Open in dashboard</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n{{/if}}\n\n<p style="margin:0;color:#6B7280;font-size:12px;line-height:1.6;">Automated notification generated by the system.</p>\n</div></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#F9FAFB;padding:18px 22px;border-radius:0 0 24px 24px;border:1px solid #E5E7EB;border-top:0"><tbody><tr><td><p style="font-size:12px;line-height:1.5;color:#6B7280;margin:0;text-align:center;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyFooter}}</p></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></body></html>	7	t	2026-05-03 16:26:42.044	2026-05-03 16:26:42.044
4	ORDERS	es	ADMIN	[{{companyName}} - Admin] Nuevo pedido recibido {{#if payload.orderNumber}}#{{payload.orderNumber}}{{/if}}	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html dir="ltr" lang="en"><head><link rel="preload" as="image" href="{{companyLogo}}"/><meta content="text/html; charset=UTF-8" http-equiv="Content-Type"/><meta name="x-apple-disable-message-reformatting"/></head><body style="background-color:#F3F4F6;margin:0;padding:0"><table border="0" width="100%" cellPadding="0" cellSpacing="0" role="presentation" align="center"><tbody><tr><td style="background-color:#F3F4F6;margin:0;padding:24px 0"><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="max-width:640px;margin:0 auto"><tbody><tr style="width:100%"><td><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background:linear-gradient(135deg, #103B34 0%, #1F6F5F 58%, #D9A441 100%);padding:24px 28px;border-radius:24px 24px 0 0"><tbody><tr><td><img alt="{{companyName}}" src="{{companyLogo}}" style="display:block;outline:none;border:none;text-decoration:none;margin:0 auto 14px;max-width:144px;height:auto" width="144"/><p style="font-size:22px;line-height:24px;color:#ffffff;font-weight:700;text-align:center;margin:0;letter-spacing:0.02em;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyName}}</p></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#ffffff;padding:28px;border-left:1px solid #E5E7EB;border-right:1px solid #E5E7EB"><tbody><tr><td><div>\n<h1 style="margin:0 0 12px;color:#111827;font-size:22px;line-height:1.35;font-weight:700;">{{eventLabel payload.event}}{{#if payload.orderNumber}} <span style='display:inline-block;margin-left:8px;padding:4px 10px;border-radius:999px;background:#EEF2FF;color:#4338CA;font-size:12px;font-weight:700;'>#{{payload.orderNumber}}</span>{{/if}}</h1>\n<p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;">{{eventAdminMessage payload}}</p>\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;"><tbody>\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Número de pedido</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{default payload.orderNumber payload.orderId}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Cliente</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{default payload.customer.name payload.customer.email}} ({{payload.customer.email}})</td>\n  </tr>\n\n  {{#if payload.customer.phone}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Teléfono</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.customer.phone}}</td>\n  </tr>\n\n  {{/if}}\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Fecha del pedido</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.orderDate}}</td>\n  </tr>\n\n  {{#if payload.status}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Estado</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.status}}</td>\n  </tr>\n\n  {{/if}}\n  {{#if payload.previousStatus}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Estado anterior</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.previousStatus}}</td>\n  </tr>\n\n  {{/if}}\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Total</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.grandTotalRaw payload.totals.currency}}</td>\n  </tr>\n\n  {{#if payload.paymentMethod}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Método de pago</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.paymentMethod}}</td>\n  </tr>\n\n  {{/if}}\n</tbody></table>\n<hr style="margin:24px 0;border:none;border-top:1px solid #E5E7EB;" />\n<h2 style="margin:0 0 12px;color:#111827;font-size:16px;line-height:1.4;font-weight:700;">Resumen del pedido</h2>\n\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;">\n  <thead>\n    <tr>\n      <th align="left" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Producto</th>\n      <th align="center" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Cant.</th>\n      <th align="right" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Importe</th>\n    </tr>\n  </thead>\n  <tbody>\n    {{#each payload.items}}\n      <tr>\n        <td style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">\n          <div>{{this.name}}</div>\n          {{#if this.description}}\n            <div style="margin-top:4px;color:#6B7280;font-size:12px;line-height:1.5;">{{this.description}}</div>\n          {{/if}}\n        </td>\n        <td align="center" style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">{{this.quantity}}</td>\n        <td align="right" style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">{{formatCurrency this.subtotalRaw ../payload.totals.currency}}</td>\n      </tr>\n    {{/each}}\n  </tbody>\n</table>\n\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;"><tbody>\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Subtotal</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.subtotalRaw payload.totals.currency}}</td>\n  </tr>\n\n    {{#if payload.totals.taxRaw}}\n      \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Impuestos</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.taxRaw payload.totals.currency}}</td>\n  </tr>\n\n    {{/if}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Total</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;"><strong>{{formatCurrency payload.totals.grandTotalRaw payload.totals.currency}}</strong></td>\n  </tr>\n\n  </tbody></table>\n{{#if (or payload.deliveryEstimateLabel payload.shippingVendor payload.shippingAddress payload.billingAddress)}}\n  <hr style="margin:24px 0;border:none;border-top:1px solid #E5E7EB;" />\n  <h2 style="margin:0 0 12px;color:#111827;font-size:16px;line-height:1.4;font-weight:700;">Información de entrega y direcciones</h2>\n  <table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;"><tbody>\n    {{#if payload.shippingVendor}}\n      \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Transportista</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.shippingVendor}}</td>\n  </tr>\n\n    {{/if}}\n    {{#if payload.deliveryEstimateLabel}}\n      \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Tiempo estimado</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.deliveryEstimateLabel}}</td>\n  </tr>\n\n    {{/if}}\n  </tbody></table>\n  {{#if payload.shippingAddress}}\n    <p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;"><strong>Dirección de envío</strong><br/>{{#each payload.shippingAddress.lines}}{{this}}<br/>{{/each}}</p>\n  {{/if}}\n  {{#if payload.billingAddress}}\n    <p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;"><strong>Dirección de facturación</strong><br/>{{#each payload.billingAddress.lines}}{{this}}<br/>{{/each}}</p>\n  {{/if}}\n{{/if}}\n{{#if payload.notes}}\n  <hr style="margin:24px 0;border:none;border-top:1px solid #E5E7EB;" />\n  <p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;"><strong>Notas:</strong> {{payload.notes}}</p>\n{{/if}}\n<hr style="margin:24px 0;border:none;border-top:1px solid #E5E7EB;" />\n\n{{#if (or payload.links.admin payload.adminUrl)}}\n  \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{default (default payload.links.admin payload.adminUrl) '#'}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Abrir en panel</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n{{/if}}\n\n<p style="margin:0;color:#6B7280;font-size:12px;line-height:1.6;">Notificación automática generada por el sistema.</p>\n</div></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#F9FAFB;padding:18px 22px;border-radius:0 0 24px 24px;border:1px solid #E5E7EB;border-top:0"><tbody><tr><td><p style="font-size:12px;line-height:1.5;color:#6B7280;margin:0;text-align:center;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyFooter}}</p></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></body></html>	7	t	2026-05-03 16:26:42.045	2026-05-03 16:26:42.045
5	PAYMENTS	en	CUSTOMER	Payment received for order #{{payload.orderNumber}}	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html dir="ltr" lang="en"><head><link rel="preload" as="image" href="{{companyLogo}}"/><meta content="text/html; charset=UTF-8" http-equiv="Content-Type"/><meta name="x-apple-disable-message-reformatting"/></head><body style="background-color:#F3F4F6;margin:0;padding:0"><table border="0" width="100%" cellPadding="0" cellSpacing="0" role="presentation" align="center"><tbody><tr><td style="background-color:#F3F4F6;margin:0;padding:24px 0"><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="max-width:640px;margin:0 auto"><tbody><tr style="width:100%"><td><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background:linear-gradient(135deg, #103B34 0%, #1F6F5F 58%, #D9A441 100%);padding:24px 28px;border-radius:24px 24px 0 0"><tbody><tr><td><img alt="{{companyName}}" src="{{companyLogo}}" style="display:block;outline:none;border:none;text-decoration:none;margin:0 auto 14px;max-width:144px;height:auto" width="144"/><p style="font-size:22px;line-height:24px;color:#ffffff;font-weight:700;text-align:center;margin:0;letter-spacing:0.02em;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyName}}</p></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#ffffff;padding:28px;border-left:1px solid #E5E7EB;border-right:1px solid #E5E7EB"><tbody><tr><td><div>\n<h1 style="margin:0 0 12px;color:#111827;font-size:22px;line-height:1.35;font-weight:700;">{{#if payload.isFullyPaid}}Payment confirmed{{else}}Partial payment received{{/if}}</h1>\n<p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;">{{#if payload.isFullyPaid}}We confirmed your payment for order {{#if payload.orderNumber}}#{{payload.orderNumber}}{{else}}#{{payload.orderId}}{{/if}}. Your purchase is fully paid and continues to the next stage.{{else}}We confirmed a partial payment for order {{#if payload.orderNumber}}#{{payload.orderNumber}}{{else}}#{{payload.orderId}}{{/if}}. The remaining balance is shown below.{{/if}}</p>\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;"><tbody>\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Order number</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{default payload.orderNumber payload.orderId}}</td>\n  </tr>\n\n  {{#if payload.orderDate}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Order date</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.orderDate}}</td>\n  </tr>\n\n  {{/if}}\n  {{#if payload.orderStatus}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Order status</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.orderStatus}}</td>\n  </tr>\n\n  {{/if}}\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Payment amount</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.amountRaw payload.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Paid so far</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.totalPaidRaw payload.totals.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Remaining balance</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.remainingRaw payload.totals.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Order total</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.grandTotalRaw payload.totals.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Payment status</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.statusLabel}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Method</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.method}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Reference</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{#if payload.paymentId}}#{{payload.paymentId}}{{else}}-{{/if}}</td>\n  </tr>\n\n  {{#if payload.reference}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Provider reference</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.reference}}</td>\n  </tr>\n\n  {{/if}}\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Processed at</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.processedAt}}</td>\n  </tr>\n\n</tbody></table>\n<hr style="margin:24px 0;border:none;border-top:1px solid #E5E7EB;" />\n<h2 style="margin:0 0 12px;color:#111827;font-size:16px;line-height:1.4;font-weight:700;">Order summary</h2>\n\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;">\n  <thead>\n    <tr>\n      <th align="left" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Item</th>\n      <th align="center" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Qty</th>\n      <th align="right" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Amount</th>\n    </tr>\n  </thead>\n  <tbody>\n    {{#each payload.items}}\n      <tr>\n        <td style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">\n          <div>{{this.name}}</div>\n          {{#if this.description}}\n            <div style="margin-top:4px;color:#6B7280;font-size:12px;line-height:1.5;">{{this.description}}</div>\n          {{/if}}\n        </td>\n        <td align="center" style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">{{this.quantity}}</td>\n        <td align="right" style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">{{formatCurrency this.subtotalRaw ../payload.totals.currency}}</td>\n      </tr>\n    {{/each}}\n  </tbody>\n</table>\n\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;"><tbody>\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Paid so far</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.totalPaidRaw payload.totals.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Remaining balance</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.remainingRaw payload.totals.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Order total</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;"><strong>{{formatCurrency payload.totals.grandTotalRaw payload.totals.currency}}</strong></td>\n  </tr>\n\n</tbody></table>\n{{#if payload.links.customer}}\n  \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{payload.links.customer}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">View order details</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n{{else if payload.portalUrl}}\n  \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{payload.portalUrl}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">View your orders</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n{{/if}}\n{{#if payload.portalUrl}}\n  <p style="margin:0;color:#6B7280;font-size:12px;line-height:1.6;">You can review the latest status from your customer account.</p>\n{{/if}}\n<p style="margin:0;color:#6B7280;font-size:12px;line-height:1.6;">Keep this receipt for your records.</p>\n</div></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#F9FAFB;padding:18px 22px;border-radius:0 0 24px 24px;border:1px solid #E5E7EB;border-top:0"><tbody><tr><td><p style="font-size:12px;line-height:1.5;color:#6B7280;margin:0;text-align:center;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyFooter}}</p></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></body></html>	4	t	2026-05-03 16:26:42.046	2026-05-03 16:26:42.046
6	PAYMENTS	es	CUSTOMER	Pago recibido para el pedido #{{payload.orderNumber}}	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html dir="ltr" lang="en"><head><link rel="preload" as="image" href="{{companyLogo}}"/><meta content="text/html; charset=UTF-8" http-equiv="Content-Type"/><meta name="x-apple-disable-message-reformatting"/></head><body style="background-color:#F3F4F6;margin:0;padding:0"><table border="0" width="100%" cellPadding="0" cellSpacing="0" role="presentation" align="center"><tbody><tr><td style="background-color:#F3F4F6;margin:0;padding:24px 0"><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="max-width:640px;margin:0 auto"><tbody><tr style="width:100%"><td><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background:linear-gradient(135deg, #103B34 0%, #1F6F5F 58%, #D9A441 100%);padding:24px 28px;border-radius:24px 24px 0 0"><tbody><tr><td><img alt="{{companyName}}" src="{{companyLogo}}" style="display:block;outline:none;border:none;text-decoration:none;margin:0 auto 14px;max-width:144px;height:auto" width="144"/><p style="font-size:22px;line-height:24px;color:#ffffff;font-weight:700;text-align:center;margin:0;letter-spacing:0.02em;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyName}}</p></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#ffffff;padding:28px;border-left:1px solid #E5E7EB;border-right:1px solid #E5E7EB"><tbody><tr><td><div>\n<h1 style="margin:0 0 12px;color:#111827;font-size:22px;line-height:1.35;font-weight:700;">{{#if payload.isFullyPaid}}Pago confirmado{{else}}Pago parcial recibido{{/if}}</h1>\n<p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;">{{#if payload.isFullyPaid}}Confirmamos tu pago para el pedido {{#if payload.orderNumber}}#{{payload.orderNumber}}{{else}}#{{payload.orderId}}{{/if}}. Tu compra quedó totalmente pagada y sigue a la próxima etapa.{{else}}Confirmamos un pago parcial para el pedido {{#if payload.orderNumber}}#{{payload.orderNumber}}{{else}}#{{payload.orderId}}{{/if}}. El saldo pendiente se muestra debajo.{{/if}}</p>\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;"><tbody>\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Número de pedido</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{default payload.orderNumber payload.orderId}}</td>\n  </tr>\n\n  {{#if payload.orderDate}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Fecha del pedido</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.orderDate}}</td>\n  </tr>\n\n  {{/if}}\n  {{#if payload.orderStatus}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Estado del pedido</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.orderStatus}}</td>\n  </tr>\n\n  {{/if}}\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Monto del pago</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.amountRaw payload.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Pagado hasta ahora</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.totalPaidRaw payload.totals.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Saldo pendiente</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.remainingRaw payload.totals.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Total del pedido</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.grandTotalRaw payload.totals.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Estado del pago</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.statusLabel}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Método</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.method}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Referencia</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{#if payload.paymentId}}#{{payload.paymentId}}{{else}}-{{/if}}</td>\n  </tr>\n\n  {{#if payload.reference}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Referencia del proveedor</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.reference}}</td>\n  </tr>\n\n  {{/if}}\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Procesado el</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.processedAt}}</td>\n  </tr>\n\n</tbody></table>\n<hr style="margin:24px 0;border:none;border-top:1px solid #E5E7EB;" />\n<h2 style="margin:0 0 12px;color:#111827;font-size:16px;line-height:1.4;font-weight:700;">Resumen del pedido</h2>\n\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;">\n  <thead>\n    <tr>\n      <th align="left" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Producto</th>\n      <th align="center" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Cant.</th>\n      <th align="right" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Importe</th>\n    </tr>\n  </thead>\n  <tbody>\n    {{#each payload.items}}\n      <tr>\n        <td style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">\n          <div>{{this.name}}</div>\n          {{#if this.description}}\n            <div style="margin-top:4px;color:#6B7280;font-size:12px;line-height:1.5;">{{this.description}}</div>\n          {{/if}}\n        </td>\n        <td align="center" style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">{{this.quantity}}</td>\n        <td align="right" style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">{{formatCurrency this.subtotalRaw ../payload.totals.currency}}</td>\n      </tr>\n    {{/each}}\n  </tbody>\n</table>\n\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;"><tbody>\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Pagado hasta ahora</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.totalPaidRaw payload.totals.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Saldo pendiente</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.remainingRaw payload.totals.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Total del pedido</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;"><strong>{{formatCurrency payload.totals.grandTotalRaw payload.totals.currency}}</strong></td>\n  </tr>\n\n</tbody></table>\n{{#if payload.links.customer}}\n  \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{payload.links.customer}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Ver detalle del pedido</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n{{else if payload.portalUrl}}\n  \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{payload.portalUrl}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Ver mis compras</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n{{/if}}\n{{#if payload.portalUrl}}\n  <p style="margin:0;color:#6B7280;font-size:12px;line-height:1.6;">Podés revisar el estado actualizado desde tu cuenta de cliente.</p>\n{{/if}}\n<p style="margin:0;color:#6B7280;font-size:12px;line-height:1.6;">Guardá este comprobante para tus registros.</p>\n</div></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#F9FAFB;padding:18px 22px;border-radius:0 0 24px 24px;border:1px solid #E5E7EB;border-top:0"><tbody><tr><td><p style="font-size:12px;line-height:1.5;color:#6B7280;margin:0;text-align:center;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyFooter}}</p></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></body></html>	4	t	2026-05-03 16:26:42.047	2026-05-03 16:26:42.047
7	PAYMENTS	en	ADMIN	[Payments] Payment received for order #{{payload.orderNumber}}	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html dir="ltr" lang="en"><head><link rel="preload" as="image" href="{{companyLogo}}"/><meta content="text/html; charset=UTF-8" http-equiv="Content-Type"/><meta name="x-apple-disable-message-reformatting"/></head><body style="background-color:#F3F4F6;margin:0;padding:0"><table border="0" width="100%" cellPadding="0" cellSpacing="0" role="presentation" align="center"><tbody><tr><td style="background-color:#F3F4F6;margin:0;padding:24px 0"><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="max-width:640px;margin:0 auto"><tbody><tr style="width:100%"><td><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background:linear-gradient(135deg, #103B34 0%, #1F6F5F 58%, #D9A441 100%);padding:24px 28px;border-radius:24px 24px 0 0"><tbody><tr><td><img alt="{{companyName}}" src="{{companyLogo}}" style="display:block;outline:none;border:none;text-decoration:none;margin:0 auto 14px;max-width:144px;height:auto" width="144"/><p style="font-size:22px;line-height:24px;color:#ffffff;font-weight:700;text-align:center;margin:0;letter-spacing:0.02em;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyName}}</p></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#ffffff;padding:28px;border-left:1px solid #E5E7EB;border-right:1px solid #E5E7EB"><tbody><tr><td><div>\n<h1 style="margin:0 0 12px;color:#111827;font-size:22px;line-height:1.35;font-weight:700;">Payment received</h1>\n<p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;">A payment was recorded for order {{#if payload.orderNumber}}#{{payload.orderNumber}}{{else}}#{{payload.orderId}}{{/if}}. Review the settlement details below.</p>\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;"><tbody>\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Order number</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{default payload.orderNumber payload.orderId}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Customer</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.customer.name}} ({{payload.customer.email}})</td>\n  </tr>\n\n  {{#if payload.customer.phone}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Phone</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.customer.phone}}</td>\n  </tr>\n\n  {{/if}}\n  {{#if payload.orderStatus}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Order status</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.orderStatus}}</td>\n  </tr>\n\n  {{/if}}\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Payment amount</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.amountRaw payload.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Paid so far</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.totalPaidRaw payload.totals.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Remaining balance</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.remainingRaw payload.totals.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Order total</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.grandTotalRaw payload.totals.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Payment status</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.statusLabel}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Method</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.method}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Reference</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{#if payload.paymentId}}#{{payload.paymentId}}{{else}}-{{/if}}</td>\n  </tr>\n\n  {{#if payload.reference}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Provider reference</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.reference}}</td>\n  </tr>\n\n  {{/if}}\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Processed at</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.processedAt}}</td>\n  </tr>\n\n</tbody></table>\n<hr style="margin:24px 0;border:none;border-top:1px solid #E5E7EB;" />\n<h2 style="margin:0 0 12px;color:#111827;font-size:16px;line-height:1.4;font-weight:700;">Order summary</h2>\n\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;">\n  <thead>\n    <tr>\n      <th align="left" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Item</th>\n      <th align="center" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Qty</th>\n      <th align="right" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Amount</th>\n    </tr>\n  </thead>\n  <tbody>\n    {{#each payload.items}}\n      <tr>\n        <td style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">\n          <div>{{this.name}}</div>\n          {{#if this.description}}\n            <div style="margin-top:4px;color:#6B7280;font-size:12px;line-height:1.5;">{{this.description}}</div>\n          {{/if}}\n        </td>\n        <td align="center" style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">{{this.quantity}}</td>\n        <td align="right" style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">{{formatCurrency this.subtotalRaw ../payload.totals.currency}}</td>\n      </tr>\n    {{/each}}\n  </tbody>\n</table>\n\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;"><tbody>\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Paid so far</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.totalPaidRaw payload.totals.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Remaining balance</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.remainingRaw payload.totals.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Order total</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;"><strong>{{formatCurrency payload.totals.grandTotalRaw payload.totals.currency}}</strong></td>\n  </tr>\n\n</tbody></table>\n{{#if payload.links.admin}}\n  \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{payload.links.admin}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Open order in dashboard</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n{{else if payload.adminUrl}}\n  \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{payload.adminUrl}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Open dashboard</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n{{/if}}\n</div></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#F9FAFB;padding:18px 22px;border-radius:0 0 24px 24px;border:1px solid #E5E7EB;border-top:0"><tbody><tr><td><p style="font-size:12px;line-height:1.5;color:#6B7280;margin:0;text-align:center;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyFooter}}</p></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></body></html>	3	t	2026-05-03 16:26:42.048	2026-05-03 16:26:42.048
8	PAYMENTS	es	ADMIN	[Pagos] Pago registrado para el pedido #{{payload.orderNumber}}	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html dir="ltr" lang="en"><head><link rel="preload" as="image" href="{{companyLogo}}"/><meta content="text/html; charset=UTF-8" http-equiv="Content-Type"/><meta name="x-apple-disable-message-reformatting"/></head><body style="background-color:#F3F4F6;margin:0;padding:0"><table border="0" width="100%" cellPadding="0" cellSpacing="0" role="presentation" align="center"><tbody><tr><td style="background-color:#F3F4F6;margin:0;padding:24px 0"><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="max-width:640px;margin:0 auto"><tbody><tr style="width:100%"><td><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background:linear-gradient(135deg, #103B34 0%, #1F6F5F 58%, #D9A441 100%);padding:24px 28px;border-radius:24px 24px 0 0"><tbody><tr><td><img alt="{{companyName}}" src="{{companyLogo}}" style="display:block;outline:none;border:none;text-decoration:none;margin:0 auto 14px;max-width:144px;height:auto" width="144"/><p style="font-size:22px;line-height:24px;color:#ffffff;font-weight:700;text-align:center;margin:0;letter-spacing:0.02em;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyName}}</p></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#ffffff;padding:28px;border-left:1px solid #E5E7EB;border-right:1px solid #E5E7EB"><tbody><tr><td><div>\n<h1 style="margin:0 0 12px;color:#111827;font-size:22px;line-height:1.35;font-weight:700;">Pago recibido</h1>\n<p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;">Se registró un pago para el pedido {{#if payload.orderNumber}}#{{payload.orderNumber}}{{else}}#{{payload.orderId}}{{/if}}. Revisá debajo el estado de cobranza.</p>\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;"><tbody>\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Número de pedido</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{default payload.orderNumber payload.orderId}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Cliente</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.customer.name}} ({{payload.customer.email}})</td>\n  </tr>\n\n  {{#if payload.customer.phone}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Teléfono</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.customer.phone}}</td>\n  </tr>\n\n  {{/if}}\n  {{#if payload.orderStatus}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Estado del pedido</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.orderStatus}}</td>\n  </tr>\n\n  {{/if}}\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Monto del pago</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.amountRaw payload.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Pagado hasta ahora</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.totalPaidRaw payload.totals.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Saldo pendiente</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.remainingRaw payload.totals.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Total del pedido</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.grandTotalRaw payload.totals.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Estado del pago</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.statusLabel}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Método</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.method}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Referencia</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{#if payload.paymentId}}#{{payload.paymentId}}{{else}}-{{/if}}</td>\n  </tr>\n\n  {{#if payload.reference}}\n    \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Referencia del proveedor</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.reference}}</td>\n  </tr>\n\n  {{/if}}\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Procesado el</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{payload.processedAt}}</td>\n  </tr>\n\n</tbody></table>\n<hr style="margin:24px 0;border:none;border-top:1px solid #E5E7EB;" />\n<h2 style="margin:0 0 12px;color:#111827;font-size:16px;line-height:1.4;font-weight:700;">Resumen del pedido</h2>\n\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;">\n  <thead>\n    <tr>\n      <th align="left" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Producto</th>\n      <th align="center" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Cant.</th>\n      <th align="right" style="padding:8px 0;border-bottom:1px solid #E5E7EB;color:#6B7280;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">Importe</th>\n    </tr>\n  </thead>\n  <tbody>\n    {{#each payload.items}}\n      <tr>\n        <td style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">\n          <div>{{this.name}}</div>\n          {{#if this.description}}\n            <div style="margin-top:4px;color:#6B7280;font-size:12px;line-height:1.5;">{{this.description}}</div>\n          {{/if}}\n        </td>\n        <td align="center" style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">{{this.quantity}}</td>\n        <td align="right" style="padding:10px 0;border-bottom:1px solid #F3F4F6;color:#111827;font-size:14px;line-height:1.6;">{{formatCurrency this.subtotalRaw ../payload.totals.currency}}</td>\n      </tr>\n    {{/each}}\n  </tbody>\n</table>\n\n<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 16px;"><tbody>\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Pagado hasta ahora</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.totalPaidRaw payload.totals.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Saldo pendiente</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;">{{formatCurrency payload.totals.remainingRaw payload.totals.currency}}</td>\n  </tr>\n\n  \n  <tr>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;"><strong>Total del pedido</strong></td>\n    <td style="padding:8px 0;color:#111827;font-size:14px;line-height:1.5;text-align:right;"><strong>{{formatCurrency payload.totals.grandTotalRaw payload.totals.currency}}</strong></td>\n  </tr>\n\n</tbody></table>\n{{#if payload.links.admin}}\n  \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{payload.links.admin}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Abrir pedido en el panel</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n{{else if payload.adminUrl}}\n  \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{payload.adminUrl}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Abrir panel</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n{{/if}}\n</div></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#F9FAFB;padding:18px 22px;border-radius:0 0 24px 24px;border:1px solid #E5E7EB;border-top:0"><tbody><tr><td><p style="font-size:12px;line-height:1.5;color:#6B7280;margin:0;text-align:center;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyFooter}}</p></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></body></html>	3	t	2026-05-03 16:26:42.049	2026-05-03 16:26:42.049
9	AUTH	en	CUSTOMER	{{#if (eq payload.event 'welcome')}}Welcome to {{companyName}}{{else if (eq payload.event 'verify_email')}}Confirm your email for {{companyName}}{{else if (eq payload.event 'password_changed')}}Your {{companyName}} password was updated{{else if (eq payload.event 'recovery_notice')}}Password recovery requested for {{companyName}}{{else}}Reset your {{companyName}} password{{/if}}	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html dir="ltr" lang="en"><head><link rel="preload" as="image" href="{{companyLogo}}"/><meta content="text/html; charset=UTF-8" http-equiv="Content-Type"/><meta name="x-apple-disable-message-reformatting"/></head><body style="background-color:#F3F4F6;margin:0;padding:0"><table border="0" width="100%" cellPadding="0" cellSpacing="0" role="presentation" align="center"><tbody><tr><td style="background-color:#F3F4F6;margin:0;padding:24px 0"><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="max-width:640px;margin:0 auto"><tbody><tr style="width:100%"><td><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background:linear-gradient(135deg, #103B34 0%, #1F6F5F 58%, #D9A441 100%);padding:24px 28px;border-radius:24px 24px 0 0"><tbody><tr><td><img alt="{{companyName}}" src="{{companyLogo}}" style="display:block;outline:none;border:none;text-decoration:none;margin:0 auto 14px;max-width:144px;height:auto" width="144"/><p style="font-size:22px;line-height:24px;color:#ffffff;font-weight:700;text-align:center;margin:0;letter-spacing:0.02em;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyName}}</p></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#ffffff;padding:28px;border-left:1px solid #E5E7EB;border-right:1px solid #E5E7EB"><tbody><tr><td><div>\n<h1 style="margin:0 0 12px;color:#111827;font-size:22px;line-height:1.35;font-weight:700;">{{#if (eq payload.event 'welcome')}}Welcome to {{companyName}}{{else if (eq payload.event 'verify_email')}}Confirm your email{{else if (eq payload.event 'password_changed')}}Your password was updated{{else if (eq payload.event 'recovery_notice')}}Password recovery requested{{else}}Reset your password{{/if}}</h1>\n<p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;">{{#if (eq payload.event 'welcome')}}Hello {{payload.displayName}}, your account is ready. From now on you can follow orders, manage saved addresses and discover everything available in the store from one place.{{else if (eq payload.event 'verify_email')}}Hello {{payload.displayName}}, confirm your email address to finish activating your account and receive updates about orders, payments and account activity.{{#if payload.expiresAt}} This link expires on {{payload.expiresAt}}.{{/if}}{{else if (eq payload.event 'password_changed')}}Hello {{payload.displayName}}, your password was just updated. If you did not make this change, secure your account immediately.{{else if (eq payload.event 'recovery_notice')}}Hello {{payload.displayName}}, we received a request to recover access to your account. If it was you, follow the steps below. If not, secure your account to keep it safe.{{else}}Hello {{payload.displayName}}, we received a request to reset your password. Use the button below to choose a new one.{{#if payload.expiresAt}} This link expires on {{payload.expiresAt}}.{{/if}}{{/if}}</p>\n{{#if (eq payload.event 'welcome')}}\n  {{#if payload.accountUrl}}\n    \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{payload.accountUrl}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Go to my account</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n  {{/if}}\n  <p style="margin:0;color:#6B7280;font-size:12px;line-height:1.6;">Use your account to track purchases, manage delivery details and continue browsing the products and solutions available on the site.</p>\n{{else if (eq payload.event 'verify_email')}}\n  {{#if payload.resetUrl}}\n    \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{payload.resetUrl}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Confirm email</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n  {{/if}}\n  {{#if payload.accountUrl}}\n    \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{payload.accountUrl}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Open my account</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n  {{/if}}\n  <p style="margin:0;color:#6B7280;font-size:12px;line-height:1.6;">Once your email is confirmed, we will use it as the main channel for order updates and account security notifications.</p>\n{{else if payload.resetUrl}}\n  \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{payload.resetUrl}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">{{#if (eq payload.event 'reset_link')}}Reset password{{else}}Secure account{{/if}}</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n{{/if}}\n<p style="margin:0;color:#6B7280;font-size:12px;line-height:1.6;">{{#if (eq payload.event 'welcome')}}If you need help getting started, reply to this email and our team will assist you.{{else if (eq payload.event 'verify_email')}}If you did not create this account, you can safely ignore this message.{{else if (eq payload.event 'password_changed')}}If you did not authorize this change, secure your account or contact us immediately.{{else if (eq payload.event 'recovery_notice')}}If this wasn't you, secure your account to prevent unauthorized access.{{else}}Didn't request this? You can safely ignore this email.{{/if}}</p>\n</div></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#F9FAFB;padding:18px 22px;border-radius:0 0 24px 24px;border:1px solid #E5E7EB;border-top:0"><tbody><tr><td><p style="font-size:12px;line-height:1.5;color:#6B7280;margin:0;text-align:center;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyFooter}}</p></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></body></html>	4	t	2026-05-03 16:26:42.049	2026-05-03 16:26:42.049
10	AUTH	es	CUSTOMER	{{#if (eq payload.event 'welcome')}}Bienvenido a {{companyName}}{{else if (eq payload.event 'verify_email')}}Confirmá tu correo para {{companyName}}{{else if (eq payload.event 'password_changed')}}Tu contraseña de {{companyName}} fue actualizada{{else if (eq payload.event 'recovery_notice')}}Solicitud de recuperación para {{companyName}}{{else}}Restablecé tu contraseña de {{companyName}}{{/if}}	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html dir="ltr" lang="en"><head><link rel="preload" as="image" href="{{companyLogo}}"/><meta content="text/html; charset=UTF-8" http-equiv="Content-Type"/><meta name="x-apple-disable-message-reformatting"/></head><body style="background-color:#F3F4F6;margin:0;padding:0"><table border="0" width="100%" cellPadding="0" cellSpacing="0" role="presentation" align="center"><tbody><tr><td style="background-color:#F3F4F6;margin:0;padding:24px 0"><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="max-width:640px;margin:0 auto"><tbody><tr style="width:100%"><td><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background:linear-gradient(135deg, #103B34 0%, #1F6F5F 58%, #D9A441 100%);padding:24px 28px;border-radius:24px 24px 0 0"><tbody><tr><td><img alt="{{companyName}}" src="{{companyLogo}}" style="display:block;outline:none;border:none;text-decoration:none;margin:0 auto 14px;max-width:144px;height:auto" width="144"/><p style="font-size:22px;line-height:24px;color:#ffffff;font-weight:700;text-align:center;margin:0;letter-spacing:0.02em;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyName}}</p></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#ffffff;padding:28px;border-left:1px solid #E5E7EB;border-right:1px solid #E5E7EB"><tbody><tr><td><div>\n<h1 style="margin:0 0 12px;color:#111827;font-size:22px;line-height:1.35;font-weight:700;">{{#if (eq payload.event 'welcome')}}Bienvenido a {{companyName}}{{else if (eq payload.event 'verify_email')}}Confirmá tu correo electrónico{{else if (eq payload.event 'password_changed')}}Tu contraseña fue actualizada{{else if (eq payload.event 'recovery_notice')}}Solicitud de recuperación{{else}}Restablecé tu contraseña{{/if}}</h1>\n<p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;">{{#if (eq payload.event 'welcome')}}Hola {{payload.displayName}}, tu cuenta ya está lista. Desde ahora podés seguir tus pedidos, administrar direcciones guardadas y descubrir todo lo que ya podés comprar en el sitio desde un mismo lugar.{{else if (eq payload.event 'verify_email')}}Hola {{payload.displayName}}, confirmá tu correo electrónico para terminar de activar tu cuenta y recibir novedades sobre pedidos, pagos y movimientos de tu cuenta.{{#if payload.expiresAt}} Este enlace vence el {{payload.expiresAt}}.{{/if}}{{else if (eq payload.event 'password_changed')}}Hola {{payload.displayName}}, acabamos de actualizar tu contraseña. Si no fuiste vos, asegurá tu cuenta de inmediato.{{else if (eq payload.event 'recovery_notice')}}Hola {{payload.displayName}}, recibimos una solicitud para recuperar el acceso a tu cuenta. Si fuiste vos, seguí los pasos a continuación. Si no la hiciste, protegé tu cuenta.{{else}}Hola {{payload.displayName}}, recibimos una solicitud para restablecer tu contraseña. Utilizá el siguiente botón para crear una nueva.{{#if payload.expiresAt}} El enlace vence el {{payload.expiresAt}}.{{/if}}{{/if}}</p>\n{{#if (eq payload.event 'welcome')}}\n  {{#if payload.accountUrl}}\n    \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{payload.accountUrl}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Ir a mi cuenta</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n  {{/if}}\n  <p style="margin:0;color:#6B7280;font-size:12px;line-height:1.6;">Usá tu cuenta para seguir compras, gestionar entregas y seguir explorando productos y soluciones publicadas en el sitio.</p>\n{{else if (eq payload.event 'verify_email')}}\n  {{#if payload.resetUrl}}\n    \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{payload.resetUrl}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Confirmar correo</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n  {{/if}}\n  {{#if payload.accountUrl}}\n    \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{payload.accountUrl}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">Acceder a mi cuenta</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n  {{/if}}\n  <p style="margin:0;color:#6B7280;font-size:12px;line-height:1.6;">Una vez confirmado tu correo, lo usaremos como canal principal para avisos de pedidos y notificaciones de seguridad de tu cuenta.</p>\n{{else if payload.resetUrl}}\n  \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{payload.resetUrl}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">{{#if (eq payload.event 'reset_link')}}Restablecer contraseña{{else}}Proteger cuenta{{/if}}</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n{{/if}}\n<p style="margin:0;color:#6B7280;font-size:12px;line-height:1.6;">{{#if (eq payload.event 'welcome')}}Si necesitás ayuda para empezar, respondé este correo y te ayudaremos.{{else if (eq payload.event 'verify_email')}}Si no creaste esta cuenta, podés ignorar este mensaje.{{else if (eq payload.event 'password_changed')}}Si no realizaste este cambio, asegurá tu cuenta o contactanos de inmediato.{{else if (eq payload.event 'recovery_notice')}}Si no fuiste vos, protegé tu cuenta para evitar accesos no autorizados.{{else}}¿No solicitaste esto? Podés ignorar este mensaje.{{/if}}</p>\n</div></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#F9FAFB;padding:18px 22px;border-radius:0 0 24px 24px;border:1px solid #E5E7EB;border-top:0"><tbody><tr><td><p style="font-size:12px;line-height:1.5;color:#6B7280;margin:0;text-align:center;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyFooter}}</p></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></body></html>	4	t	2026-05-03 16:26:42.05	2026-05-03 16:26:42.05
11	AUTH	en	ADMIN	Reset your administrator password	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html dir="ltr" lang="en"><head><link rel="preload" as="image" href="{{companyLogo}}"/><meta content="text/html; charset=UTF-8" http-equiv="Content-Type"/><meta name="x-apple-disable-message-reformatting"/></head><body style="background-color:#F3F4F6;margin:0;padding:0"><table border="0" width="100%" cellPadding="0" cellSpacing="0" role="presentation" align="center"><tbody><tr><td style="background-color:#F3F4F6;margin:0;padding:24px 0"><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="max-width:640px;margin:0 auto"><tbody><tr style="width:100%"><td><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background:linear-gradient(135deg, #103B34 0%, #1F6F5F 58%, #D9A441 100%);padding:24px 28px;border-radius:24px 24px 0 0"><tbody><tr><td><img alt="{{companyName}}" src="{{companyLogo}}" style="display:block;outline:none;border:none;text-decoration:none;margin:0 auto 14px;max-width:144px;height:auto" width="144"/><p style="font-size:22px;line-height:24px;color:#ffffff;font-weight:700;text-align:center;margin:0;letter-spacing:0.02em;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyName}}</p></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#ffffff;padding:28px;border-left:1px solid #E5E7EB;border-right:1px solid #E5E7EB"><tbody><tr><td><div>\n<h1 style="margin:0 0 12px;color:#111827;font-size:22px;line-height:1.35;font-weight:700;">{{#if (eq payload.event 'password_changed')}}Administrator password updated{{else if (eq payload.event 'recovery_notice')}}Administrator recovery requested{{else}}Admin password reset{{/if}}</h1>\n<p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;">{{#if (eq payload.event 'password_changed')}}Hi {{payload.displayName}}, your administrator password was updated. If you didn't authorize this change, secure your account and alert the security team.{{else if (eq payload.event 'recovery_notice')}}Hi {{payload.displayName}}, we received a request to recover your administrator account. If this wasn't you, secure your account immediately.{{else}}Hi {{payload.displayName}}, you requested to reset your administrator password. Click the button below to continue.{{#if payload.expiresAt}} The link expires on {{payload.expiresAt}}.{{/if}}{{/if}}</p>\n{{#if payload.resetUrl}}\n  \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{payload.resetUrl}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">{{#if (eq payload.event 'reset_link')}}Reset administrator password{{else}}Secure administrator account{{/if}}</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n{{/if}}\n<p style="margin:0;color:#6B7280;font-size:12px;line-height:1.6;">{{#if (eq payload.event 'reset_link')}}If you no longer need this, you can safely ignore this email.{{else}}If this wasn't you, contact an administrator immediately.{{/if}}</p>\n</div></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#F9FAFB;padding:18px 22px;border-radius:0 0 24px 24px;border:1px solid #E5E7EB;border-top:0"><tbody><tr><td><p style="font-size:12px;line-height:1.5;color:#6B7280;margin:0;text-align:center;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyFooter}}</p></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></body></html>	2	t	2026-05-03 16:26:42.051	2026-05-03 16:26:42.051
12	AUTH	es	ADMIN	Restablecer contraseña de administrador	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html dir="ltr" lang="en"><head><link rel="preload" as="image" href="{{companyLogo}}"/><meta content="text/html; charset=UTF-8" http-equiv="Content-Type"/><meta name="x-apple-disable-message-reformatting"/></head><body style="background-color:#F3F4F6;margin:0;padding:0"><table border="0" width="100%" cellPadding="0" cellSpacing="0" role="presentation" align="center"><tbody><tr><td style="background-color:#F3F4F6;margin:0;padding:24px 0"><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="max-width:640px;margin:0 auto"><tbody><tr style="width:100%"><td><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background:linear-gradient(135deg, #103B34 0%, #1F6F5F 58%, #D9A441 100%);padding:24px 28px;border-radius:24px 24px 0 0"><tbody><tr><td><img alt="{{companyName}}" src="{{companyLogo}}" style="display:block;outline:none;border:none;text-decoration:none;margin:0 auto 14px;max-width:144px;height:auto" width="144"/><p style="font-size:22px;line-height:24px;color:#ffffff;font-weight:700;text-align:center;margin:0;letter-spacing:0.02em;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyName}}</p></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#ffffff;padding:28px;border-left:1px solid #E5E7EB;border-right:1px solid #E5E7EB"><tbody><tr><td><div>\n<h1 style="margin:0 0 12px;color:#111827;font-size:22px;line-height:1.35;font-weight:700;">{{#if (eq payload.event 'password_changed')}}Contraseña de administrador actualizada{{else if (eq payload.event 'recovery_notice')}}Solicitud de recuperación de administrador{{else}}Restablecer contraseña de administrador{{/if}}</h1>\n<p style="margin:0 0 16px;color:#111827;font-size:14px;line-height:1.7;">{{#if (eq payload.event 'password_changed')}}Hola {{payload.displayName}}, tu contraseña de administrador fue actualizada. Si no fuiste vos, asegurá la cuenta y avisá al equipo de seguridad.{{else if (eq payload.event 'recovery_notice')}}Hola {{payload.displayName}}, recibimos una solicitud para recuperar tu cuenta de administrador. Si no la hiciste, protegé tu cuenta de inmediato.{{else}}Hola {{payload.displayName}}, solicitaste restablecer tu contraseña de administrador. Hacé clic en el botón para continuar.{{#if payload.expiresAt}} El enlace vence el {{payload.expiresAt}}.{{/if}}{{/if}}</p>\n{{#if payload.resetUrl}}\n  \n  <table role="presentation" style="margin:0 0 16px;">\n    <tbody>\n      <tr>\n        <td>\n          <a href="{{payload.resetUrl}}" style="display:inline-block;padding:12px 20px;border-radius:10px;background:#111827;color:#FFFFFF !important;font-size:14px;font-weight:600;text-decoration:none;">{{#if (eq payload.event 'reset_link')}}Restablecer contraseña{{else}}Proteger cuenta de administrador{{/if}}</a>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n\n{{/if}}\n<p style="margin:0;color:#6B7280;font-size:12px;line-height:1.6;">{{#if (eq payload.event 'reset_link')}}Si ya no necesitás esta acción, podés ignorar este mensaje.{{else}}Si no fuiste vos, contactá a un administrador de inmediato.{{/if}}</p>\n</div></td></tr></tbody></table><table align="center" width="100%" border="0" cellPadding="0" cellSpacing="0" role="presentation" style="background-color:#F9FAFB;padding:18px 22px;border-radius:0 0 24px 24px;border:1px solid #E5E7EB;border-top:0"><tbody><tr><td><p style="font-size:12px;line-height:1.5;color:#6B7280;margin:0;text-align:center;margin-top:0;margin-bottom:0;margin-left:0;margin-right:0">{{companyFooter}}</p></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></body></html>	2	t	2026-05-03 16:26:42.051	2026-05-03 16:26:42.051
\.


--
-- Data for Name: Expense; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Expense" (id, title, name, description, amount, date, currency, "categoryId", "statusId", "paymentMethodId", "paymentReference", "taxCreditEligible", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ExpenseAttachment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ExpenseAttachment" (id, "expenseId", name, "mimeType", size, content, "createdAt") FROM stdin;
\.


--
-- Data for Name: ExpenseCategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ExpenseCategory" (id, name) FROM stdin;
\.


--
-- Data for Name: ExpenseStatus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ExpenseStatus" (id, name, color) FROM stdin;
\.


--
-- Data for Name: InboxAccount; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."InboxAccount" (id, "displayName", address, channel, active, metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: InboxAttachment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."InboxAttachment" (id, "messageId", "remoteId", "fileName", "contentType", size, metadata, "createdAt") FROM stdin;
\.


--
-- Data for Name: InboxMessage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."InboxMessage" (id, "accountId", channel, provider, "messageUid", "remoteId", "threadRemoteId", subject, snippet, "previewText", "fromAddress", "fromName", "toAddresses", "ccAddresses", "bccAddresses", "replyToAddresses", direction, folder, "queueId", "isRead", "isStarred", "isSpam", "hasAttachments", "sentAt", "receivedAt", "bodyHash", metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: InboxMessageEvent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."InboxMessageEvent" (id, "messageId", type, payload, "occurredAt") FROM stdin;
\.


--
-- Data for Name: InboxQueue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."InboxQueue" (id, slug, name, description, rules, "isActive", priority, "slaTargetMinutes", "maxAssignedConversations", "assignmentMode", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: InboxQueueUserAssignment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."InboxQueueUserAssignment" (id, "queueId", "userId", "isActive", "isPrimary", "maxOpenConversations", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: InboxSyncState; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."InboxSyncState" (id, "accountId", channel, folder, "lastRemoteId", "lastSyncAt", metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: KnowledgeCandidate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."KnowledgeCandidate" (id, "tenantKey", scope, "sourceType", status, "observationId", title, excerpt, "redactedExcerpt", summary, "detectedIntent", problem, "contextSummary", "suggestedResponse", "approvedResponse", confidence, "dedupeHash", "clusterKey", version, "piiDetected", metadata, "conversationId", "messageId", "createdByUserId", "reviewedByUserId", "reviewedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: KnowledgeConversationBundle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."KnowledgeConversationBundle" (id, "tenantKey", scope, status, "conversationId", title, summary, "detectedIntents", "eventCount", "candidateCount", "approvedCount", "pendingCount", "previewQuestion", "previewResponse", metadata, "createdByUserId", "reviewedByUserId", "reviewedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: KnowledgeDerivedArtifact; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."KnowledgeDerivedArtifact" (id, "tenantKey", scope, type, status, "sourceDocumentId", content, metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: KnowledgeDocument; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."KnowledgeDocument" (id, "tenantKey", scope, "sourceType", status, "chunkIndexStatus", "chunkIndexVersion", "chunkCount", "chunkIndexAttempts", "chunkIndexedAt", "chunkIndexRequestedAt", "chunkIndexStartedAt", "chunkIndexError", "sourceKey", title, summary, content, "sourceFileName", "sourceFilePath", "sourceFileMime", "sourceFileSize", tags, "piiRiskLevel", metadata, "authoredByUserId", "approvedByUserId", "approvedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: KnowledgeDocumentChunk; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."KnowledgeDocumentChunk" (id, "chunkKey", "tenantKey", "documentId", scope, "sourceType", "chunkIndex", "charStart", "charEnd", "charLength", content, tags, metadata, provider, model, dimensions, "contentHash", vector, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: KnowledgeDocumentEmbedding; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."KnowledgeDocumentEmbedding" (id, "documentId", provider, model, dimensions, "contentHash", vector, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: KnowledgeIngestionRun; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."KnowledgeIngestionRun" (id, "tenantKey", "sourceType", "triggerType", status, "processedCount", "createdCandidates", "skippedCount", "errorCount", metadata, "createdByUserId", "startedAt", "finishedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: KnowledgeNegativeExample; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."KnowledgeNegativeExample" (id, "tenantKey", scope, status, "sourceKind", "conversationId", "candidateId", "feedbackId", title, summary, "detectedIntent", channel, "disallowedText", "correctedText", metadata, "createdByUserId", "reviewedByUserId", "reviewedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: KnowledgeRawEvent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."KnowledgeRawEvent" (id, "tenantKey", scope, channel, "sourceAuthorType", status, "conversationId", "messageId", "userMessage", "normalizedMessage", "redactedMessage", "operatorReply", "aiReply", "detectedIntent", problem, "contextSummary", "suggestedResponse", confidence, "relevanceScore", "dedupeHash", "clusterKey", "messageElements", "messageContextOrigin", attachments, metadata, "ingestionRunId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: KnowledgeSnapshot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."KnowledgeSnapshot" (id, "tenantKey", scope, status, version, "generationReason", "summaryText", metrics, "coverageScore", metadata, "generatedByUserId", "generatedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: KnowledgeSnapshotEntry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."KnowledgeSnapshotEntry" (id, "snapshotId", "tenantKey", scope, "entryType", key, title, "plainText", "normalizedIntent", "topicKey", confidence, priority, "appliesToChannels", metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: KnowledgeSnapshotSource; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."KnowledgeSnapshotSource" (id, "snapshotEntryId", "sourceKind", "sourceId", "sourceVersion", "sourceStatus", role, excerpt, metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: KnowledgeSuggestionFeedback; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."KnowledgeSuggestionFeedback" (id, "tenantKey", "conversationId", "candidateId", "targetMessageId", "operatorMessageId", "actorUserId", outcome, "suggestedText", "finalText", metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Notification" (id, "eventType", audience, channel, "deliveryStatus", "recipientId", "customerId", "orderId", "paymentId", title, body, metadata, "idempotencyKey", "readAt", readed, target, description, type, image, location, "locationLabel", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: NotificationSetting; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."NotificationSetting" (id, "eventType", audience, channel, enabled, roles, "templateKey", "localeOverrides", "emailSubject", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Order" (id, uuid, "documentType", "customerId", date, "paymentMethodId", "shippingAddress1", "shippingAddress2", "shippingCity", "shippingDepartment", "shippingState", "shippingNeighborhood", "shippingZip", "shippingCountry", "billingAddress1", "billingAddress2", "billingCity", "billingDepartment", "billingState", "billingNeighborhood", "billingZip", "billingCountry", "billingSameAsShipping", "shippingVendor", "deliveryFees", "estimatedMin", "estimatedMax", comment, disclaimer, metadata, "statusId", "subTotal", tax, "grandTotal", "minimumDepositType", "minimumDepositValue", "confirmedAt", "depositSatisfiedAt", "customerCredit", "orderCurrency", "fxBase", "fxRates", "currencySnapshot", "taxRateSnapshot", "priceListIdSnapshot", "exchangeRateSnapshot", "validUntil", "activityId", "originId", "convertedOrderId", "convertedAt", "convertedBy", session_id, user_id, utm_source, utm_medium, utm_campaign, referrer, "documentFilePath", "documentFileName", "documentFileMime", "documentFileSize", "documentGeneratedAt", "documentPdf", version, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: OrderItem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."OrderItem" (id, "orderId", "productId", "variantId", name, price, qty, img, description, comments, "unitAmount", "unitCurrency", "unitAmountOrderCurrency", "conversionRate", "unitCostAmount", "unitCostCurrency", "unitCostOrderCurrency", "customAttributes", "pricingMethodSnapshot", "unitPriceSnapshot", "skuSnapshot", "nameSnapshot", "specSummary", "specJson", "parametricConfig", "parametricBreakdown", "parametricReferenceDate", "parametricSource", "parametricVersion") FROM stdin;
\.


--
-- Data for Name: OrderTimelineEvent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."OrderTimelineEvent" (id, "eventId", "orderId", type, "timestamp", actor, amount, currency, "paymentMethod", "remainingAmount", "estimateDate", "statusFrom", "statusTo", message, metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PasswordResetToken; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PasswordResetToken" (id, "tokenHash", "userId", "customerId", channel, "targetIdentifierHash", "signingKid", metadata, "expiresAt", "usedAt", "ipAddress", "userAgent", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Payment" (id, "orderId", "paymentMethodId", method, amount, currency, type, status, reference, date, notes, metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PaymentAttachment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PaymentAttachment" (id, "paymentId", name, "mimeType", size, content, "createdAt") FROM stdin;
\.


--
-- Data for Name: PaymentPlan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PaymentPlan" (id, "orderId", name, description, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PaymentPlanMilestone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PaymentPlanMilestone" (id, "paymentPlanId", name, "dueDate", "requirementType", value, notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Product" (id, name, "productCode", img, description, specifications, "seoTitle", "seoDescription", "seoImageUrl", "categoryId", "installationResolutionMode", "installationChargeScope", "installationPricePresentationMode", "installServiceProductId", "productType", mode, "calculationStrategy", precio_venta, precio_costo, currency, "unitOfMeasure", "isBudgetCalculable", stock, "permanentStock", status, "costPerItem", "bulkDiscountPrice", "taxRate", tags, brand, vendor, published, "createdAt", "updatedAt", "productCapabilities", "productConfigSchema") FROM stdin;
1	Cortinas Roller	cortinas-roller	/uploads/cms/legacy-assets/img/portfolio/roller/cortinas_roller_3.jpeg	Producto semilla para el flujo de presupuesto m².	\N	\N	\N	/uploads/cms/legacy-assets/img/portfolio/roller/cortinas_roller_3.jpeg	\N	\N	\N	\N	\N	PHYSICAL	SIMPLE	M2	120.00	72.00	UYU	SQUARE_METER	t	100	f	0	72	\N	22	{budget,m2}	\N	\N	t	2026-05-03 16:26:41.063	2026-05-03 16:26:41.064	\N	\N
\.


--
-- Data for Name: ProductCategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductCategory" (id, name, description, image, "seoTitle", "seoDescription", "seoImageUrl", "parentId", "installationResolutionMode", "installationChargeScope", "installationPricePresentationMode", "installServiceProductId", "catalogExposureMode") FROM stdin;
\.


--
-- Data for Name: ProductImage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductImage" (id, "productId", "variantId", name, img, "sortOrder", alt, "publicId", version, "familyKey") FROM stdin;
\.


--
-- Data for Name: ProductOption; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductOption" (id, "productId", type, name, "sortOrder", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ProductOptionValue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductOptionValue" (id, "optionId", code, label, value, "colorHex", "imageUrl", "imageAlt", "sortOrder", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ProductRelation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductRelation" (id, "productId", "relatedProductId", type, "sortOrder", "isActive", metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ProductReview; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductReview" (id, "productId", "customerId", "orderItemId", rating, title, comment, status, "verifiedPurchase", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ProductVariant; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductVariant" (id, "productId", key, sku, barcode, label, "salePrice", "costPrice", stock, "permanentStock", "isActive", "inheritSalePrice", "inheritCostPrice", "inheritStock", "inheritSku", "inheritImages", attributes, "combinationKey", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ProductVariantSelection; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductVariantSelection" ("variantId", "optionValueId") FROM stdin;
\.


--
-- Data for Name: ProductionOrder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductionOrder" (id, "workOrderId", "orderId", status, priority, "assignedToId", "scheduledAt", "startedAt", "completedAt", "deliveredAt", notes, metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Project" (id, name, code, description, "startDate", "endDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: RoleNotificationRule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RoleNotificationRule" (id, role, categories, enabled, "createdAt", "updatedAt") FROM stdin;
1	ADMIN	{ORDERS,PAYMENTS,AUTH}	t	2026-05-03 16:26:41.069	2026-05-03 16:26:41.069
\.


--
-- Data for Name: SecureConfig; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SecureConfig" (key, value, "createdAt", "updatedAt") FROM stdin;
integrations.google	UCIdL8OZm4KoioViZyP8n4J7XZlx3fqBxdZJQTn7MyAIiV8N0cklKmMbQMsitj1IlPwK/uPb482aY7iMVoMS6RR51wuj0OBD1OcawvdJ1oZ2KUXBBPxC02dG692kO0oOu/E0kl1QQA7vKS3rFNHrIh7bfydp7PFoFC5Aj262efKYNqHyW2re43AEgbtOhyn+nqixUjIysYpDQaxVR9vJgfB98gFQbg9Pf85Nc5ekBx3WVViEf9wdchemCb4FHFdy4xzDEBvIf72RaXIcXaEgoDIAThFdXEvxexYEwkZr3Gb/CTBNT1mpQG/9kYAOJWOh0ClepswF7345SD/ZxdrwnGMCZ7XLLInZ1tgMSmpvjB/UdHoWblF42C1fyurqodp9ZjLUua6cqqn5cvjS6NNwYItMOBuUquPOB7GBjoOC37fUP1qpe2g1fHgUfSZPwQb+fKXHHODXJdaGeEYu4g6eEoF2Lsfh5S/gPMTFfneNC369OyWvKJWLvT76rZjYp7L4Tq8ahQ==	2026-05-03 16:26:40.592	2026-05-03 16:26:40.592
email.provider.config	l7Jp1UrUh1WtxyCRPm6VItkAKbPhuTEVcRGfXybW+24MAU0jypAs0UpbMjXoENaKsZWGS5bGDHV/ImXe6zxgFddxoYGNPmu4LmvGRnSsfItZn2ATkf79FjT8YNpbDNrzMWRYWhdryTMeOxO0cWUeKK0aNc8UvHiPLos4NGmQGAjKMK5YyGk8SDrWelM+12bb9TrexkylsK5Jlj9p6WMH3eFCFO71g/kjg+ViIcg10CdzYyt/nMiEm21/e3PaJiCM0oaI7jBP8jz7RKlhArGllGkyViZk	2026-05-03 16:26:40.593	2026-05-03 16:26:40.593
\.


--
-- Data for Name: Setting; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Setting" (id, key, value, environment, "createdAt", "updatedAt") FROM stdin;
1	app.environment	{"clientSlug": "urucortinas", "environment": "production"}	production	2026-05-03 16:26:40.577	2026-05-03 16:26:40.577
2	currency.default	{"code": "UYU"}	production	2026-05-03 16:26:40.579	2026-05-03 16:26:40.579
3	currency.supported	{"codes": ["USD", "UYU"]}	production	2026-05-03 16:26:40.58	2026-05-03 16:26:40.58
4	checkout.tax	{"rate": 22, "currency": "UYU"}	production	2026-05-03 16:26:40.582	2026-05-03 16:26:40.582
5	auth.session	{"ttlHours": 168, "cookieDomain": null, "cookieSecure": true, "cookieSameSite": "lax"}	production	2026-05-03 16:26:40.583	2026-05-03 16:26:40.583
6	security.cors	{"allowedOrigins": "http://localhost:8080", "defaultAllowedOrigins": "http://localhost:8080"}	production	2026-05-03 16:26:40.584	2026-05-03 16:26:40.584
7	storefront.resilience	{"snapshotFallbackEnabled": false}	production	2026-05-03 16:26:40.585	2026-05-03 16:26:40.585
8	notifications.defaults	{"emailFromName": "Sistema Administrativo", "emailFromAddress": "no-reply@example.com"}	production	2026-05-03 16:26:40.586	2026-05-03 16:26:40.586
9	email.provider	{"fromName": "Sistema Administrativo", "provider": "DEV", "fromAddress": "no-reply@example.com"}	production	2026-05-03 16:26:40.594	2026-05-03 16:26:40.594
10	payments.provider	{"country": "AR", "provider": "mercadopago", "timeoutMs": 12000}	production	2026-05-03 16:26:40.595	2026-05-03 16:26:40.595
11	storefront.localization	{"siteUrl": "http://localhost:8080", "clientSlug": "urucortinas"}	production	2026-05-03 16:26:40.596	2026-05-03 16:26:40.596
12	feature.flags	{"demoSeedEnabled": false, "recaptchaEnabled": false, "googleOauthEnabled": false, "adminRecaptchaEnabled": false, "storefrontRecaptchaEnabled": false}	production	2026-05-03 16:26:40.597	2026-05-03 16:26:40.597
13	notifications.email.categories	{"categories": ["ORDERS", "PAYMENTS", "AUTH"]}	production	2026-05-03 16:26:40.597	2026-05-03 16:26:40.597
14	auth.bootstrap	{"tempPasswordConfigured": true, "storefrontGenericCustomerPasswordConfigured": true}	production	2026-05-03 16:26:40.598	2026-05-03 16:26:40.598
\.


--
-- Data for Name: ShippingOption; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ShippingOption" (id, name, "deliveryFees", "estimatedMin", "estimatedMax", img, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: StandardSize; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."StandardSize" (id, width, height, label, "isActive", "sortOrder", "createdAt", "updatedAt") FROM stdin;
1	0.8000	1.0000	0.80 x 1.00	t	0	2026-05-03 16:26:40.6	2026-05-03 16:26:40.6
2	1.0000	1.0000	1.00 x 1.00	t	1	2026-05-03 16:26:40.601	2026-05-03 16:26:40.601
3	1.0000	1.2000	1.00 x 1.20	t	2	2026-05-03 16:26:40.601	2026-05-03 16:26:40.601
4	1.0000	1.5000	1.00 x 1.50	t	3	2026-05-03 16:26:40.602	2026-05-03 16:26:40.602
5	1.2000	1.0000	1.20 x 1.00	t	4	2026-05-03 16:26:40.602	2026-05-03 16:26:40.602
6	1.2000	1.2000	1.20 x 1.20	t	5	2026-05-03 16:26:40.602	2026-05-03 16:26:40.602
7	1.2000	1.5000	1.20 x 1.50	t	6	2026-05-03 16:26:40.603	2026-05-03 16:26:40.603
8	1.2000	2.0000	1.20 x 2.00	t	7	2026-05-03 16:26:40.603	2026-05-03 16:26:40.603
9	1.5000	1.0000	1.50 x 1.00	t	8	2026-05-03 16:26:40.604	2026-05-03 16:26:40.604
10	1.5000	1.2000	1.50 x 1.20	t	9	2026-05-03 16:26:40.604	2026-05-03 16:26:40.604
11	1.5000	1.5000	1.50 x 1.50	t	10	2026-05-03 16:26:40.604	2026-05-03 16:26:40.604
12	1.5000	2.0000	1.50 x 2.00	t	11	2026-05-03 16:26:40.605	2026-05-03 16:26:40.605
13	1.8000	1.0000	1.80 x 1.00	t	12	2026-05-03 16:26:40.605	2026-05-03 16:26:40.605
14	1.8000	1.2000	1.80 x 1.20	t	13	2026-05-03 16:26:40.605	2026-05-03 16:26:40.605
15	1.8000	1.5000	1.80 x 1.50	t	14	2026-05-03 16:26:40.606	2026-05-03 16:26:40.606
16	1.8000	2.0000	1.80 x 2.00	t	15	2026-05-03 16:26:40.606	2026-05-03 16:26:40.606
17	2.0000	1.2000	2.00 x 1.20	t	16	2026-05-03 16:26:40.606	2026-05-03 16:26:40.606
18	2.0000	1.5000	2.00 x 1.50	t	17	2026-05-03 16:26:40.607	2026-05-03 16:26:40.607
19	2.0000	2.0000	2.00 x 2.00	t	18	2026-05-03 16:26:40.607	2026-05-03 16:26:40.607
\.


--
-- Data for Name: StorefrontOAuthSession; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."StorefrontOAuthSession" (id, provider, state, "codeVerifier", nonce, "redirectUri", "returnPath", purpose, "expectedCustomerId", scopes, "ipAddress", "userAgent", "createdAt", "expiresAt", "completedAt", "errorCode", "errorMessage") FROM stdin;
\.


--
-- Data for Name: StorefrontPaymentIntent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."StorefrontPaymentIntent" (id, provider, "externalPaymentId", status, "statusDetail", amount, currency, installments, "paymentMethodId", "paymentTypeId", "cardBrand", "cardLastFour", "cardholderName", "statementDescriptor", description, "cartId", "orderId", "payerEmail", "payerIdentificationType", "payerIdentificationNumber", "payerFirstName", "payerLastName", "riskLevel", "fraudStatus", "captureMethod", "paymentMethodType", metadata, "rawResponse", "rawError", "idempotencyKey", "requestId", "liveMode", "refundsRaw", "processedAt", "statusUpdatedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Story; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Story" (id, slug, title, "coverPublicId", "isActive", "startsAt", "endsAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: StoryItem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."StoryItem" (id, "storyId", "order", type, "publicId", duration, "ctaLabel", "ctaUrl", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: SystemConfig; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SystemConfig" (key, value) FROM stdin;
taxRate	22
currencyBase	UYU
currencies	["USD","UYU"]
themeConfig	{"themeColor":"indigo","direction":"ltr","mode":"light","primaryColorLevel":600,"panelExpand":false,"navMode":"light","cardBordered":true,"layout":{"type":"modern","sideNavCollapse":false}}
storefront:snapshotFallbackEnabled	false
storefront:config	{"defaultLayout":"classic-showcase","layouts":[{"key":"classic-showcase","name":"Classic showcase","description":"Hero, featured products, category spotlight, and testimonials.","modules":[{"id":"classic-hero","type":"hero","title":"Discover the new season","subtitle":"Premium quality products curated for everyday comfort.","description":"Enjoy free shipping over $150 and complimentary returns within 30 days.","emphasis":"left","ctas":[{"id":"cta-shop-now","label":"Shop now","href":"/products"},{"id":"cta-view-lookbook","label":"View lookbook","href":"/collections/lookbook"}]},{"id":"classic-usps","type":"usp-strip","title":"Why customers choose us","items":[{"id":"usp-shipping","icon":"Truck","title":"Fast shipping","description":"2-day express delivery on most orders"},{"id":"usp-quality","icon":"ShieldCheck","title":"Premium quality","description":"Carefully sourced materials"},{"id":"usp-support","icon":"Headset","title":"24/7 support","description":"Dedicated concierge assistance"},{"id":"usp-payment","icon":"CreditCard","title":"Secure checkout","description":"Multiple payment providers"}]},{"id":"classic-featured","type":"product-grid","title":"New arrivals","subtitle":"Weekly updates from our top designers","layout":"grid","columns":4,"limit":8,"showQuickAdd":true,"showRating":true,"filter":{"featured":true}},{"id":"classic-categories","type":"category-grid","title":"Shop by category","subtitle":"Find the right products tailored to your needs","layout":"grid","limit":6,"emphasizeFeatured":true},{"id":"classic-testimonials","type":"testimonial","title":"Loved by thousands of customers","layout":"carousel","testimonials":[{"id":"testimonial-1","quote":"The quality is outstanding. Shipping was fast and the packaging felt luxurious.","author":"Camila Rivera","role":"Verified buyer","rating":5},{"id":"testimonial-2","quote":"Configuring the layouts from the dashboard is incredibly flexible. Our marketing team loves it.","author":"Daniel Thompson","role":"Head of eCommerce","rating":5},{"id":"testimonial-3","quote":"This storefront is blazing fast and easy to customize.","author":"Lauren Chen","role":"Brand manager","rating":4.5}]},{"id":"classic-newsletter","type":"newsletter","title":"Stay in the know","description":"Be the first to hear about new launches, restocks, and private events.","placeholder":"you@example.com","consentMessage":"We respect your privacy and only send relevant updates."}],"isDefault":true},{"key":"editorial-fashion","name":"Editorial fashion","description":"Story-driven layout with product carousel and journal posts.","modules":[{"id":"editorial-hero","type":"hero","title":"Discover the new season","subtitle":"Effortless silhouettes with a modern touch","description":"Enjoy free shipping over $150 and complimentary returns within 30 days.","emphasis":"left","ctas":[{"id":"editorial-shop","label":"Explore collection","href":"/collections/editorial"},{"id":"editorial-story","label":"Read the story","href":"/blog/editorial-season"}]},{"id":"editorial-trending","type":"product-carousel","title":"Curator picks","subtitle":"Curated by our community","layout":"carousel","limit":12,"showQuickAdd":true,"showRating":true,"filter":{"tag":"trending"}},{"id":"editorial-banner","type":"banner","title":"Limited edition drop","subtitle":"Available for 72 hours only","description":"Members enjoy exclusive perks and early access to new drops.","ctas":[{"id":"banner-sale","label":"Redeem offer","href":"/collections/sale"}]},{"id":"editorial-blog","type":"blog-teaser","title":"From the Journal","subtitle":"Stories, interviews, and product highlights","limit":3,"layout":"grid","highlightFirst":true},{"id":"editorial-newsletter","type":"newsletter","title":"Stay in the know","description":"Be the first to hear about new launches, restocks, and private events.","placeholder":"you@example.com","consentMessage":"We respect your privacy and only send relevant updates."}]},{"key":"premium-lifestyle","name":"Premium lifestyle","description":"Balanced modules for lifestyle brands focusing on benefits.","modules":[{"id":"lifestyle-hero","type":"hero","title":"Discover the new season","subtitle":"Luxury essentials for every moment","description":"Enjoy free shipping over $150 and complimentary returns within 30 days.","emphasis":"center","ctas":[{"id":"cta-shop-now","label":"Shop now","href":"/products"},{"id":"cta-view-lookbook","label":"View lookbook","href":"/collections/lookbook"}]},{"id":"lifestyle-features","type":"usp-strip","title":"Signature experience","items":[{"id":"usp-shipping","icon":"Truck","title":"Fast shipping","description":"2-day express delivery on most orders"},{"id":"usp-quality","icon":"ShieldCheck","title":"Premium quality","description":"Carefully sourced materials"},{"id":"usp-support","icon":"Headset","title":"24/7 support","description":"Dedicated concierge assistance"},{"id":"usp-payment","icon":"CreditCard","title":"Secure checkout","description":"Multiple payment providers"}]},{"id":"lifestyle-featured","type":"product-grid","title":"Signature pieces","subtitle":"Weekly updates from our top designers","layout":"grid","columns":4,"limit":8,"showQuickAdd":true,"showRating":true,"filter":{"featured":true}},{"id":"lifestyle-banner","type":"banner","title":"Member-exclusive rewards","subtitle":"Earn points on every purchase","description":"Members enjoy exclusive perks and early access to new drops.","ctas":[{"id":"banner-sale","label":"Redeem offer","href":"/collections/sale"}]},{"id":"lifestyle-testimonials","type":"testimonial","title":"Customer stories","layout":"carousel","testimonials":[{"id":"testimonial-1","quote":"The quality is outstanding. Shipping was fast and the packaging felt luxurious.","author":"Camila Rivera","role":"Verified buyer","rating":5},{"id":"testimonial-2","quote":"Configuring the layouts from the dashboard is incredibly flexible. Our marketing team loves it.","author":"Daniel Thompson","role":"Head of eCommerce","rating":5},{"id":"testimonial-3","quote":"This storefront is blazing fast and easy to customize.","author":"Lauren Chen","role":"Brand manager","rating":4.5}]}]},{"key":"modern-electronics","name":"Modern electronics","description":"Tech-focused layout with product recommendations and stats.","modules":[{"id":"electronics-hero","type":"hero","title":"Discover the new season","subtitle":"Smart devices engineered for performance","description":"Enjoy free shipping over $150 and complimentary returns within 30 days.","emphasis":"left","ctas":[{"id":"cta-shop-now","label":"Shop now","href":"/products"},{"id":"cta-view-lookbook","label":"View lookbook","href":"/collections/lookbook"}]},{"id":"electronics-top-rated","type":"product-carousel","title":"Top-rated tech","subtitle":"Curated by our community","layout":"carousel","limit":12,"showQuickAdd":true,"showRating":true,"filter":{"tag":"trending"}},{"id":"electronics-usps","type":"usp-strip","title":"Why customers choose us","items":[{"id":"usp-support-365","icon":"Headset","title":"365-day support","description":"Certified technicians on call"},{"id":"usp-warranty","icon":"Shield","title":"Extended warranty","description":"Coverage up to 3 years"},{"id":"usp-energy","icon":"Zap","title":"Energy efficient","description":"Designed with sustainability in mind"}]},{"id":"electronics-banner","type":"banner","title":"Bundle & save","subtitle":"Build your smart ecosystem and save 15%","description":"Members enjoy exclusive perks and early access to new drops.","ctas":[{"id":"banner-sale","label":"Redeem offer","href":"/collections/sale"}]},{"id":"electronics-recommendations","type":"product-grid","title":"Recommended for you","subtitle":"Weekly updates from our top designers","layout":"grid","columns":4,"limit":8,"showQuickAdd":true,"showRating":true,"filter":{"tag":"recommended"}},{"id":"electronics-newsletter","type":"newsletter","title":"Stay in the know","description":"Be the first to hear about new launches, restocks, and private events.","placeholder":"you@example.com","consentMessage":"We respect your privacy and only send relevant updates."}]},{"key":"home-decor","name":"Home & decor","description":"Warm storytelling with category highlights and blog content.","modules":[{"id":"decor-hero","type":"hero","title":"Discover the new season","subtitle":"Thoughtfully crafted pieces to elevate every space","description":"Enjoy free shipping over $150 and complimentary returns within 30 days.","emphasis":"left","ctas":[{"id":"cta-shop-now","label":"Shop now","href":"/products"},{"id":"cta-view-lookbook","label":"View lookbook","href":"/collections/lookbook"}]},{"id":"decor-categories","type":"category-grid","title":"Curated rooms","subtitle":"Find the right products tailored to your needs","layout":"grid","limit":6,"emphasizeFeatured":true},{"id":"decor-banner","type":"banner","title":"Interior styling services","subtitle":"Complimentary consultation with every purchase","description":"Members enjoy exclusive perks and early access to new drops.","ctas":[{"id":"banner-sale","label":"Redeem offer","href":"/collections/sale"}]},{"id":"decor-featured","type":"product-grid","title":"Handpicked favorites","subtitle":"Weekly updates from our top designers","layout":"grid","columns":4,"limit":8,"showQuickAdd":true,"showRating":true,"filter":{"featured":true}},{"id":"decor-stories","type":"blog-teaser","title":"Design notes","subtitle":"Stories, interviews, and product highlights","limit":3,"layout":"grid","highlightFirst":true}]},{"key":"beauty-wellness","name":"Beauty & wellness","description":"Focus on testimonials, routines, and featured bundles.","modules":[{"id":"beauty-hero","type":"hero","title":"Discover the new season","subtitle":"Clean formulations backed by clinical research","description":"Enjoy free shipping over $150 and complimentary returns within 30 days.","emphasis":"left","ctas":[{"id":"cta-shop-now","label":"Shop now","href":"/products"},{"id":"cta-view-lookbook","label":"View lookbook","href":"/collections/lookbook"}]},{"id":"beauty-usps","type":"usp-strip","title":"Why customers choose us","items":[{"id":"usp-ingredients","icon":"Leaf","title":"Clinically tested","description":"Dermatologist approved formulas"},{"id":"usp-crueltyfree","icon":"Heart","title":"Cruelty free","description":"No animal testing, ever"},{"id":"usp-subscription","icon":"Repeat","title":"Auto-replenish","description":"Flexible delivery schedules"}]},{"id":"beauty-best-sellers","type":"product-carousel","title":"Best sellers","subtitle":"Curated by our community","layout":"carousel","limit":12,"showQuickAdd":true,"showRating":true,"filter":{"tag":"trending"}},{"id":"beauty-testimonials","type":"testimonial","title":"Real results","layout":"carousel","testimonials":[{"id":"testimonial-1","quote":"The quality is outstanding. Shipping was fast and the packaging felt luxurious.","author":"Camila Rivera","role":"Verified buyer","rating":5},{"id":"testimonial-2","quote":"Configuring the layouts from the dashboard is incredibly flexible. Our marketing team loves it.","author":"Daniel Thompson","role":"Head of eCommerce","rating":5},{"id":"testimonial-3","quote":"This storefront is blazing fast and easy to customize.","author":"Lauren Chen","role":"Brand manager","rating":4.5}]},{"id":"beauty-newsletter","type":"newsletter","title":"Get personalized routines","description":"Be the first to hear about new launches, restocks, and private events.","placeholder":"you@example.com","consentMessage":"We respect your privacy and only send relevant updates."}]},{"key":"outdoor-adventure","name":"Outdoor adventure","description":"Storytelling focused on exploration with collection highlights.","modules":[{"id":"outdoor-hero","type":"hero","title":"Discover the new season","subtitle":"Gear built to go the distance","description":"Enjoy free shipping over $150 and complimentary returns within 30 days.","emphasis":"center","ctas":[{"id":"cta-shop-now","label":"Shop now","href":"/products"},{"id":"cta-view-lookbook","label":"View lookbook","href":"/collections/lookbook"}]},{"id":"outdoor-trending","type":"product-carousel","title":"Trail-tested picks","subtitle":"Curated by our community","layout":"carousel","limit":12,"showQuickAdd":true,"showRating":true,"filter":{"tag":"trending"}},{"id":"outdoor-banner","type":"banner","title":"Adventure guarantee","subtitle":"Lifetime repairs on all technical gear","description":"Members enjoy exclusive perks and early access to new drops.","ctas":[{"id":"banner-sale","label":"Redeem offer","href":"/collections/sale"}]},{"id":"outdoor-collections","type":"category-grid","title":"Featured collections","subtitle":"Find the right products tailored to your needs","layout":"grid","limit":6,"emphasizeFeatured":true},{"id":"outdoor-testimonials","type":"testimonial","title":"Field notes","layout":"carousel","testimonials":[{"id":"testimonial-1","quote":"The quality is outstanding. Shipping was fast and the packaging felt luxurious.","author":"Camila Rivera","role":"Verified buyer","rating":5},{"id":"testimonial-2","quote":"Configuring the layouts from the dashboard is incredibly flexible. Our marketing team loves it.","author":"Daniel Thompson","role":"Head of eCommerce","rating":5},{"id":"testimonial-3","quote":"This storefront is blazing fast and easy to customize.","author":"Lauren Chen","role":"Brand manager","rating":4.5}]}]},{"key":"minimal-digital","name":"Minimal digital","description":"Clean layout optimized for DTC digital products and SaaS.","modules":[{"id":"digital-hero","type":"hero","title":"Discover the new season","subtitle":"Design assets and tools crafted for creative teams","description":"Enjoy free shipping over $150 and complimentary returns within 30 days.","emphasis":"left","ctas":[{"id":"cta-shop-now","label":"Shop now","href":"/products"},{"id":"cta-view-lookbook","label":"View lookbook","href":"/collections/lookbook"}]},{"id":"digital-usps","type":"usp-strip","title":"Why customers choose us","items":[{"id":"usp-license","icon":"FileCheck","title":"Flexible licenses","description":"Enterprise-ready usage rights"},{"id":"usp-updates","icon":"RefreshCcw","title":"Rolling updates","description":"New drops every month"},{"id":"usp-support","icon":"MessageCircle","title":"Priority support","description":"Dedicated Slack channel"}]},{"id":"digital-featured","type":"product-grid","title":"Featured kits","subtitle":"Weekly updates from our top designers","layout":"grid","columns":4,"limit":8,"showQuickAdd":true,"showRating":true,"filter":{"featured":true}},{"id":"digital-blog","type":"blog-teaser","title":"Workflow insights","subtitle":"Stories, interviews, and product highlights","limit":3,"layout":"grid","highlightFirst":true},{"id":"digital-newsletter","type":"newsletter","title":"Access private beta releases","description":"Be the first to hear about new launches, restocks, and private events.","placeholder":"you@example.com","consentMessage":"We respect your privacy and only send relevant updates."}]},{"key":"kids-lifestyle","name":"Kids lifestyle","description":"Playful layout highlighting collections and parent stories.","modules":[{"id":"kids-hero","type":"hero","title":"Discover the new season","subtitle":"Playful essentials made to grow with them","description":"Enjoy free shipping over $150 and complimentary returns within 30 days.","emphasis":"left","ctas":[{"id":"cta-shop-now","label":"Shop now","href":"/products"},{"id":"cta-view-lookbook","label":"View lookbook","href":"/collections/lookbook"}]},{"id":"kids-categories","type":"category-grid","title":"Shop by age","subtitle":"Find the right products tailored to your needs","layout":"grid","limit":6,"emphasizeFeatured":true},{"id":"kids-banner","type":"banner","title":"Bundle deals","subtitle":"Outfit bundles from newborn to pre-teen","description":"Members enjoy exclusive perks and early access to new drops.","ctas":[{"id":"banner-sale","label":"Redeem offer","href":"/collections/sale"}]},{"id":"kids-favorites","type":"product-carousel","title":"Parent favorites","subtitle":"Curated by our community","layout":"carousel","limit":12,"showQuickAdd":true,"showRating":true,"filter":{"tag":"trending"}},{"id":"kids-testimonials","type":"testimonial","title":"Parent stories","layout":"carousel","testimonials":[{"id":"testimonial-1","quote":"The quality is outstanding. Shipping was fast and the packaging felt luxurious.","author":"Camila Rivera","role":"Verified buyer","rating":5},{"id":"testimonial-2","quote":"Configuring the layouts from the dashboard is incredibly flexible. Our marketing team loves it.","author":"Daniel Thompson","role":"Head of eCommerce","rating":5},{"id":"testimonial-3","quote":"This storefront is blazing fast and easy to customize.","author":"Lauren Chen","role":"Brand manager","rating":4.5}]},{"id":"kids-newsletter","type":"newsletter","title":"Parenting notes & releases","description":"Be the first to hear about new launches, restocks, and private events.","placeholder":"you@example.com","consentMessage":"We respect your privacy and only send relevant updates."}]},{"key":"gourmet-market","name":"Gourmet market","description":"Highlight curated collections, featured recipes, and testimonials.","modules":[{"id":"gourmet-hero","type":"hero","title":"Discover the new season","subtitle":"Small-batch producers and chef-curated pairings","description":"Enjoy free shipping over $150 and complimentary returns within 30 days.","emphasis":"left","ctas":[{"id":"cta-shop-now","label":"Shop now","href":"/products"},{"id":"cta-view-lookbook","label":"View lookbook","href":"/collections/lookbook"}]},{"id":"gourmet-featured","type":"product-grid","title":"Weekly tasting box","subtitle":"Weekly updates from our top designers","layout":"grid","columns":4,"limit":8,"showQuickAdd":true,"showRating":true,"filter":{"featured":true}},{"id":"gourmet-banner","type":"banner","title":"Chef masterclasses","subtitle":"Complimentary with seasonal subscriptions","description":"Members enjoy exclusive perks and early access to new drops.","ctas":[{"id":"banner-sale","label":"Redeem offer","href":"/collections/sale"}]},{"id":"gourmet-blog","type":"blog-teaser","title":"In the kitchen","subtitle":"Stories, interviews, and product highlights","limit":3,"layout":"grid","highlightFirst":true},{"id":"gourmet-testimonials","type":"testimonial","title":"Community favorites","layout":"carousel","testimonials":[{"id":"testimonial-1","quote":"The quality is outstanding. Shipping was fast and the packaging felt luxurious.","author":"Camila Rivera","role":"Verified buyer","rating":5},{"id":"testimonial-2","quote":"Configuring the layouts from the dashboard is incredibly flexible. Our marketing team loves it.","author":"Daniel Thompson","role":"Head of eCommerce","rating":5},{"id":"testimonial-3","quote":"This storefront is blazing fast and easy to customize.","author":"Lauren Chen","role":"Brand manager","rating":4.5}]},{"id":"gourmet-newsletter","type":"newsletter","title":"Exclusive recipes & launches","description":"Be the first to hear about new launches, restocks, and private events.","placeholder":"you@example.com","consentMessage":"We respect your privacy and only send relevant updates."}]},{"key":"fitness-performance","name":"Fitness performance","description":"Performance-driven layout with stats and product carousels.","modules":[{"id":"fitness-hero","type":"hero","title":"Discover the new season","subtitle":"Engineered for high-performance training","description":"Enjoy free shipping over $150 and complimentary returns within 30 days.","emphasis":"left","ctas":[{"id":"cta-shop-now","label":"Shop now","href":"/products"},{"id":"cta-view-lookbook","label":"View lookbook","href":"/collections/lookbook"}]},{"id":"fitness-featured","type":"product-carousel","title":"Performance essentials","subtitle":"Curated by our community","layout":"carousel","limit":12,"showQuickAdd":true,"showRating":true,"filter":{"tag":"trending"}},{"id":"fitness-usps","type":"usp-strip","title":"Why customers choose us","items":[{"id":"usp-moisture","icon":"Droplet","title":"Moisture wicking","description":"Keeps you dry under pressure"},{"id":"usp-compression","icon":"Activity","title":"Compression support","description":"Enhances muscle recovery"},{"id":"usp-eco","icon":"Recycle","title":"Sustainable fabrics","description":"Made with recycled fibers"}]},{"id":"fitness-banner","type":"banner","title":"Join the performance club","subtitle":"Earn perks with every milestone","description":"Members enjoy exclusive perks and early access to new drops.","ctas":[{"id":"banner-sale","label":"Redeem offer","href":"/collections/sale"}]},{"id":"fitness-testimonials","type":"testimonial","title":"Athlete reviews","layout":"carousel","testimonials":[{"id":"testimonial-1","quote":"The quality is outstanding. Shipping was fast and the packaging felt luxurious.","author":"Camila Rivera","role":"Verified buyer","rating":5},{"id":"testimonial-2","quote":"Configuring the layouts from the dashboard is incredibly flexible. Our marketing team loves it.","author":"Daniel Thompson","role":"Head of eCommerce","rating":5},{"id":"testimonial-3","quote":"This storefront is blazing fast and easy to customize.","author":"Lauren Chen","role":"Brand manager","rating":4.5}]}]},{"key":"artisanal-maker","name":"Artisanal maker","description":"Focus on maker stories, handcrafted goods, and category highlights.","modules":[{"id":"artisan-hero","type":"hero","title":"Discover the new season","subtitle":"Handcrafted pieces from independent makers","description":"Enjoy free shipping over $150 and complimentary returns within 30 days.","emphasis":"left","ctas":[{"id":"cta-shop-now","label":"Shop now","href":"/products"},{"id":"cta-view-lookbook","label":"View lookbook","href":"/collections/lookbook"}]},{"id":"artisan-story","type":"story-highlight","title":"Meet the makers","story":{"heading":"Craftsmanship rooted in tradition","body":"Each piece is created in small batches, celebrating heritage techniques passed down through generations.","author":"Lucía Fernández","role":"Master artisan"}},{"id":"artisan-categories","type":"category-grid","title":"Explore collections","subtitle":"Find the right products tailored to your needs","layout":"grid","limit":6,"emphasizeFeatured":true},{"id":"artisan-featured","type":"product-grid","title":"Limited editions","subtitle":"Weekly updates from our top designers","layout":"grid","columns":4,"limit":8,"showQuickAdd":true,"showRating":true,"filter":{"featured":true}},{"id":"artisan-newsletter","type":"newsletter","title":"Studio updates","description":"Be the first to hear about new launches, restocks, and private events.","placeholder":"you@example.com","consentMessage":"We respect your privacy and only send relevant updates."}]}],"navigation":{"primary":[{"id":"nav-home","label":"Inicio","href":"/"},{"id":"nav-shop","label":"Tienda","href":"/shop"},{"id":"nav-categories","label":"Categorías","href":"/categories"},{"id":"nav-about","label":"Quiénes somos","href":"/quienes-somos"},{"id":"nav-faq","label":"Preguntas frecuentes","href":"/preguntas-frecuentes"},{"id":"nav-contact","label":"Contacto","href":"/contacto"}],"secondary":[{"id":"nav-account","label":"Account","href":"/account"},{"id":"nav-orders","label":"Order tracking","href":"/account/orders"}],"footer":[[{"id":"footer-about","label":"Quiénes somos","href":"/quienes-somos"},{"id":"footer-contact","label":"Contacto","href":"/contacto"},{"id":"footer-faq","label":"Preguntas frecuentes","href":"/preguntas-frecuentes"}]],"socials":[{"id":"social-instagram","label":"Instagram","href":"https://instagram.com","external":true},{"id":"social-pinterest","label":"Pinterest","href":"https://pinterest.com","external":true},{"id":"social-youtube","label":"YouTube","href":"https://youtube.com","external":true}]},"theme":{"accentColor":"#111827","accentContrastColor":"#ffffff","backgroundColor":"#f8fafc","surfaceColor":"#ffffff","textColor":"#0f172a","mutedTextColor":"#475569","borderColor":"#e2e8f0","radius":{"sm":"0.375rem","md":"0.75rem","lg":"1rem"},"fonts":{"heading":"var(--font-geist-sans)","body":"var(--font-geist-sans)"}},"seo":{"siteName":"Storefront","defaultTitle":"Storefront","titleTemplate":"%s · Storefront","defaultDescription":"Headless ecommerce storefront with CMS-managed content.","shareImage":null},"policies":[],"announcement":null,"companyProfile":{"legalName":null,"tradeName":null,"taxId":null,"email":null,"phone":null,"website":null,"addressLine1":null,"addressLine2":null,"seoDescription":null,"seoAuthor":null,"seoImageUrl":null,"googleSiteVerification":null,"logo":null},"resilience":{"snapshotFallbackEnabled":true}}
\.


--
-- Data for Name: Task; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Task" (id, code, subject, description, priority, status, "projectId", "createdById", "dueDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: TaskAssignee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TaskAssignee" ("taskId", "userId") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, name, "lastName", email, img, role, "capabilityGroups", "directCapabilities", lang, country, "countryCode", city, "passwordHash", "createdAt", "updatedAt", phone, status) FROM stdin;
1	Local Admin	\N	admin@local.test		SUPERADMIN	{}	{}	en	\N	\N	\N	$2b$12$EMqdjbQJteEmDUB3BO2Oj.fOec1uu9Bdf0bmauTWHTQFNGRn1K05u	2026-05-03 16:26:41.056	2026-05-03 16:26:41.056	\N	ACTIVE
\.


--
-- Data for Name: UserActivity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."UserActivity" (id, "userId", type, description, metadata, "ipAddress", "userAgent", "deviceId", "performedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: UserDevice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."UserDevice" (id, "userId", fingerprint, "displayName", "userAgent", location, "lastIpAddress", "deviceType", "firstSeenAt", "lastSeenAt") FROM stdin;
\.


--
-- Data for Name: Wishlist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Wishlist" (id, "customerId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: WishlistItem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WishlistItem" (id, "wishlistId", "productId", "createdAt") FROM stdin;
\.


--
-- Data for Name: WorkOrder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WorkOrder" (id, "orderId", code, status, "issuedAt", "startedAt", "completedAt", "deliveredAt", "closedAt", notes, metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
0aa34d78-dcf4-4dac-a4a0-3a4975d127a6	a6f724f2d555d0c50e5867609e9da771ee1f840aff43e0c4b16bbde038c3d7ee	2026-05-03 16:26:39.444936+00	20260429122000_analytics_pipeline_hardening	\N	\N	2026-05-03 16:26:39.443525+00	1
5194f859-9ca0-4519-b42f-699065772354	725fc838f66b526c02dd6925cf524a6ebe7dc223b6fa50872c08276f3a70e2b9	2026-05-03 16:26:39.369188+00	20260428170000_consolidated_baseline	\N	\N	2026-05-03 16:26:38.953632+00	1
016d3e47-3f89-4753-adf9-3ec9a41f88ef	00cee1a692959f5be100f931916ddbd9d17b995356fa402041b46bd67a04b6f6	2026-05-03 16:26:39.396548+00	20260428193000_analytics_connectors_ai	\N	\N	2026-05-03 16:26:39.369585+00	1
d1ffb9ff-420e-42f8-8057-2f4ad3e8ae9f	9cb4064bb3f52f2b6e0148adad22e0a7c6b7d660b2d80c06583d564ac228eb65	2026-05-03 16:26:39.49152+00	20260429201000_analytics_production_validation	\N	\N	2026-05-03 16:26:39.480472+00	1
068ae7e3-4fea-4239-bb7f-90b7863d998e	7aa3aa4f72ca7799198154c08286170c4955c5bff9cf28f4e797839b674d987d	2026-05-03 16:26:39.399186+00	20260428195500_analytics_ga4_initial_sync_fields	\N	\N	2026-05-03 16:26:39.396796+00	1
fe1a31eb-efcf-42c0-8be6-1efbc3a8c73e	a3a87f62d5bf62f0fd83b81db45a43ba0a9d34360699af7834e0aebd7db1beab	2026-05-03 16:26:39.450501+00	20260429150000_analytics_health_checks	\N	\N	2026-05-03 16:26:39.445136+00	1
f6b3fbd8-c9ae-412c-9393-e723ad342166	91f68d5e54ca8946b8ef2920ae959d52788d3791b219cfc48e80e14e63a8f050	2026-05-03 16:26:39.400471+00	20260428197500_analytics_ga4_health_retry_semantics	\N	\N	2026-05-03 16:26:39.399408+00	1
1c37e2ea-c27c-4a64-bdb3-0e5592d05223	543c537ecce9a0419d58b10cbfede810f8197a2977875a9af80fd8927882e142	2026-05-03 16:26:39.412184+00	20260428200000_ga4_report_parity	\N	\N	2026-05-03 16:26:39.400769+00	1
7e323047-7a1c-4885-a3e6-05979bde6cad	75ea7490c94e50280e60e2dc6e6ed429f8983b78eed35fc14b96de4588cadc86	2026-05-03 16:26:39.413264+00	20260428220000_analytics_ads_conversion_value	\N	\N	2026-05-03 16:26:39.412411+00	1
7c0f0a32-2c11-4960-a8cc-575bb5441551	303f95539348bbf249671ad55d9f9ac3512b703bdc8bc80066ec9530d4ea5ccb	2026-05-03 16:26:39.451558+00	20260429165000_analytics_health_visibility	\N	\N	2026-05-03 16:26:39.450732+00	1
03356cb3-8da3-4aee-8f0f-b7526f2e4d4b	b359591e7c6d8b2af1f8d8b1262c0f4762a8f583d9b14cbe5cdfd098f23cb238	2026-05-03 16:26:39.4225+00	20260428230000_analytics_baseline_quality	\N	\N	2026-05-03 16:26:39.413488+00	1
216ba7ae-ae9d-4d06-afbf-3811c9accafe	0d885301ce939908774ab357e498551be8e493d88fa941c57173881a64e3f30b	2026-05-03 16:26:39.426319+00	20260428241000_analytics_insights_history	\N	\N	2026-05-03 16:26:39.422764+00	1
24618eb7-eebd-4e81-930a-b55c7d118378	21aa3febf1da3ed61c33dd15727afaee6b13cdd65779d5ce580c1ca504dca842	2026-05-03 16:26:39.520808+00	20260502210000_canonical_configurations	\N	\N	2026-05-03 16:26:39.515149+00	1
f5bd1eea-9f3f-49e6-add6-919de0898af1	6e2c56c1909b480fd79b34f2c18da00fe846b6bde6034c1314d96817371a3f5c	2026-05-03 16:26:39.43049+00	20260428250000_analytics_ai_insights	\N	\N	2026-05-03 16:26:39.426531+00	1
e5ab838e-7fd9-460f-a8da-7575d5ed08f7	5a9f3ff2ebc6bf0eaaf8aa01360c5835b61bed78e6cb1b18a1f9fb9bcae25bf7	2026-05-03 16:26:39.457026+00	20260429172000_analytics_data_trust_checks	\N	\N	2026-05-03 16:26:39.451843+00	1
1aacd7fc-c245-41a5-b89a-7a809b61a3e8	f9e4ff86595c147a9f36119977d6cf54c118cc2181f8c1d53da0a86c56c98577	2026-05-03 16:26:39.435287+00	20260428260000_analytics_measurement_events_and_ads_conversion_flag	\N	\N	2026-05-03 16:26:39.430736+00	1
d26d345c-b45b-4d96-b6a4-90b97d494e46	007b46039fec0cb989431593bec77aab6c5c50269e970c206acdf8b29905da55	2026-05-03 16:26:39.440336+00	20260429000000_meta_capi_tracking	\N	\N	2026-05-03 16:26:39.435572+00	1
97ad2989-bf0c-4549-8f47-2daac3bdc16f	ff54e9dc2c306019e1616e26aaf4c5ed8d81108fffc5f03f703872185f84d9f3	2026-05-03 16:26:39.49964+00	20260429213000_cms_tenant_content	\N	\N	2026-05-03 16:26:39.491787+00	1
567aea1a-d1e1-4c7b-aecb-642b5e1b7242	58eda50b3568e0facd45d254ffd5be1a93714439e96a92c2ff5aad0838e4782e	2026-05-03 16:26:39.443333+00	20260429102000_analytics_conversion_flag	\N	\N	2026-05-03 16:26:39.440564+00	1
aef8420e-9ce4-4994-8e8f-6c03b5599f9c	b712a01c08b54b5148b8b9be5967f4cab55d8b3f4efadcc4e48c1d96b9a3f2f9	2026-05-03 16:26:39.465073+00	20260429183000_analytics_parity_usage	\N	\N	2026-05-03 16:26:39.457252+00	1
d8994dc9-9746-43ff-aa57-8910d2117544	19c97aec7af4a892521854d8bdc32d47936b01fbd0a495deb057aff7547f637a	2026-05-03 16:26:39.507692+00	20260501172000_product_image_family_key	\N	\N	2026-05-03 16:26:39.507022+00	1
cd406452-3c8a-459f-917a-7e8c770a8a92	94fbc8ac6309c24f8db8c073d877082c56fa4916d6f2313b1b6401ff1e2939d9	2026-05-03 16:26:39.475086+00	20260429190000_phone_otp_auth	\N	\N	2026-05-03 16:26:39.465319+00	1
ad6e06f4-0e0d-4063-bf8e-d9044cdd77e7	f0237f533660ec2fed263645bddc2096bb75e0c05aebc691ada93421273c0886	2026-05-03 16:26:39.503517+00	20260430090000_cms_remove_tenant_key	\N	\N	2026-05-03 16:26:39.499889+00	1
feec8212-51fb-4e78-b3e5-ebc0612eb96d	96dd611d3a736bd677d54a66142bf0028ce9077b1aeb6c6af83948c0eea00b7b	2026-05-03 16:26:39.479254+00	20260429194000_analytics_export_runs	\N	\N	2026-05-03 16:26:39.47536+00	1
9a3e42fd-901d-40db-935c-b8ca17f22d21	9b4033db642e79c488a14850491233374670ec60b92b508f2186857f49a4be3f	2026-05-03 16:26:39.48024+00	20260429195500_analytics_export_run_traceability	\N	\N	2026-05-03 16:26:39.479482+00	1
fda009ca-5cb5-45ca-8db5-450f35c9c778	60428e0a90f2f44e9e23a1f7c226b7997f679ecaeea4d3d85284680160410a30	2026-05-03 16:26:39.504495+00	20260430093000_cms_visual_marketing_sections	\N	\N	2026-05-03 16:26:39.503718+00	1
1473baba-97e4-4c02-a31e-ef4b865a1dc5	f13248825ebb0c3f46a939aff398f3c11d165d7b64c374cbae6cc30c089cf3a3	2026-05-03 16:26:39.514045+00	20260501180000_stories_sitewide	\N	\N	2026-05-03 16:26:39.507913+00	1
637f764c-0371-469b-8714-e2ba2851b2cf	a7046c2fb8ddb1245cd3fd7dfcf1eb835d52c03725f1971f2c009c9bcc44f57e	2026-05-03 16:26:39.505599+00	20260501170000_product_image_media_metadata	\N	\N	2026-05-03 16:26:39.504718+00	1
92f1b286-7fa8-4fdf-a73b-5bf2787d6edb	e7a07b5d7e943fb59655fa3406c4537a9d160e579de2e1ec97b403f72dca64a9	2026-05-03 16:26:39.506829+00	20260501171000_product_image_sequence_fix	\N	\N	2026-05-03 16:26:39.505793+00	1
d1cb1413-fa19-49be-a71f-22c40e157c90	dc1d5f08f3398b1c19ceae69ac94f40a9618b81f914ce5181fb95280f0cc8635	2026-05-03 16:26:39.514952+00	20260502190000_restore_settings_table	\N	\N	2026-05-03 16:26:39.514249+00	1
3c067ed5-1afc-4501-9be7-cfea700a4592	2558e441b38417fca6a0eca4d78e4bdf17eb37fe626ff57450044d6a181b8a81	2026-05-03 16:26:39.536172+00	20260502234500_analytics_event_cross_validation	\N	\N	2026-05-03 16:26:39.529057+00	1
abec1c92-c85d-416b-965d-bf09ed8c6823	bc0bfb67b988d132ce2e87eeaf2f522b53ef4e0122eaa65fb86545e14c8996cb	2026-05-03 16:26:39.527542+00	20260502224500_analytics_structural_event_columns	\N	\N	2026-05-03 16:26:39.521042+00	1
b1cf33fa-da99-4216-913d-abe03a577a3c	3c23dece175fec69f1b56314482054b3f97eae371569f859c1a8b9670c134354	2026-05-03 16:26:39.528851+00	20260502231000_analytics_tenant_id_no_default	\N	\N	2026-05-03 16:26:39.527787+00	1
15ee3909-3bbc-4baa-aa5e-7d12b51c346c	c95fbd3b55acf8fb5c19829327c0a8657600118bf5eb5b3f0e7624fc44f85eeb	2026-05-03 16:26:39.537747+00	20260503090000_catalog_exposure_mode	\N	\N	2026-05-03 16:26:39.536404+00	1
\.


--
-- Data for Name: abertura_glossary_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.abertura_glossary_items (id, category, label, value, "adjustPct", metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: analytics_ads_daily_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_ads_daily_metrics (id, date, campaign, clicks, impressions, cost, conversions, conversion_value, connection_id, sync_run_id, created_at, has_conversion_data) FROM stdin;
\.


--
-- Data for Name: analytics_ai_insights; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_ai_insights (id, date, summary, insights_json, actions_json, confidence, bundle_json, response_json, created_at) FROM stdin;
\.


--
-- Data for Name: analytics_baseline_checks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_baseline_checks (id, date, source, metric, comparison_kind, expected_value, actual_value, diff_pct, status, snapshot_group, created_at) FROM stdin;
\.


--
-- Data for Name: analytics_baseline_snapshots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_baseline_snapshots (id, connection_id, source, report_key, date, metric_name, dimension_hash, dimension_values, value, query_hash, raw, created_at, origin, snapshot_group) FROM stdin;
\.


--
-- Data for Name: analytics_connection_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_connection_credentials (connection_id, refresh_token_encrypted, access_token_encrypted, expires_at, scopes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: analytics_connections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_connections (id, source, status, external_account_id, external_property_id, display_name, sync_interval_minutes, last_synced_at, next_sync_at, needs_reauth, created_at, updated_at, last_attempted_sync_at, last_successful_sync_at, last_sync_error_message, last_sync_error_at) FROM stdin;
\.


--
-- Data for Name: analytics_data_anomalies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_data_anomalies (id, type, source, metric, description, severity, detected_at) FROM stdin;
\.


--
-- Data for Name: analytics_data_parity_checks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_data_parity_checks (id, source, metric, date_from, date_to, api_value, baseline_value, delta_abs, delta_percent, status, snapshot_group, created_at) FROM stdin;
\.


--
-- Data for Name: analytics_data_quality_checks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_data_quality_checks (id, connection_id, report_key, date, metric_name, dimension_hash, baseline_value, synced_value, diff, diff_percent, status, baseline_snapshot_id, sync_run_id, query_hash, created_at) FROM stdin;
\.


--
-- Data for Name: analytics_data_trust_checks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_data_trust_checks (id, environment, check_name, status, metric_value, expected_range, details_json, created_at) FROM stdin;
\.


--
-- Data for Name: analytics_endpoint_usage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_endpoint_usage (id, endpoint, user_id, status_code, duration_ms, created_at) FROM stdin;
\.


--
-- Data for Name: analytics_event_comparisons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_event_comparisons (id, tenant_id, event_id, event_name, direct_event_timestamp, ga_event_timestamp, exists_in_direct, exists_in_ga, payload_match, time_diff_ms, status, direct_source, ga_source, comparison_date, direct_payload, ga_payload, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: analytics_export_runs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_export_runs (id, export_type, source, date_from, date_to, filters, row_count, file_format, status, error_message, created_at, duration_ms, file_size) FROM stdin;
\.


--
-- Data for Name: analytics_ga4_daily_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_ga4_daily_metrics (id, date, source, medium, campaign, sessions, users, event_count, key_events, purchases, revenue, connection_id, sync_run_id, created_at) FROM stdin;
\.


--
-- Data for Name: analytics_health_alert_state; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_health_alert_state (id, environment, last_status, last_signature, last_alerted_at, created_at, updated_at, last_summary_at, last_digest_at, last_digest_signature) FROM stdin;
\.


--
-- Data for Name: analytics_health_checks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_health_checks (id, status, environment, summary, details_json, duration_ms, created_at) FROM stdin;
\.


--
-- Data for Name: analytics_insights; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_insights (id, source, metric, dimension, title, description, recommendation, impact, confidence, evidence, created_at, resolved_at, status) FROM stdin;
\.


--
-- Data for Name: analytics_insights_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_insights_history (id, date, insight_type, title, description, impact, recommendation, confidence, evidence, source_report, period_range, score, summary, created_at) FROM stdin;
\.


--
-- Data for Name: analytics_report_catalog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_report_catalog (key, source, title, description, baseline_header, baseline_title, equivalence_status, row_key_strategy, dimension_labels, metric_labels, api_definition, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: analytics_report_reconciliations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_report_reconciliations (id, report_key, baseline_run_id, sync_run_id, status, baseline_row_count, sync_row_count, matched_row_count, baseline_only_row_count, sync_only_row_count, delta_percent, summary, evidence, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: analytics_report_rows; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_report_rows (id, report_run_id, report_key, source, row_type, row_index, row_key, dimensions, metrics, raw, created_at) FROM stdin;
\.


--
-- Data for Name: analytics_report_runs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_report_runs (id, report_key, source, status, from_date, to_date, row_count, error_message, metadata, started_at, finished_at, created_at) FROM stdin;
\.


--
-- Data for Name: analytics_reporting_daily; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_reporting_daily (id, date, channel, source, medium, campaign, product_id, landing_page, device, country, sessions, users, revenue, orders, cost, impressions, clicks, views, add_to_cart, event_count, key_events, purchase, created_at, ga4_purchase_proxy) FROM stdin;
\.


--
-- Data for Name: analytics_search_console_daily_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_search_console_daily_metrics (id, date, query, page, clicks, impressions, ctr, "position", connection_id, sync_run_id, created_at) FROM stdin;
\.


--
-- Data for Name: analytics_sync_runs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_sync_runs (id, connection_id, job_type, from_date, to_date, status, records_fetched, records_upserted, error_message, started_at, finished_at, created_at, queued_at, retry_count, partial_failure_flag, duration_ms) FROM stdin;
\.


--
-- Data for Name: analytics_usage_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_usage_events (id, endpoint, user_id, time_range, filters, response_time_ms, response_size, trust_level, has_data, created_at) FROM stdin;
\.


--
-- Data for Name: dimension_price_matrix; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dimension_price_matrix (id, "productId", fingerprint, option_state, "familyId", serie, material, color, vidrio, "widthMm", "heightMm", "hasMosquitero", "hasShutterMonoblock", "shutterSystem", price, "priceBase", "priceMosquitero", "priceMonoblock", "priceMonoblockMosquitero", "hasMosquiteroOption", "hasMonoblockOption", currency, "detailSnapshot", price_lineage, conflict_flags, source, reference_date, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: event_facts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.event_facts (id, event_name, event_timestamp, event_date, session_id, user_id, page, path, product_id, category, utm_source, utm_medium, utm_campaign, referrer, device, country, value, source_event_id, created_at, event_category, source, measurement_status, event_id, fbp, fbc, external_targets, meta_sent_at, meta_event_id, meta_status, conversion_flag, utm_term, utm_content, landing_page, tenant_id, schema_version, page_type, component_type, component_id, cta_id, cta_name, cta_type, cta_context, cta_location, "position", ingestion_source, ingestion_path) FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.events (id, event_name, session_id, correlation_id, user_id, url, referrer, user_agent, "timestamp", payload, processed, "processedAt", "createdAt", "updatedAt", event_category, source, measurement_status, event_id, fbp, fbc, external_targets, meta_sent_at, meta_event_id, meta_status, conversion_flag, tenant_id, schema_version, page_type, component_type, component_id, cta_id, cta_name, cta_type, cta_context, cta_location, "position", ingestion_source, ingestion_path) FROM stdin;
\.


--
-- Data for Name: otp_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.otp_codes (id, "userId", "codeHash", type, "expiresAt", attempts, "consumedAt", target, channel, metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: parametric_compatibility_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parametric_compatibility_rules (id, "productId", type, "ruleKey", "ruleValue", note, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: parametric_matrix_staging; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parametric_matrix_staging (id, "productId", fingerprint, option_state, "familyId", serie, material, color, vidrio, "widthMm", "heightMm", "hasMosquitero", "hasShutterMonoblock", "shutterSystem", "hasMosquiteroOption", "hasMonoblockOption", "priceBase", "priceMosquitero", "priceMonoblock", "priceMonoblockMosquitero", currency, specifications, "sourceSystem", "sourceRecordId", source, reference_date, "ingestedAt", "processedAt", payload) FROM stdin;
\.


--
-- Data for Name: security_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.security_events (id, "userId", "eventType", channel, "ipAddress", "userAgent", metadata, "createdAt") FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, first_seen, last_seen, utm_source, utm_medium, utm_campaign, referrer, created_at, updated_at) FROM stdin;
\.


--
-- Name: ActivityColumn_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ActivityColumn_id_seq"', 1, false);


--
-- Name: ActivityTicket_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ActivityTicket_id_seq"', 1, false);


--
-- Name: CalendarEventAttachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CalendarEventAttachment_id_seq"', 1, false);


--
-- Name: CalendarEventComment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CalendarEventComment_id_seq"', 1, false);


--
-- Name: CalendarEventType_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CalendarEventType_id_seq"', 1, false);


--
-- Name: CalendarEvent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CalendarEvent_id_seq"', 1, false);


--
-- Name: CanonicalConfiguration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CanonicalConfiguration_id_seq"', 1, false);


--
-- Name: CmsEntryAsset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CmsEntryAsset_id_seq"', 24, true);


--
-- Name: CmsEntry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CmsEntry_id_seq"', 24, true);


--
-- Name: CmsMedia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CmsMedia_id_seq"', 86, true);


--
-- Name: CmsPageAlias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CmsPageAlias_id_seq"', 1, true);


--
-- Name: CmsPageBlock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CmsPageBlock_id_seq"', 185, true);


--
-- Name: CmsPageSection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CmsPageSection_id_seq"', 106, true);


--
-- Name: CmsPage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CmsPage_id_seq"', 27, true);


--
-- Name: CmsSection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CmsSection_id_seq"', 4, true);


--
-- Name: CompanyProfile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CompanyProfile_id_seq"', 1, false);


--
-- Name: CurrencyRate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CurrencyRate_id_seq"', 1, false);


--
-- Name: CustomerAddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CustomerAddress_id_seq"', 1, false);


--
-- Name: CustomerEmailVerificationToken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CustomerEmailVerificationToken_id_seq"', 1, false);


--
-- Name: CustomerOAuthAccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CustomerOAuthAccount_id_seq"', 1, false);


--
-- Name: CustomerOtpChallenge_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CustomerOtpChallenge_id_seq"', 1, false);


--
-- Name: CustomerPhone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CustomerPhone_id_seq"', 1, false);


--
-- Name: CustomerReauthToken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CustomerReauthToken_id_seq"', 1, false);


--
-- Name: CustomerSecurityEvent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CustomerSecurityEvent_id_seq"', 1, false);


--
-- Name: CustomerStatus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CustomerStatus_id_seq"', 3, true);


--
-- Name: Customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Customer_id_seq"', 1, false);


--
-- Name: EmailLog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EmailLog_id_seq"', 1, false);


--
-- Name: EmailSetting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EmailSetting_id_seq"', 3, true);


--
-- Name: EmailTemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EmailTemplate_id_seq"', 12, true);


--
-- Name: ExpenseAttachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ExpenseAttachment_id_seq"', 1, false);


--
-- Name: ExpenseCategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ExpenseCategory_id_seq"', 1, false);


--
-- Name: ExpenseStatus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ExpenseStatus_id_seq"', 1, false);


--
-- Name: Expense_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Expense_id_seq"', 1, false);


--
-- Name: InboxMessageEvent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."InboxMessageEvent_id_seq"', 1, false);


--
-- Name: NotificationSetting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."NotificationSetting_id_seq"', 1, false);


--
-- Name: Notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Notification_id_seq"', 1, false);


--
-- Name: OrderItem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."OrderItem_id_seq"', 1, false);


--
-- Name: OrderTimelineEvent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."OrderTimelineEvent_id_seq"', 1, false);


--
-- Name: Order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Order_id_seq"', 1, false);


--
-- Name: PasswordResetToken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PasswordResetToken_id_seq"', 1, false);


--
-- Name: PaymentAttachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PaymentAttachment_id_seq"', 1, false);


--
-- Name: PaymentPlanMilestone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PaymentPlanMilestone_id_seq"', 1, false);


--
-- Name: PaymentPlan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PaymentPlan_id_seq"', 1, false);


--
-- Name: Payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Payment_id_seq"', 1, false);


--
-- Name: ProductCategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ProductCategory_id_seq"', 1, false);


--
-- Name: ProductImage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ProductImage_id_seq"', 1, true);


--
-- Name: ProductOptionValue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ProductOptionValue_id_seq"', 1, false);


--
-- Name: ProductOption_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ProductOption_id_seq"', 1, false);


--
-- Name: ProductRelation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ProductRelation_id_seq"', 1, false);


--
-- Name: ProductReview_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ProductReview_id_seq"', 1, false);


--
-- Name: ProductVariant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ProductVariant_id_seq"', 1, false);


--
-- Name: Product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Product_id_seq"', 1, true);


--
-- Name: ProductionOrder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ProductionOrder_id_seq"', 1, false);


--
-- Name: Project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Project_id_seq"', 1, false);


--
-- Name: RoleNotificationRule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."RoleNotificationRule_id_seq"', 1, true);


--
-- Name: Setting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Setting_id_seq"', 14, true);


--
-- Name: ShippingOption_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ShippingOption_id_seq"', 1, false);


--
-- Name: StandardSize_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."StandardSize_id_seq"', 19, true);


--
-- Name: Task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Task_id_seq"', 1, false);


--
-- Name: UserActivity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."UserActivity_id_seq"', 1, false);


--
-- Name: UserDevice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."UserDevice_id_seq"', 1, false);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."User_id_seq"', 1, true);


--
-- Name: WishlistItem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."WishlistItem_id_seq"', 1, false);


--
-- Name: Wishlist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Wishlist_id_seq"', 1, false);


--
-- Name: WorkOrder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."WorkOrder_id_seq"', 1, false);


--
-- Name: abertura_glossary_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.abertura_glossary_items_id_seq', 1, false);


--
-- Name: analytics_ads_daily_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.analytics_ads_daily_metrics_id_seq', 1, false);


--
-- Name: analytics_ga4_daily_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.analytics_ga4_daily_metrics_id_seq', 1, false);


--
-- Name: analytics_report_rows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.analytics_report_rows_id_seq', 1, false);


--
-- Name: analytics_reporting_daily_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.analytics_reporting_daily_id_seq', 1, false);


--
-- Name: analytics_search_console_daily_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.analytics_search_console_daily_metrics_id_seq', 1, false);


--
-- Name: dimension_price_matrix_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dimension_price_matrix_id_seq', 1, false);


--
-- Name: event_facts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.event_facts_id_seq', 1, false);


--
-- Name: otp_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.otp_codes_id_seq', 1, false);


--
-- Name: parametric_compatibility_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.parametric_compatibility_rules_id_seq', 1, false);


--
-- Name: parametric_matrix_staging_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.parametric_matrix_staging_id_seq', 1, false);


--
-- Name: security_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.security_events_id_seq', 1, false);


--
-- Name: ActivityColumn ActivityColumn_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ActivityColumn"
    ADD CONSTRAINT "ActivityColumn_pkey" PRIMARY KEY (id);


--
-- Name: ActivityTicketMember ActivityTicketMember_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ActivityTicketMember"
    ADD CONSTRAINT "ActivityTicketMember_pkey" PRIMARY KEY ("ticketId", "userId");


--
-- Name: ActivityTicket ActivityTicket_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ActivityTicket"
    ADD CONSTRAINT "ActivityTicket_pkey" PRIMARY KEY (id);


--
-- Name: CalendarEventAttachment CalendarEventAttachment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CalendarEventAttachment"
    ADD CONSTRAINT "CalendarEventAttachment_pkey" PRIMARY KEY (id);


--
-- Name: CalendarEventComment CalendarEventComment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CalendarEventComment"
    ADD CONSTRAINT "CalendarEventComment_pkey" PRIMARY KEY (id);


--
-- Name: CalendarEventType CalendarEventType_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CalendarEventType"
    ADD CONSTRAINT "CalendarEventType_pkey" PRIMARY KEY (id);


--
-- Name: CalendarEvent CalendarEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CalendarEvent"
    ADD CONSTRAINT "CalendarEvent_pkey" PRIMARY KEY (id);


--
-- Name: CanonicalConfiguration CanonicalConfiguration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CanonicalConfiguration"
    ADD CONSTRAINT "CanonicalConfiguration_pkey" PRIMARY KEY (id);


--
-- Name: CmsEntryAsset CmsEntryAsset_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsEntryAsset"
    ADD CONSTRAINT "CmsEntryAsset_pkey" PRIMARY KEY (id);


--
-- Name: CmsEntry CmsEntry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsEntry"
    ADD CONSTRAINT "CmsEntry_pkey" PRIMARY KEY (id);


--
-- Name: CmsMedia CmsMedia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsMedia"
    ADD CONSTRAINT "CmsMedia_pkey" PRIMARY KEY (id);


--
-- Name: CmsPageAlias CmsPageAlias_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsPageAlias"
    ADD CONSTRAINT "CmsPageAlias_pkey" PRIMARY KEY (id);


--
-- Name: CmsPageBlock CmsPageBlock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsPageBlock"
    ADD CONSTRAINT "CmsPageBlock_pkey" PRIMARY KEY (id);


--
-- Name: CmsPageSection CmsPageSection_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsPageSection"
    ADD CONSTRAINT "CmsPageSection_pkey" PRIMARY KEY (id);


--
-- Name: CmsPage CmsPage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsPage"
    ADD CONSTRAINT "CmsPage_pkey" PRIMARY KEY (id);


--
-- Name: CmsSection CmsSection_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsSection"
    ADD CONSTRAINT "CmsSection_pkey" PRIMARY KEY (id);


--
-- Name: CompanyProfile CompanyProfile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CompanyProfile"
    ADD CONSTRAINT "CompanyProfile_pkey" PRIMARY KEY (id);


--
-- Name: ConversationExternalIdentity ConversationExternalIdentity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConversationExternalIdentity"
    ADD CONSTRAINT "ConversationExternalIdentity_pkey" PRIMARY KEY (id);


--
-- Name: ConversationHandoffEvent ConversationHandoffEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConversationHandoffEvent"
    ADD CONSTRAINT "ConversationHandoffEvent_pkey" PRIMARY KEY (id);


--
-- Name: ConversationMessage ConversationMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConversationMessage"
    ADD CONSTRAINT "ConversationMessage_pkey" PRIMARY KEY (id);


--
-- Name: ConversationParticipant ConversationParticipant_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConversationParticipant"
    ADD CONSTRAINT "ConversationParticipant_pkey" PRIMARY KEY (id);


--
-- Name: ConversationReadState ConversationReadState_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConversationReadState"
    ADD CONSTRAINT "ConversationReadState_pkey" PRIMARY KEY ("conversationId", "userId");


--
-- Name: ConversationToolCall ConversationToolCall_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConversationToolCall"
    ADD CONSTRAINT "ConversationToolCall_pkey" PRIMARY KEY (id);


--
-- Name: Conversation Conversation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_pkey" PRIMARY KEY (id);


--
-- Name: CurrencyRate CurrencyRate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CurrencyRate"
    ADD CONSTRAINT "CurrencyRate_pkey" PRIMARY KEY (id);


--
-- Name: CustomerAddress CustomerAddress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerAddress"
    ADD CONSTRAINT "CustomerAddress_pkey" PRIMARY KEY (id);


--
-- Name: CustomerEmailVerificationToken CustomerEmailVerificationToken_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerEmailVerificationToken"
    ADD CONSTRAINT "CustomerEmailVerificationToken_pkey" PRIMARY KEY (id);


--
-- Name: CustomerOAuthAccount CustomerOAuthAccount_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerOAuthAccount"
    ADD CONSTRAINT "CustomerOAuthAccount_pkey" PRIMARY KEY (id);


--
-- Name: CustomerOtpChallenge CustomerOtpChallenge_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerOtpChallenge"
    ADD CONSTRAINT "CustomerOtpChallenge_pkey" PRIMARY KEY (id);


--
-- Name: CustomerPhone CustomerPhone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerPhone"
    ADD CONSTRAINT "CustomerPhone_pkey" PRIMARY KEY (id);


--
-- Name: CustomerReauthToken CustomerReauthToken_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerReauthToken"
    ADD CONSTRAINT "CustomerReauthToken_pkey" PRIMARY KEY (id);


--
-- Name: CustomerSecurityEvent CustomerSecurityEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerSecurityEvent"
    ADD CONSTRAINT "CustomerSecurityEvent_pkey" PRIMARY KEY (id);


--
-- Name: CustomerStatus CustomerStatus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerStatus"
    ADD CONSTRAINT "CustomerStatus_pkey" PRIMARY KEY (id);


--
-- Name: Customer Customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Customer"
    ADD CONSTRAINT "Customer_pkey" PRIMARY KEY (id);


--
-- Name: EmailLog EmailLog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailLog"
    ADD CONSTRAINT "EmailLog_pkey" PRIMARY KEY (id);


--
-- Name: EmailSetting EmailSetting_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailSetting"
    ADD CONSTRAINT "EmailSetting_pkey" PRIMARY KEY (id);


--
-- Name: EmailTemplate EmailTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailTemplate"
    ADD CONSTRAINT "EmailTemplate_pkey" PRIMARY KEY (id);


--
-- Name: ExpenseAttachment ExpenseAttachment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExpenseAttachment"
    ADD CONSTRAINT "ExpenseAttachment_pkey" PRIMARY KEY (id);


--
-- Name: ExpenseCategory ExpenseCategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExpenseCategory"
    ADD CONSTRAINT "ExpenseCategory_pkey" PRIMARY KEY (id);


--
-- Name: ExpenseStatus ExpenseStatus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExpenseStatus"
    ADD CONSTRAINT "ExpenseStatus_pkey" PRIMARY KEY (id);


--
-- Name: Expense Expense_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Expense"
    ADD CONSTRAINT "Expense_pkey" PRIMARY KEY (id);


--
-- Name: InboxAccount InboxAccount_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InboxAccount"
    ADD CONSTRAINT "InboxAccount_pkey" PRIMARY KEY (id);


--
-- Name: InboxAttachment InboxAttachment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InboxAttachment"
    ADD CONSTRAINT "InboxAttachment_pkey" PRIMARY KEY (id);


--
-- Name: InboxMessageEvent InboxMessageEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InboxMessageEvent"
    ADD CONSTRAINT "InboxMessageEvent_pkey" PRIMARY KEY (id);


--
-- Name: InboxMessage InboxMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InboxMessage"
    ADD CONSTRAINT "InboxMessage_pkey" PRIMARY KEY (id);


--
-- Name: InboxQueueUserAssignment InboxQueueUserAssignment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InboxQueueUserAssignment"
    ADD CONSTRAINT "InboxQueueUserAssignment_pkey" PRIMARY KEY (id);


--
-- Name: InboxQueue InboxQueue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InboxQueue"
    ADD CONSTRAINT "InboxQueue_pkey" PRIMARY KEY (id);


--
-- Name: InboxSyncState InboxSyncState_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InboxSyncState"
    ADD CONSTRAINT "InboxSyncState_pkey" PRIMARY KEY (id);


--
-- Name: KnowledgeCandidate KnowledgeCandidate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeCandidate"
    ADD CONSTRAINT "KnowledgeCandidate_pkey" PRIMARY KEY (id);


--
-- Name: KnowledgeConversationBundle KnowledgeConversationBundle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeConversationBundle"
    ADD CONSTRAINT "KnowledgeConversationBundle_pkey" PRIMARY KEY (id);


--
-- Name: KnowledgeDerivedArtifact KnowledgeDerivedArtifact_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeDerivedArtifact"
    ADD CONSTRAINT "KnowledgeDerivedArtifact_pkey" PRIMARY KEY (id);


--
-- Name: KnowledgeDocumentChunk KnowledgeDocumentChunk_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeDocumentChunk"
    ADD CONSTRAINT "KnowledgeDocumentChunk_pkey" PRIMARY KEY (id);


--
-- Name: KnowledgeDocumentEmbedding KnowledgeDocumentEmbedding_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeDocumentEmbedding"
    ADD CONSTRAINT "KnowledgeDocumentEmbedding_pkey" PRIMARY KEY (id);


--
-- Name: KnowledgeDocument KnowledgeDocument_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeDocument"
    ADD CONSTRAINT "KnowledgeDocument_pkey" PRIMARY KEY (id);


--
-- Name: KnowledgeIngestionRun KnowledgeIngestionRun_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeIngestionRun"
    ADD CONSTRAINT "KnowledgeIngestionRun_pkey" PRIMARY KEY (id);


--
-- Name: KnowledgeNegativeExample KnowledgeNegativeExample_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeNegativeExample"
    ADD CONSTRAINT "KnowledgeNegativeExample_pkey" PRIMARY KEY (id);


--
-- Name: KnowledgeRawEvent KnowledgeRawEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeRawEvent"
    ADD CONSTRAINT "KnowledgeRawEvent_pkey" PRIMARY KEY (id);


--
-- Name: KnowledgeSnapshotEntry KnowledgeSnapshotEntry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeSnapshotEntry"
    ADD CONSTRAINT "KnowledgeSnapshotEntry_pkey" PRIMARY KEY (id);


--
-- Name: KnowledgeSnapshotSource KnowledgeSnapshotSource_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeSnapshotSource"
    ADD CONSTRAINT "KnowledgeSnapshotSource_pkey" PRIMARY KEY (id);


--
-- Name: KnowledgeSnapshot KnowledgeSnapshot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeSnapshot"
    ADD CONSTRAINT "KnowledgeSnapshot_pkey" PRIMARY KEY (id);


--
-- Name: KnowledgeSuggestionFeedback KnowledgeSuggestionFeedback_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeSuggestionFeedback"
    ADD CONSTRAINT "KnowledgeSuggestionFeedback_pkey" PRIMARY KEY (id);


--
-- Name: NotificationSetting NotificationSetting_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NotificationSetting"
    ADD CONSTRAINT "NotificationSetting_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: OrderItem OrderItem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_pkey" PRIMARY KEY (id);


--
-- Name: OrderTimelineEvent OrderTimelineEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderTimelineEvent"
    ADD CONSTRAINT "OrderTimelineEvent_pkey" PRIMARY KEY (id);


--
-- Name: Order Order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY (id);


--
-- Name: PasswordResetToken PasswordResetToken_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_pkey" PRIMARY KEY (id);


--
-- Name: PaymentAttachment PaymentAttachment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PaymentAttachment"
    ADD CONSTRAINT "PaymentAttachment_pkey" PRIMARY KEY (id);


--
-- Name: PaymentPlanMilestone PaymentPlanMilestone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PaymentPlanMilestone"
    ADD CONSTRAINT "PaymentPlanMilestone_pkey" PRIMARY KEY (id);


--
-- Name: PaymentPlan PaymentPlan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PaymentPlan"
    ADD CONSTRAINT "PaymentPlan_pkey" PRIMARY KEY (id);


--
-- Name: Payment Payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_pkey" PRIMARY KEY (id);


--
-- Name: ProductCategory ProductCategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductCategory"
    ADD CONSTRAINT "ProductCategory_pkey" PRIMARY KEY (id);


--
-- Name: ProductImage ProductImage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductImage"
    ADD CONSTRAINT "ProductImage_pkey" PRIMARY KEY (id);


--
-- Name: ProductOptionValue ProductOptionValue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductOptionValue"
    ADD CONSTRAINT "ProductOptionValue_pkey" PRIMARY KEY (id);


--
-- Name: ProductOption ProductOption_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductOption"
    ADD CONSTRAINT "ProductOption_pkey" PRIMARY KEY (id);


--
-- Name: ProductRelation ProductRelation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductRelation"
    ADD CONSTRAINT "ProductRelation_pkey" PRIMARY KEY (id);


--
-- Name: ProductReview ProductReview_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductReview"
    ADD CONSTRAINT "ProductReview_pkey" PRIMARY KEY (id);


--
-- Name: ProductVariantSelection ProductVariantSelection_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductVariantSelection"
    ADD CONSTRAINT "ProductVariantSelection_pkey" PRIMARY KEY ("variantId", "optionValueId");


--
-- Name: ProductVariant ProductVariant_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductVariant"
    ADD CONSTRAINT "ProductVariant_pkey" PRIMARY KEY (id);


--
-- Name: Product Product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_pkey" PRIMARY KEY (id);


--
-- Name: ProductionOrder ProductionOrder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductionOrder"
    ADD CONSTRAINT "ProductionOrder_pkey" PRIMARY KEY (id);


--
-- Name: Project Project_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_pkey" PRIMARY KEY (id);


--
-- Name: RoleNotificationRule RoleNotificationRule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RoleNotificationRule"
    ADD CONSTRAINT "RoleNotificationRule_pkey" PRIMARY KEY (id);


--
-- Name: SecureConfig SecureConfig_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SecureConfig"
    ADD CONSTRAINT "SecureConfig_pkey" PRIMARY KEY (key);


--
-- Name: Setting Setting_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Setting"
    ADD CONSTRAINT "Setting_pkey" PRIMARY KEY (id);


--
-- Name: ShippingOption ShippingOption_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ShippingOption"
    ADD CONSTRAINT "ShippingOption_pkey" PRIMARY KEY (id);


--
-- Name: StandardSize StandardSize_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StandardSize"
    ADD CONSTRAINT "StandardSize_pkey" PRIMARY KEY (id);


--
-- Name: StorefrontOAuthSession StorefrontOAuthSession_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StorefrontOAuthSession"
    ADD CONSTRAINT "StorefrontOAuthSession_pkey" PRIMARY KEY (id);


--
-- Name: StorefrontPaymentIntent StorefrontPaymentIntent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StorefrontPaymentIntent"
    ADD CONSTRAINT "StorefrontPaymentIntent_pkey" PRIMARY KEY (id);


--
-- Name: StoryItem StoryItem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StoryItem"
    ADD CONSTRAINT "StoryItem_pkey" PRIMARY KEY (id);


--
-- Name: Story Story_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Story"
    ADD CONSTRAINT "Story_pkey" PRIMARY KEY (id);


--
-- Name: SystemConfig SystemConfig_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SystemConfig"
    ADD CONSTRAINT "SystemConfig_pkey" PRIMARY KEY (key);


--
-- Name: TaskAssignee TaskAssignee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TaskAssignee"
    ADD CONSTRAINT "TaskAssignee_pkey" PRIMARY KEY ("taskId", "userId");


--
-- Name: Task Task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_pkey" PRIMARY KEY (id);


--
-- Name: UserActivity UserActivity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserActivity"
    ADD CONSTRAINT "UserActivity_pkey" PRIMARY KEY (id);


--
-- Name: UserDevice UserDevice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserDevice"
    ADD CONSTRAINT "UserDevice_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: WishlistItem WishlistItem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WishlistItem"
    ADD CONSTRAINT "WishlistItem_pkey" PRIMARY KEY (id);


--
-- Name: Wishlist Wishlist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Wishlist"
    ADD CONSTRAINT "Wishlist_pkey" PRIMARY KEY (id);


--
-- Name: WorkOrder WorkOrder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WorkOrder"
    ADD CONSTRAINT "WorkOrder_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: abertura_glossary_items abertura_glossary_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.abertura_glossary_items
    ADD CONSTRAINT abertura_glossary_items_pkey PRIMARY KEY (id);


--
-- Name: analytics_ads_daily_metrics analytics_ads_daily_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_ads_daily_metrics
    ADD CONSTRAINT analytics_ads_daily_metrics_pkey PRIMARY KEY (id);


--
-- Name: analytics_ai_insights analytics_ai_insights_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_ai_insights
    ADD CONSTRAINT analytics_ai_insights_pkey PRIMARY KEY (id);


--
-- Name: analytics_baseline_checks analytics_baseline_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_baseline_checks
    ADD CONSTRAINT analytics_baseline_checks_pkey PRIMARY KEY (id);


--
-- Name: analytics_baseline_snapshots analytics_baseline_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_baseline_snapshots
    ADD CONSTRAINT analytics_baseline_snapshots_pkey PRIMARY KEY (id);


--
-- Name: analytics_connection_credentials analytics_connection_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_connection_credentials
    ADD CONSTRAINT analytics_connection_credentials_pkey PRIMARY KEY (connection_id);


--
-- Name: analytics_connections analytics_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_connections
    ADD CONSTRAINT analytics_connections_pkey PRIMARY KEY (id);


--
-- Name: analytics_data_anomalies analytics_data_anomalies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_data_anomalies
    ADD CONSTRAINT analytics_data_anomalies_pkey PRIMARY KEY (id);


--
-- Name: analytics_data_parity_checks analytics_data_parity_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_data_parity_checks
    ADD CONSTRAINT analytics_data_parity_checks_pkey PRIMARY KEY (id);


--
-- Name: analytics_data_quality_checks analytics_data_quality_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_data_quality_checks
    ADD CONSTRAINT analytics_data_quality_checks_pkey PRIMARY KEY (id);


--
-- Name: analytics_data_trust_checks analytics_data_trust_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_data_trust_checks
    ADD CONSTRAINT analytics_data_trust_checks_pkey PRIMARY KEY (id);


--
-- Name: analytics_endpoint_usage analytics_endpoint_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_endpoint_usage
    ADD CONSTRAINT analytics_endpoint_usage_pkey PRIMARY KEY (id);


--
-- Name: analytics_event_comparisons analytics_event_comparisons_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_event_comparisons
    ADD CONSTRAINT analytics_event_comparisons_pkey PRIMARY KEY (id);


--
-- Name: analytics_export_runs analytics_export_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_export_runs
    ADD CONSTRAINT analytics_export_runs_pkey PRIMARY KEY (id);


--
-- Name: analytics_ga4_daily_metrics analytics_ga4_daily_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_ga4_daily_metrics
    ADD CONSTRAINT analytics_ga4_daily_metrics_pkey PRIMARY KEY (id);


--
-- Name: analytics_health_alert_state analytics_health_alert_state_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_health_alert_state
    ADD CONSTRAINT analytics_health_alert_state_pkey PRIMARY KEY (id);


--
-- Name: analytics_health_checks analytics_health_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_health_checks
    ADD CONSTRAINT analytics_health_checks_pkey PRIMARY KEY (id);


--
-- Name: analytics_insights_history analytics_insights_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_insights_history
    ADD CONSTRAINT analytics_insights_history_pkey PRIMARY KEY (id);


--
-- Name: analytics_insights analytics_insights_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_insights
    ADD CONSTRAINT analytics_insights_pkey PRIMARY KEY (id);


--
-- Name: analytics_report_catalog analytics_report_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_report_catalog
    ADD CONSTRAINT analytics_report_catalog_pkey PRIMARY KEY (key);


--
-- Name: analytics_report_reconciliations analytics_report_reconciliations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_report_reconciliations
    ADD CONSTRAINT analytics_report_reconciliations_pkey PRIMARY KEY (id);


--
-- Name: analytics_report_rows analytics_report_rows_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_report_rows
    ADD CONSTRAINT analytics_report_rows_pkey PRIMARY KEY (id);


--
-- Name: analytics_report_runs analytics_report_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_report_runs
    ADD CONSTRAINT analytics_report_runs_pkey PRIMARY KEY (id);


--
-- Name: analytics_reporting_daily analytics_reporting_daily_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_reporting_daily
    ADD CONSTRAINT analytics_reporting_daily_pkey PRIMARY KEY (id);


--
-- Name: analytics_search_console_daily_metrics analytics_search_console_daily_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_search_console_daily_metrics
    ADD CONSTRAINT analytics_search_console_daily_metrics_pkey PRIMARY KEY (id);


--
-- Name: analytics_sync_runs analytics_sync_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_sync_runs
    ADD CONSTRAINT analytics_sync_runs_pkey PRIMARY KEY (id);


--
-- Name: analytics_usage_events analytics_usage_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_usage_events
    ADD CONSTRAINT analytics_usage_events_pkey PRIMARY KEY (id);


--
-- Name: dimension_price_matrix dimension_price_matrix_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dimension_price_matrix
    ADD CONSTRAINT dimension_price_matrix_pkey PRIMARY KEY (id);


--
-- Name: event_facts event_facts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_facts
    ADD CONSTRAINT event_facts_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: otp_codes otp_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_codes
    ADD CONSTRAINT otp_codes_pkey PRIMARY KEY (id);


--
-- Name: parametric_compatibility_rules parametric_compatibility_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parametric_compatibility_rules
    ADD CONSTRAINT parametric_compatibility_rules_pkey PRIMARY KEY (id);


--
-- Name: parametric_matrix_staging parametric_matrix_staging_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parametric_matrix_staging
    ADD CONSTRAINT parametric_matrix_staging_pkey PRIMARY KEY (id);


--
-- Name: security_events security_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: ActivityColumn_title_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ActivityColumn_title_key" ON public."ActivityColumn" USING btree (title);


--
-- Name: CanonicalConfiguration_baseProductId_indexable_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CanonicalConfiguration_baseProductId_indexable_idx" ON public."CanonicalConfiguration" USING btree ("baseProductId", indexable);


--
-- Name: CanonicalConfiguration_tenantId_indexable_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CanonicalConfiguration_tenantId_indexable_idx" ON public."CanonicalConfiguration" USING btree ("tenantId", indexable);


--
-- Name: CanonicalConfiguration_tenantId_slug_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "CanonicalConfiguration_tenantId_slug_key" ON public."CanonicalConfiguration" USING btree ("tenantId", slug);


--
-- Name: CmsEntryAsset_entryId_isActive_sortOrder_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CmsEntryAsset_entryId_isActive_sortOrder_idx" ON public."CmsEntryAsset" USING btree ("entryId", "isActive", "sortOrder");


--
-- Name: CmsEntry_categoryId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CmsEntry_categoryId_idx" ON public."CmsEntry" USING btree ("categoryId");


--
-- Name: CmsEntry_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CmsEntry_productId_idx" ON public."CmsEntry" USING btree ("productId");


--
-- Name: CmsEntry_publishedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CmsEntry_publishedAt_idx" ON public."CmsEntry" USING btree ("publishedAt");


--
-- Name: CmsEntry_sectionId_locale_slug_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "CmsEntry_sectionId_locale_slug_key" ON public."CmsEntry" USING btree ("sectionId", locale, slug);


--
-- Name: CmsEntry_sectionId_status_isActive_priority_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CmsEntry_sectionId_status_isActive_priority_idx" ON public."CmsEntry" USING btree ("sectionId", status, "isActive", priority);


--
-- Name: CmsMedia_type_isActive_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CmsMedia_type_isActive_createdAt_idx" ON public."CmsMedia" USING btree (type, "isActive", "createdAt");


--
-- Name: CmsPageAlias_pageId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CmsPageAlias_pageId_idx" ON public."CmsPageAlias" USING btree ("pageId");


--
-- Name: CmsPageAlias_path_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "CmsPageAlias_path_key" ON public."CmsPageAlias" USING btree (path);


--
-- Name: CmsPageBlock_mediaId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CmsPageBlock_mediaId_idx" ON public."CmsPageBlock" USING btree ("mediaId");


--
-- Name: CmsPageBlock_sectionId_sortOrder_visible_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CmsPageBlock_sectionId_sortOrder_visible_idx" ON public."CmsPageBlock" USING btree ("sectionId", "sortOrder", visible);


--
-- Name: CmsPageSection_pageId_sortOrder_visible_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CmsPageSection_pageId_sortOrder_visible_idx" ON public."CmsPageSection" USING btree ("pageId", "sortOrder", visible);


--
-- Name: CmsPage_path_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CmsPage_path_idx" ON public."CmsPage" USING btree (path);


--
-- Name: CmsPage_path_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "CmsPage_path_key" ON public."CmsPage" USING btree (path);


--
-- Name: CmsPage_scope_status_locale_visible_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CmsPage_scope_status_locale_visible_idx" ON public."CmsPage" USING btree (scope, status, locale, visible);


--
-- Name: CmsSection_isActive_sortOrder_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CmsSection_isActive_sortOrder_idx" ON public."CmsSection" USING btree ("isActive", "sortOrder");


--
-- Name: CmsSection_key_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "CmsSection_key_key" ON public."CmsSection" USING btree (key);


--
-- Name: CompanyProfile_singleton_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "CompanyProfile_singleton_key" ON public."CompanyProfile" USING btree (singleton);


--
-- Name: ConversationExternalIdentity_conversationId_kind_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ConversationExternalIdentity_conversationId_kind_idx" ON public."ConversationExternalIdentity" USING btree ("conversationId", kind);


--
-- Name: ConversationExternalIdentity_tenantKey_channel_kind_normali_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ConversationExternalIdentity_tenantKey_channel_kind_normali_key" ON public."ConversationExternalIdentity" USING btree ("tenantKey", channel, kind, "normalizedValue");


--
-- Name: ConversationExternalIdentity_tenantKey_channel_normalizedVa_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ConversationExternalIdentity_tenantKey_channel_normalizedVa_idx" ON public."ConversationExternalIdentity" USING btree ("tenantKey", channel, "normalizedValue");


--
-- Name: ConversationHandoffEvent_conversationId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ConversationHandoffEvent_conversationId_createdAt_idx" ON public."ConversationHandoffEvent" USING btree ("conversationId", "createdAt");


--
-- Name: ConversationMessage_conversationId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ConversationMessage_conversationId_createdAt_idx" ON public."ConversationMessage" USING btree ("conversationId", "createdAt");


--
-- Name: ConversationMessage_externalMessageId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ConversationMessage_externalMessageId_idx" ON public."ConversationMessage" USING btree ("externalMessageId");


--
-- Name: ConversationMessage_inboxMessageId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ConversationMessage_inboxMessageId_idx" ON public."ConversationMessage" USING btree ("inboxMessageId");


--
-- Name: ConversationParticipant_conversationId_role_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ConversationParticipant_conversationId_role_idx" ON public."ConversationParticipant" USING btree ("conversationId", role);


--
-- Name: ConversationParticipant_customerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ConversationParticipant_customerId_idx" ON public."ConversationParticipant" USING btree ("customerId");


--
-- Name: ConversationParticipant_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ConversationParticipant_userId_idx" ON public."ConversationParticipant" USING btree ("userId");


--
-- Name: ConversationReadState_userId_updatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ConversationReadState_userId_updatedAt_idx" ON public."ConversationReadState" USING btree ("userId", "updatedAt");


--
-- Name: ConversationToolCall_conversationId_status_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ConversationToolCall_conversationId_status_createdAt_idx" ON public."ConversationToolCall" USING btree ("conversationId", status, "createdAt");


--
-- Name: ConversationToolCall_messageId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ConversationToolCall_messageId_idx" ON public."ConversationToolCall" USING btree ("messageId");


--
-- Name: Conversation_assignedToUserId_status_lastMessageAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Conversation_assignedToUserId_status_lastMessageAt_idx" ON public."Conversation" USING btree ("assignedToUserId", status, "lastMessageAt");


--
-- Name: Conversation_conversationRole_lastMessageAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Conversation_conversationRole_lastMessageAt_idx" ON public."Conversation" USING btree ("conversationRole", "lastMessageAt");


--
-- Name: Conversation_customerId_lastMessageAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Conversation_customerId_lastMessageAt_idx" ON public."Conversation" USING btree ("customerId", "lastMessageAt");


--
-- Name: Conversation_inboxAccountId_channel_lastMessageAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Conversation_inboxAccountId_channel_lastMessageAt_idx" ON public."Conversation" USING btree ("inboxAccountId", channel, "lastMessageAt");


--
-- Name: Conversation_tenantKey_channel_externalThreadId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Conversation_tenantKey_channel_externalThreadId_key" ON public."Conversation" USING btree ("tenantKey", channel, "externalThreadId");


--
-- Name: Conversation_tenantKey_scope_channel_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Conversation_tenantKey_scope_channel_status_idx" ON public."Conversation" USING btree ("tenantKey", scope, channel, status);


--
-- Name: CurrencyRate_base_quote_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "CurrencyRate_base_quote_key" ON public."CurrencyRate" USING btree (base, quote);


--
-- Name: CustomerEmailVerificationToken_customerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CustomerEmailVerificationToken_customerId_idx" ON public."CustomerEmailVerificationToken" USING btree ("customerId");


--
-- Name: CustomerEmailVerificationToken_expiresAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CustomerEmailVerificationToken_expiresAt_idx" ON public."CustomerEmailVerificationToken" USING btree ("expiresAt");


--
-- Name: CustomerEmailVerificationToken_tokenHash_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "CustomerEmailVerificationToken_tokenHash_key" ON public."CustomerEmailVerificationToken" USING btree ("tokenHash");


--
-- Name: CustomerOAuthAccount_customerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CustomerOAuthAccount_customerId_idx" ON public."CustomerOAuthAccount" USING btree ("customerId");


--
-- Name: CustomerOAuthAccount_provider_providerAccountId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "CustomerOAuthAccount_provider_providerAccountId_key" ON public."CustomerOAuthAccount" USING btree (provider, "providerAccountId");


--
-- Name: CustomerOtpChallenge_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CustomerOtpChallenge_createdAt_idx" ON public."CustomerOtpChallenge" USING btree ("createdAt");


--
-- Name: CustomerOtpChallenge_customerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CustomerOtpChallenge_customerId_idx" ON public."CustomerOtpChallenge" USING btree ("customerId");


--
-- Name: CustomerOtpChallenge_expiresAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CustomerOtpChallenge_expiresAt_idx" ON public."CustomerOtpChallenge" USING btree ("expiresAt");


--
-- Name: CustomerOtpChallenge_phone_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CustomerOtpChallenge_phone_idx" ON public."CustomerOtpChallenge" USING btree (phone);


--
-- Name: CustomerReauthToken_customerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CustomerReauthToken_customerId_idx" ON public."CustomerReauthToken" USING btree ("customerId");


--
-- Name: CustomerReauthToken_expiresAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CustomerReauthToken_expiresAt_idx" ON public."CustomerReauthToken" USING btree ("expiresAt");


--
-- Name: CustomerReauthToken_tokenHash_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "CustomerReauthToken_tokenHash_key" ON public."CustomerReauthToken" USING btree ("tokenHash");


--
-- Name: CustomerSecurityEvent_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CustomerSecurityEvent_createdAt_idx" ON public."CustomerSecurityEvent" USING btree ("createdAt");


--
-- Name: CustomerSecurityEvent_customerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CustomerSecurityEvent_customerId_idx" ON public."CustomerSecurityEvent" USING btree ("customerId");


--
-- Name: CustomerStatus_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "CustomerStatus_name_key" ON public."CustomerStatus" USING btree (name);


--
-- Name: Customer_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Customer_email_key" ON public."Customer" USING btree (email);


--
-- Name: Customer_phoneNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Customer_phoneNumber_key" ON public."Customer" USING btree ("phoneNumber");


--
-- Name: EmailLog_category_status_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "EmailLog_category_status_createdAt_idx" ON public."EmailLog" USING btree (category, status, "createdAt");


--
-- Name: EmailLog_templateId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "EmailLog_templateId_idx" ON public."EmailLog" USING btree ("templateId");


--
-- Name: EmailLog_toAddress_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "EmailLog_toAddress_createdAt_idx" ON public."EmailLog" USING btree ("toAddress", "createdAt");


--
-- Name: EmailSetting_category_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "EmailSetting_category_key" ON public."EmailSetting" USING btree (category);


--
-- Name: EmailTemplate_category_locale_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "EmailTemplate_category_locale_active_idx" ON public."EmailTemplate" USING btree (category, locale, active);


--
-- Name: EmailTemplate_category_locale_variant_version_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "EmailTemplate_category_locale_variant_version_key" ON public."EmailTemplate" USING btree (category, locale, variant, version);


--
-- Name: ExpenseCategory_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ExpenseCategory_name_key" ON public."ExpenseCategory" USING btree (name);


--
-- Name: ExpenseStatus_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ExpenseStatus_name_key" ON public."ExpenseStatus" USING btree (name);


--
-- Name: InboxAccount_channel_address_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "InboxAccount_channel_address_key" ON public."InboxAccount" USING btree (channel, address);


--
-- Name: InboxMessageEvent_messageId_occurredAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "InboxMessageEvent_messageId_occurredAt_idx" ON public."InboxMessageEvent" USING btree ("messageId", "occurredAt");


--
-- Name: InboxMessage_accountId_channel_remoteId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "InboxMessage_accountId_channel_remoteId_key" ON public."InboxMessage" USING btree ("accountId", channel, "remoteId");


--
-- Name: InboxMessage_accountId_folder_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "InboxMessage_accountId_folder_idx" ON public."InboxMessage" USING btree ("accountId", folder);


--
-- Name: InboxMessage_accountId_isRead_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "InboxMessage_accountId_isRead_idx" ON public."InboxMessage" USING btree ("accountId", "isRead");


--
-- Name: InboxMessage_accountId_sentAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "InboxMessage_accountId_sentAt_idx" ON public."InboxMessage" USING btree ("accountId", "sentAt");


--
-- Name: InboxMessage_messageUid_provider_folder_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "InboxMessage_messageUid_provider_folder_key" ON public."InboxMessage" USING btree ("messageUid", provider, folder);


--
-- Name: InboxMessage_queueId_receivedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "InboxMessage_queueId_receivedAt_idx" ON public."InboxMessage" USING btree ("queueId", "receivedAt");


--
-- Name: InboxQueueUserAssignment_queueId_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "InboxQueueUserAssignment_queueId_isActive_idx" ON public."InboxQueueUserAssignment" USING btree ("queueId", "isActive");


--
-- Name: InboxQueueUserAssignment_queueId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "InboxQueueUserAssignment_queueId_userId_key" ON public."InboxQueueUserAssignment" USING btree ("queueId", "userId");


--
-- Name: InboxQueueUserAssignment_userId_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "InboxQueueUserAssignment_userId_isActive_idx" ON public."InboxQueueUserAssignment" USING btree ("userId", "isActive");


--
-- Name: InboxQueue_slug_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "InboxQueue_slug_key" ON public."InboxQueue" USING btree (slug);


--
-- Name: InboxSyncState_accountId_channel_folder_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "InboxSyncState_accountId_channel_folder_key" ON public."InboxSyncState" USING btree ("accountId", channel, folder);


--
-- Name: KnowledgeCandidate_conversationId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeCandidate_conversationId_createdAt_idx" ON public."KnowledgeCandidate" USING btree ("conversationId", "createdAt");


--
-- Name: KnowledgeCandidate_messageId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeCandidate_messageId_idx" ON public."KnowledgeCandidate" USING btree ("messageId");


--
-- Name: KnowledgeCandidate_observationId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "KnowledgeCandidate_observationId_key" ON public."KnowledgeCandidate" USING btree ("observationId");


--
-- Name: KnowledgeCandidate_tenantKey_dedupeHash_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeCandidate_tenantKey_dedupeHash_status_idx" ON public."KnowledgeCandidate" USING btree ("tenantKey", "dedupeHash", status);


--
-- Name: KnowledgeCandidate_tenantKey_detectedIntent_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeCandidate_tenantKey_detectedIntent_status_idx" ON public."KnowledgeCandidate" USING btree ("tenantKey", "detectedIntent", status);


--
-- Name: KnowledgeCandidate_tenantKey_scope_status_sourceType_create_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeCandidate_tenantKey_scope_status_sourceType_create_idx" ON public."KnowledgeCandidate" USING btree ("tenantKey", scope, status, "sourceType", "createdAt");


--
-- Name: KnowledgeConversationBundle_conversationId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "KnowledgeConversationBundle_conversationId_key" ON public."KnowledgeConversationBundle" USING btree ("conversationId");


--
-- Name: KnowledgeConversationBundle_tenantKey_conversationId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeConversationBundle_tenantKey_conversationId_idx" ON public."KnowledgeConversationBundle" USING btree ("tenantKey", "conversationId");


--
-- Name: KnowledgeConversationBundle_tenantKey_scope_status_updatedA_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeConversationBundle_tenantKey_scope_status_updatedA_idx" ON public."KnowledgeConversationBundle" USING btree ("tenantKey", scope, status, "updatedAt");


--
-- Name: KnowledgeDerivedArtifact_sourceDocumentId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeDerivedArtifact_sourceDocumentId_idx" ON public."KnowledgeDerivedArtifact" USING btree ("sourceDocumentId");


--
-- Name: KnowledgeDerivedArtifact_tenantKey_scope_type_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeDerivedArtifact_tenantKey_scope_type_status_idx" ON public."KnowledgeDerivedArtifact" USING btree ("tenantKey", scope, type, status);


--
-- Name: KnowledgeDocumentChunk_chunkKey_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "KnowledgeDocumentChunk_chunkKey_key" ON public."KnowledgeDocumentChunk" USING btree ("chunkKey");


--
-- Name: KnowledgeDocumentChunk_documentId_chunkIndex_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "KnowledgeDocumentChunk_documentId_chunkIndex_key" ON public."KnowledgeDocumentChunk" USING btree ("documentId", "chunkIndex");


--
-- Name: KnowledgeDocumentChunk_documentId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeDocumentChunk_documentId_idx" ON public."KnowledgeDocumentChunk" USING btree ("documentId");


--
-- Name: KnowledgeDocumentChunk_provider_model_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeDocumentChunk_provider_model_idx" ON public."KnowledgeDocumentChunk" USING btree (provider, model);


--
-- Name: KnowledgeDocumentChunk_tenantKey_scope_sourceType_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeDocumentChunk_tenantKey_scope_sourceType_idx" ON public."KnowledgeDocumentChunk" USING btree ("tenantKey", scope, "sourceType");


--
-- Name: KnowledgeDocumentEmbedding_documentId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "KnowledgeDocumentEmbedding_documentId_key" ON public."KnowledgeDocumentEmbedding" USING btree ("documentId");


--
-- Name: KnowledgeDocumentEmbedding_provider_model_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeDocumentEmbedding_provider_model_idx" ON public."KnowledgeDocumentEmbedding" USING btree (provider, model);


--
-- Name: KnowledgeDocument_tenantKey_chunkIndexStatus_updatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeDocument_tenantKey_chunkIndexStatus_updatedAt_idx" ON public."KnowledgeDocument" USING btree ("tenantKey", "chunkIndexStatus", "updatedAt");


--
-- Name: KnowledgeDocument_tenantKey_scope_sourceType_sourceKey_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "KnowledgeDocument_tenantKey_scope_sourceType_sourceKey_key" ON public."KnowledgeDocument" USING btree ("tenantKey", scope, "sourceType", "sourceKey");


--
-- Name: KnowledgeDocument_tenantKey_scope_status_sourceType_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeDocument_tenantKey_scope_status_sourceType_idx" ON public."KnowledgeDocument" USING btree ("tenantKey", scope, status, "sourceType");


--
-- Name: KnowledgeIngestionRun_createdByUserId_startedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeIngestionRun_createdByUserId_startedAt_idx" ON public."KnowledgeIngestionRun" USING btree ("createdByUserId", "startedAt");


--
-- Name: KnowledgeIngestionRun_tenantKey_status_startedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeIngestionRun_tenantKey_status_startedAt_idx" ON public."KnowledgeIngestionRun" USING btree ("tenantKey", status, "startedAt");


--
-- Name: KnowledgeNegativeExample_feedbackId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "KnowledgeNegativeExample_feedbackId_key" ON public."KnowledgeNegativeExample" USING btree ("feedbackId");


--
-- Name: KnowledgeNegativeExample_tenantKey_conversationId_updatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeNegativeExample_tenantKey_conversationId_updatedAt_idx" ON public."KnowledgeNegativeExample" USING btree ("tenantKey", "conversationId", "updatedAt");


--
-- Name: KnowledgeNegativeExample_tenantKey_scope_status_sourceKind__idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeNegativeExample_tenantKey_scope_status_sourceKind__idx" ON public."KnowledgeNegativeExample" USING btree ("tenantKey", scope, status, "sourceKind", "updatedAt");


--
-- Name: KnowledgeRawEvent_conversationId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeRawEvent_conversationId_createdAt_idx" ON public."KnowledgeRawEvent" USING btree ("conversationId", "createdAt");


--
-- Name: KnowledgeRawEvent_ingestionRunId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeRawEvent_ingestionRunId_idx" ON public."KnowledgeRawEvent" USING btree ("ingestionRunId");


--
-- Name: KnowledgeRawEvent_messageId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "KnowledgeRawEvent_messageId_key" ON public."KnowledgeRawEvent" USING btree ("messageId");


--
-- Name: KnowledgeRawEvent_tenantKey_dedupeHash_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeRawEvent_tenantKey_dedupeHash_idx" ON public."KnowledgeRawEvent" USING btree ("tenantKey", "dedupeHash");


--
-- Name: KnowledgeRawEvent_tenantKey_scope_status_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeRawEvent_tenantKey_scope_status_createdAt_idx" ON public."KnowledgeRawEvent" USING btree ("tenantKey", scope, status, "createdAt");


--
-- Name: KnowledgeSnapshotEntry_snapshotId_entryType_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeSnapshotEntry_snapshotId_entryType_idx" ON public."KnowledgeSnapshotEntry" USING btree ("snapshotId", "entryType");


--
-- Name: KnowledgeSnapshotEntry_snapshotId_key_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeSnapshotEntry_snapshotId_key_idx" ON public."KnowledgeSnapshotEntry" USING btree ("snapshotId", key);


--
-- Name: KnowledgeSnapshotEntry_tenantKey_scope_entryType_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeSnapshotEntry_tenantKey_scope_entryType_idx" ON public."KnowledgeSnapshotEntry" USING btree ("tenantKey", scope, "entryType");


--
-- Name: KnowledgeSnapshotSource_snapshotEntryId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeSnapshotSource_snapshotEntryId_idx" ON public."KnowledgeSnapshotSource" USING btree ("snapshotEntryId");


--
-- Name: KnowledgeSnapshotSource_sourceKind_sourceId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeSnapshotSource_sourceKind_sourceId_idx" ON public."KnowledgeSnapshotSource" USING btree ("sourceKind", "sourceId");


--
-- Name: KnowledgeSnapshot_tenantKey_scope_status_generatedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeSnapshot_tenantKey_scope_status_generatedAt_idx" ON public."KnowledgeSnapshot" USING btree ("tenantKey", scope, status, "generatedAt");


--
-- Name: KnowledgeSnapshot_tenantKey_scope_version_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "KnowledgeSnapshot_tenantKey_scope_version_key" ON public."KnowledgeSnapshot" USING btree ("tenantKey", scope, version);


--
-- Name: KnowledgeSuggestionFeedback_actorUserId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeSuggestionFeedback_actorUserId_createdAt_idx" ON public."KnowledgeSuggestionFeedback" USING btree ("actorUserId", "createdAt");


--
-- Name: KnowledgeSuggestionFeedback_conversationId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeSuggestionFeedback_conversationId_createdAt_idx" ON public."KnowledgeSuggestionFeedback" USING btree ("conversationId", "createdAt");


--
-- Name: KnowledgeSuggestionFeedback_operatorMessageId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeSuggestionFeedback_operatorMessageId_idx" ON public."KnowledgeSuggestionFeedback" USING btree ("operatorMessageId");


--
-- Name: KnowledgeSuggestionFeedback_targetMessageId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeSuggestionFeedback_targetMessageId_idx" ON public."KnowledgeSuggestionFeedback" USING btree ("targetMessageId");


--
-- Name: KnowledgeSuggestionFeedback_tenantKey_candidateId_outcome_c_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "KnowledgeSuggestionFeedback_tenantKey_candidateId_outcome_c_idx" ON public."KnowledgeSuggestionFeedback" USING btree ("tenantKey", "candidateId", outcome, "createdAt");


--
-- Name: OrderTimelineEvent_eventId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "OrderTimelineEvent_eventId_key" ON public."OrderTimelineEvent" USING btree ("eventId");


--
-- Name: OrderTimelineEvent_orderId_timestamp_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "OrderTimelineEvent_orderId_timestamp_idx" ON public."OrderTimelineEvent" USING btree ("orderId", "timestamp");


--
-- Name: OrderTimelineEvent_orderId_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "OrderTimelineEvent_orderId_type_idx" ON public."OrderTimelineEvent" USING btree ("orderId", type);


--
-- Name: Order_activityId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_activityId_idx" ON public."Order" USING btree ("activityId");


--
-- Name: Order_convertedOrderId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Order_convertedOrderId_key" ON public."Order" USING btree ("convertedOrderId");


--
-- Name: Order_customerId_documentType_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_customerId_documentType_date_idx" ON public."Order" USING btree ("customerId", "documentType", date);


--
-- Name: Order_documentType_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_documentType_createdAt_idx" ON public."Order" USING btree ("documentType", "createdAt");


--
-- Name: Order_documentType_statusId_customerId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_documentType_statusId_customerId_createdAt_idx" ON public."Order" USING btree ("documentType", "statusId", "customerId", "createdAt");


--
-- Name: Order_originId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Order_originId_key" ON public."Order" USING btree ("originId");


--
-- Name: Order_session_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_session_id_idx" ON public."Order" USING btree (session_id);


--
-- Name: Order_utm_source_utm_campaign_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_utm_source_utm_campaign_idx" ON public."Order" USING btree (utm_source, utm_campaign);


--
-- Name: Order_uuid_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Order_uuid_key" ON public."Order" USING btree (uuid);


--
-- Name: Order_validUntil_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Order_validUntil_idx" ON public."Order" USING btree ("validUntil");


--
-- Name: PasswordResetToken_channel_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PasswordResetToken_channel_idx" ON public."PasswordResetToken" USING btree (channel);


--
-- Name: PasswordResetToken_customerId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PasswordResetToken_customerId_idx" ON public."PasswordResetToken" USING btree ("customerId");


--
-- Name: PasswordResetToken_expiresAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PasswordResetToken_expiresAt_idx" ON public."PasswordResetToken" USING btree ("expiresAt");


--
-- Name: PasswordResetToken_tokenHash_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PasswordResetToken_tokenHash_key" ON public."PasswordResetToken" USING btree ("tokenHash");


--
-- Name: PasswordResetToken_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PasswordResetToken_userId_idx" ON public."PasswordResetToken" USING btree ("userId");


--
-- Name: PaymentPlanMilestone_paymentPlanId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PaymentPlanMilestone_paymentPlanId_idx" ON public."PaymentPlanMilestone" USING btree ("paymentPlanId");


--
-- Name: PaymentPlan_orderId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PaymentPlan_orderId_key" ON public."PaymentPlan" USING btree ("orderId");


--
-- Name: Payment_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Payment_orderId_idx" ON public."Payment" USING btree ("orderId");


--
-- Name: Payment_orderId_reference_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Payment_orderId_reference_key" ON public."Payment" USING btree ("orderId", reference);


--
-- Name: Payment_orderId_status_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Payment_orderId_status_date_idx" ON public."Payment" USING btree ("orderId", status, date);


--
-- Name: Payment_paymentMethodId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Payment_paymentMethodId_idx" ON public."Payment" USING btree ("paymentMethodId");


--
-- Name: Payment_status_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Payment_status_type_idx" ON public."Payment" USING btree (status, type);


--
-- Name: ProductCategory_installServiceProductId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductCategory_installServiceProductId_key" ON public."ProductCategory" USING btree ("installServiceProductId");


--
-- Name: ProductCategory_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductCategory_name_key" ON public."ProductCategory" USING btree (name);


--
-- Name: ProductCategory_parentId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductCategory_parentId_idx" ON public."ProductCategory" USING btree ("parentId");


--
-- Name: ProductImage_productId_variantId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductImage_productId_variantId_idx" ON public."ProductImage" USING btree ("productId", "variantId");


--
-- Name: ProductOptionValue_optionId_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductOptionValue_optionId_code_key" ON public."ProductOptionValue" USING btree ("optionId", code);


--
-- Name: ProductOptionValue_optionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductOptionValue_optionId_idx" ON public."ProductOptionValue" USING btree ("optionId");


--
-- Name: ProductOption_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductOption_productId_idx" ON public."ProductOption" USING btree ("productId");


--
-- Name: ProductOption_productId_type_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductOption_productId_type_key" ON public."ProductOption" USING btree ("productId", type);


--
-- Name: ProductRelation_productId_relatedProductId_type_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductRelation_productId_relatedProductId_type_key" ON public."ProductRelation" USING btree ("productId", "relatedProductId", type);


--
-- Name: ProductRelation_productId_type_isActive_sortOrder_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductRelation_productId_type_isActive_sortOrder_idx" ON public."ProductRelation" USING btree ("productId", type, "isActive", "sortOrder");


--
-- Name: ProductRelation_relatedProductId_type_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductRelation_relatedProductId_type_isActive_idx" ON public."ProductRelation" USING btree ("relatedProductId", type, "isActive");


--
-- Name: ProductReview_customerId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductReview_customerId_createdAt_idx" ON public."ProductReview" USING btree ("customerId", "createdAt");


--
-- Name: ProductReview_orderItemId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductReview_orderItemId_idx" ON public."ProductReview" USING btree ("orderItemId");


--
-- Name: ProductReview_orderItemId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductReview_orderItemId_key" ON public."ProductReview" USING btree ("orderItemId");


--
-- Name: ProductReview_productId_status_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductReview_productId_status_createdAt_idx" ON public."ProductReview" USING btree ("productId", status, "createdAt");


--
-- Name: ProductVariantSelection_optionValueId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductVariantSelection_optionValueId_idx" ON public."ProductVariantSelection" USING btree ("optionValueId");


--
-- Name: ProductVariant_productId_combinationKey_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductVariant_productId_combinationKey_key" ON public."ProductVariant" USING btree ("productId", "combinationKey");


--
-- Name: ProductVariant_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductVariant_productId_idx" ON public."ProductVariant" USING btree ("productId");


--
-- Name: ProductVariant_productId_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductVariant_productId_isActive_idx" ON public."ProductVariant" USING btree ("productId", "isActive");


--
-- Name: ProductVariant_productId_key_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductVariant_productId_key_key" ON public."ProductVariant" USING btree ("productId", key);


--
-- Name: Product_installServiceProductId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Product_installServiceProductId_idx" ON public."Product" USING btree ("installServiceProductId");


--
-- Name: ProductionOrder_assignedToId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductionOrder_assignedToId_idx" ON public."ProductionOrder" USING btree ("assignedToId");


--
-- Name: ProductionOrder_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductionOrder_orderId_idx" ON public."ProductionOrder" USING btree ("orderId");


--
-- Name: ProductionOrder_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductionOrder_status_idx" ON public."ProductionOrder" USING btree (status);


--
-- Name: ProductionOrder_workOrderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductionOrder_workOrderId_idx" ON public."ProductionOrder" USING btree ("workOrderId");


--
-- Name: ProductionOrder_workOrderId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductionOrder_workOrderId_key" ON public."ProductionOrder" USING btree ("workOrderId");


--
-- Name: ShippingOption_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ShippingOption_name_key" ON public."ShippingOption" USING btree (name);


--
-- Name: StandardSize_isActive_sortOrder_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "StandardSize_isActive_sortOrder_idx" ON public."StandardSize" USING btree ("isActive", "sortOrder");


--
-- Name: StandardSize_width_height_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "StandardSize_width_height_key" ON public."StandardSize" USING btree (width, height);


--
-- Name: StorefrontOAuthSession_expiresAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "StorefrontOAuthSession_expiresAt_idx" ON public."StorefrontOAuthSession" USING btree ("expiresAt");


--
-- Name: StorefrontOAuthSession_state_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "StorefrontOAuthSession_state_key" ON public."StorefrontOAuthSession" USING btree (state);


--
-- Name: StorefrontPaymentIntent_cartId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "StorefrontPaymentIntent_cartId_idx" ON public."StorefrontPaymentIntent" USING btree ("cartId");


--
-- Name: StorefrontPaymentIntent_externalPaymentId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "StorefrontPaymentIntent_externalPaymentId_idx" ON public."StorefrontPaymentIntent" USING btree ("externalPaymentId");


--
-- Name: StorefrontPaymentIntent_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "StorefrontPaymentIntent_orderId_idx" ON public."StorefrontPaymentIntent" USING btree ("orderId");


--
-- Name: StorefrontPaymentIntent_payerEmail_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "StorefrontPaymentIntent_payerEmail_idx" ON public."StorefrontPaymentIntent" USING btree ("payerEmail");


--
-- Name: StorefrontPaymentIntent_provider_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "StorefrontPaymentIntent_provider_status_idx" ON public."StorefrontPaymentIntent" USING btree (provider, status);


--
-- Name: StorefrontPaymentIntent_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "StorefrontPaymentIntent_status_idx" ON public."StorefrontPaymentIntent" USING btree (status);


--
-- Name: StoryItem_storyId_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "StoryItem_storyId_order_idx" ON public."StoryItem" USING btree ("storyId", "order");


--
-- Name: StoryItem_storyId_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "StoryItem_storyId_type_idx" ON public."StoryItem" USING btree ("storyId", type);


--
-- Name: Story_isActive_startsAt_endsAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Story_isActive_startsAt_endsAt_idx" ON public."Story" USING btree ("isActive", "startsAt", "endsAt");


--
-- Name: Story_slug_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Story_slug_key" ON public."Story" USING btree (slug);


--
-- Name: UserDevice_fingerprint_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "UserDevice_fingerprint_key" ON public."UserDevice" USING btree (fingerprint);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_phone_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_phone_key" ON public."User" USING btree (phone);


--
-- Name: WishlistItem_wishlistId_productId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "WishlistItem_wishlistId_productId_key" ON public."WishlistItem" USING btree ("wishlistId", "productId");


--
-- Name: Wishlist_customerId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Wishlist_customerId_key" ON public."Wishlist" USING btree ("customerId");


--
-- Name: WorkOrder_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "WorkOrder_code_key" ON public."WorkOrder" USING btree (code);


--
-- Name: WorkOrder_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "WorkOrder_orderId_idx" ON public."WorkOrder" USING btree ("orderId");


--
-- Name: WorkOrder_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "WorkOrder_status_idx" ON public."WorkOrder" USING btree (status);


--
-- Name: abertura_glossary_category_label; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX abertura_glossary_category_label ON public.abertura_glossary_items USING btree (category, label);


--
-- Name: abertura_glossary_items_category_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX abertura_glossary_items_category_idx ON public.abertura_glossary_items USING btree (category);


--
-- Name: analytics_ads_daily_metrics_campaign_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_ads_daily_metrics_campaign_idx ON public.analytics_ads_daily_metrics USING btree (campaign);


--
-- Name: analytics_ads_daily_metrics_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_ads_daily_metrics_date_idx ON public.analytics_ads_daily_metrics USING btree (date);


--
-- Name: analytics_ads_daily_metrics_natural_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX analytics_ads_daily_metrics_natural_key ON public.analytics_ads_daily_metrics USING btree (date, campaign);


--
-- Name: analytics_ai_insights_date_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_ai_insights_date_created_at_idx ON public.analytics_ai_insights USING btree (date, created_at);


--
-- Name: analytics_baseline_checks_comparison_kind_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_baseline_checks_comparison_kind_created_at_idx ON public.analytics_baseline_checks USING btree (comparison_kind, created_at);


--
-- Name: analytics_baseline_checks_snapshot_group_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_baseline_checks_snapshot_group_created_at_idx ON public.analytics_baseline_checks USING btree (snapshot_group, created_at);


--
-- Name: analytics_baseline_checks_source_metric_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_baseline_checks_source_metric_date_idx ON public.analytics_baseline_checks USING btree (source, metric, date);


--
-- Name: analytics_baseline_snapshots_natural_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX analytics_baseline_snapshots_natural_key ON public.analytics_baseline_snapshots USING btree (connection_id, source, report_key, date, metric_name, dimension_hash, query_hash);


--
-- Name: analytics_baseline_snapshots_query_hash_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_baseline_snapshots_query_hash_idx ON public.analytics_baseline_snapshots USING btree (query_hash);


--
-- Name: analytics_baseline_snapshots_report_key_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_baseline_snapshots_report_key_date_idx ON public.analytics_baseline_snapshots USING btree (report_key, date);


--
-- Name: analytics_baseline_snapshots_source_metric_name_origin_snapshot; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_baseline_snapshots_source_metric_name_origin_snapshot ON public.analytics_baseline_snapshots USING btree (source, metric_name, origin, snapshot_group, date);


--
-- Name: analytics_data_anomalies_source_detected_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_data_anomalies_source_detected_at_idx ON public.analytics_data_anomalies USING btree (source, detected_at);


--
-- Name: analytics_data_anomalies_type_severity_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_data_anomalies_type_severity_idx ON public.analytics_data_anomalies USING btree (type, severity);


--
-- Name: analytics_data_parity_checks_snapshot_group_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_data_parity_checks_snapshot_group_created_at_idx ON public.analytics_data_parity_checks USING btree (snapshot_group, created_at);


--
-- Name: analytics_data_parity_checks_source_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_data_parity_checks_source_status_idx ON public.analytics_data_parity_checks USING btree (source, status);


--
-- Name: analytics_data_quality_checks_connection_report_date_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_data_quality_checks_connection_report_date_status_idx ON public.analytics_data_quality_checks USING btree (connection_id, report_key, date, status);


--
-- Name: analytics_data_quality_checks_natural_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX analytics_data_quality_checks_natural_key ON public.analytics_data_quality_checks USING btree (connection_id, report_key, date, metric_name, dimension_hash, query_hash);


--
-- Name: analytics_data_quality_checks_query_hash_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_data_quality_checks_query_hash_idx ON public.analytics_data_quality_checks USING btree (query_hash);


--
-- Name: analytics_data_quality_checks_sync_run_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_data_quality_checks_sync_run_id_idx ON public.analytics_data_quality_checks USING btree (sync_run_id);


--
-- Name: analytics_data_trust_checks_check_name_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_data_trust_checks_check_name_created_at_idx ON public.analytics_data_trust_checks USING btree (check_name, created_at);


--
-- Name: analytics_data_trust_checks_environment_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_data_trust_checks_environment_created_at_idx ON public.analytics_data_trust_checks USING btree (environment, created_at);


--
-- Name: analytics_endpoint_usage_endpoint_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_endpoint_usage_endpoint_created_at_idx ON public.analytics_endpoint_usage USING btree (endpoint, created_at);


--
-- Name: analytics_endpoint_usage_status_code_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_endpoint_usage_status_code_created_at_idx ON public.analytics_endpoint_usage USING btree (status_code, created_at);


--
-- Name: analytics_endpoint_usage_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_endpoint_usage_user_id_created_at_idx ON public.analytics_endpoint_usage USING btree (user_id, created_at);


--
-- Name: analytics_event_comparisons_comparison_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_event_comparisons_comparison_date_idx ON public.analytics_event_comparisons USING btree (comparison_date);


--
-- Name: analytics_event_comparisons_tenant_id_event_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX analytics_event_comparisons_tenant_id_event_id_key ON public.analytics_event_comparisons USING btree (tenant_id, event_id);


--
-- Name: analytics_event_comparisons_tenant_id_event_name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_event_comparisons_tenant_id_event_name_idx ON public.analytics_event_comparisons USING btree (tenant_id, event_name);


--
-- Name: analytics_event_comparisons_tenant_id_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_event_comparisons_tenant_id_status_idx ON public.analytics_event_comparisons USING btree (tenant_id, status);


--
-- Name: analytics_export_runs_export_type_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_export_runs_export_type_created_at_idx ON public.analytics_export_runs USING btree (export_type, created_at);


--
-- Name: analytics_export_runs_source_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_export_runs_source_created_at_idx ON public.analytics_export_runs USING btree (source, created_at);


--
-- Name: analytics_export_runs_status_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_export_runs_status_created_at_idx ON public.analytics_export_runs USING btree (status, created_at);


--
-- Name: analytics_ga4_daily_metrics_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_ga4_daily_metrics_date_idx ON public.analytics_ga4_daily_metrics USING btree (date);


--
-- Name: analytics_ga4_daily_metrics_natural_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX analytics_ga4_daily_metrics_natural_key ON public.analytics_ga4_daily_metrics USING btree (date, source, medium, campaign);


--
-- Name: analytics_ga4_daily_metrics_source_campaign_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_ga4_daily_metrics_source_campaign_idx ON public.analytics_ga4_daily_metrics USING btree (source, campaign);


--
-- Name: analytics_health_alert_state_environment_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX analytics_health_alert_state_environment_key ON public.analytics_health_alert_state USING btree (environment);


--
-- Name: analytics_health_checks_environment_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_health_checks_environment_created_at_idx ON public.analytics_health_checks USING btree (environment, created_at);


--
-- Name: analytics_health_checks_status_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_health_checks_status_created_at_idx ON public.analytics_health_checks USING btree (status, created_at);


--
-- Name: analytics_insights_history_date_insight_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_insights_history_date_insight_type_idx ON public.analytics_insights_history USING btree (date, insight_type);


--
-- Name: analytics_insights_history_source_report_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_insights_history_source_report_created_at_idx ON public.analytics_insights_history USING btree (source_report, created_at);


--
-- Name: analytics_insights_impact_confidence_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_insights_impact_confidence_idx ON public.analytics_insights USING btree (impact, confidence);


--
-- Name: analytics_insights_source_metric_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_insights_source_metric_status_idx ON public.analytics_insights USING btree (source, metric, status);


--
-- Name: analytics_report_reconciliations_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_report_reconciliations_created_at_idx ON public.analytics_report_reconciliations USING btree (created_at);


--
-- Name: analytics_report_reconciliations_report_key_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_report_reconciliations_report_key_status_idx ON public.analytics_report_reconciliations USING btree (report_key, status);


--
-- Name: analytics_report_rows_report_key_source_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_report_rows_report_key_source_idx ON public.analytics_report_rows USING btree (report_key, source);


--
-- Name: analytics_report_rows_report_run_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_report_rows_report_run_id_idx ON public.analytics_report_rows USING btree (report_run_id);


--
-- Name: analytics_report_rows_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX analytics_report_rows_unique ON public.analytics_report_rows USING btree (report_run_id, row_key, source);


--
-- Name: analytics_reporting_daily_channel_campaign_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_reporting_daily_channel_campaign_idx ON public.analytics_reporting_daily USING btree (channel, campaign);


--
-- Name: analytics_reporting_daily_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_reporting_daily_date_idx ON public.analytics_reporting_daily USING btree (date);


--
-- Name: analytics_reporting_daily_natural_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX analytics_reporting_daily_natural_key ON public.analytics_reporting_daily USING btree (date, channel, source, medium, campaign, product_id, landing_page, device, country);


--
-- Name: analytics_search_console_daily_metrics_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_search_console_daily_metrics_date_idx ON public.analytics_search_console_daily_metrics USING btree (date);


--
-- Name: analytics_search_console_daily_metrics_natural_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX analytics_search_console_daily_metrics_natural_key ON public.analytics_search_console_daily_metrics USING btree (date, query, page);


--
-- Name: analytics_search_console_daily_metrics_query_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_search_console_daily_metrics_query_idx ON public.analytics_search_console_daily_metrics USING btree (query);


--
-- Name: analytics_usage_events_endpoint_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_usage_events_endpoint_created_at_idx ON public.analytics_usage_events USING btree (endpoint, created_at);


--
-- Name: analytics_usage_events_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_usage_events_user_id_created_at_idx ON public.analytics_usage_events USING btree (user_id, created_at);


--
-- Name: dimension_price_matrix_productId_fingerprint_option_state_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "dimension_price_matrix_productId_fingerprint_option_state_key" ON public.dimension_price_matrix USING btree ("productId", fingerprint, option_state);


--
-- Name: dimension_price_matrix_productId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "dimension_price_matrix_productId_idx" ON public.dimension_price_matrix USING btree ("productId");


--
-- Name: event_facts_conversion_flag_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_facts_conversion_flag_idx ON public.event_facts USING btree (conversion_flag);


--
-- Name: event_facts_event_category_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_facts_event_category_idx ON public.event_facts USING btree (event_category);


--
-- Name: event_facts_event_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_facts_event_id_idx ON public.event_facts USING btree (event_id);


--
-- Name: event_facts_event_name_event_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_facts_event_name_event_date_idx ON public.event_facts USING btree (event_name, event_date);


--
-- Name: event_facts_measurement_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_facts_measurement_status_idx ON public.event_facts USING btree (measurement_status);


--
-- Name: event_facts_session_id_event_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_facts_session_id_event_date_idx ON public.event_facts USING btree (session_id, event_date);


--
-- Name: event_facts_source_event_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX event_facts_source_event_id_key ON public.event_facts USING btree (source_event_id);


--
-- Name: event_facts_source_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_facts_source_idx ON public.event_facts USING btree (source);


--
-- Name: event_facts_tenant_id_component_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_facts_tenant_id_component_id_idx ON public.event_facts USING btree (tenant_id, component_id);


--
-- Name: event_facts_tenant_id_cta_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_facts_tenant_id_cta_id_idx ON public.event_facts USING btree (tenant_id, cta_id);


--
-- Name: event_facts_tenant_id_event_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_facts_tenant_id_event_date_idx ON public.event_facts USING btree (tenant_id, event_date);


--
-- Name: event_facts_tenant_id_event_name_event_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_facts_tenant_id_event_name_event_date_idx ON public.event_facts USING btree (tenant_id, event_name, event_date);


--
-- Name: event_facts_utm_source_utm_campaign_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX event_facts_utm_source_utm_campaign_idx ON public.event_facts USING btree (utm_source, utm_campaign);


--
-- Name: events_conversion_flag_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_conversion_flag_idx ON public.events USING btree (conversion_flag);


--
-- Name: events_correlation_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_correlation_id_idx ON public.events USING btree (correlation_id);


--
-- Name: events_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "events_createdAt_idx" ON public.events USING btree ("createdAt");


--
-- Name: events_event_category_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_event_category_idx ON public.events USING btree (event_category);


--
-- Name: events_event_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_event_id_idx ON public.events USING btree (event_id);


--
-- Name: events_event_name_timestamp_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_event_name_timestamp_idx ON public.events USING btree (event_name, "timestamp");


--
-- Name: events_measurement_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_measurement_status_idx ON public.events USING btree (measurement_status);


--
-- Name: events_meta_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_meta_status_idx ON public.events USING btree (meta_status);


--
-- Name: events_processed_timestamp_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_processed_timestamp_idx ON public.events USING btree (processed, "timestamp");


--
-- Name: events_session_id_timestamp_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_session_id_timestamp_idx ON public.events USING btree (session_id, "timestamp");


--
-- Name: events_source_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_source_idx ON public.events USING btree (source);


--
-- Name: events_tenant_id_component_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_tenant_id_component_id_idx ON public.events USING btree (tenant_id, component_id);


--
-- Name: events_tenant_id_cta_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_tenant_id_cta_id_idx ON public.events USING btree (tenant_id, cta_id);


--
-- Name: events_tenant_id_event_name_timestamp_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_tenant_id_event_name_timestamp_idx ON public.events USING btree (tenant_id, event_name, "timestamp");


--
-- Name: events_tenant_id_timestamp_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_tenant_id_timestamp_idx ON public.events USING btree (tenant_id, "timestamp");


--
-- Name: notification_customer_audience_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_customer_audience_created_at_idx ON public."Notification" USING btree ("customerId", audience, "createdAt");


--
-- Name: notification_customer_read_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_customer_read_at_idx ON public."Notification" USING btree ("customerId", "readAt");


--
-- Name: notification_event_audience_channel_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_event_audience_channel_idx ON public."Notification" USING btree ("eventType", audience, channel);


--
-- Name: notification_idempotency_key_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX notification_idempotency_key_unique ON public."Notification" USING btree ("idempotencyKey");


--
-- Name: notification_order_id_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_order_id_id_idx ON public."Notification" USING btree ("orderId", id);


--
-- Name: notification_recipient_audience_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_recipient_audience_created_at_idx ON public."Notification" USING btree ("recipientId", audience, "createdAt");


--
-- Name: notification_recipient_read_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_recipient_read_at_idx ON public."Notification" USING btree ("recipientId", "readAt");


--
-- Name: notification_settings_event_channel_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX notification_settings_event_channel_unique ON public."NotificationSetting" USING btree ("eventType", audience, channel);


--
-- Name: order_timeline_order_timestamp_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX order_timeline_order_timestamp_id_idx ON public."OrderTimelineEvent" USING btree ("orderId", "timestamp", id);


--
-- Name: otp_codes_expiresAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "otp_codes_expiresAt_idx" ON public.otp_codes USING btree ("expiresAt");


--
-- Name: otp_codes_target_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX otp_codes_target_idx ON public.otp_codes USING btree (target);


--
-- Name: otp_codes_userId_type_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "otp_codes_userId_type_createdAt_idx" ON public.otp_codes USING btree ("userId", type, "createdAt");


--
-- Name: parametric_compatibility_rules_productId_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "parametric_compatibility_rules_productId_type_idx" ON public.parametric_compatibility_rules USING btree ("productId", type);


--
-- Name: parametric_compatibility_rules_productId_type_ruleKey_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "parametric_compatibility_rules_productId_type_ruleKey_key" ON public.parametric_compatibility_rules USING btree ("productId", type, "ruleKey");


--
-- Name: parametric_matrix_staging_productId_processedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "parametric_matrix_staging_productId_processedAt_idx" ON public.parametric_matrix_staging USING btree ("productId", "processedAt");


--
-- Name: security_events_eventType_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "security_events_eventType_createdAt_idx" ON public.security_events USING btree ("eventType", "createdAt");


--
-- Name: security_events_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "security_events_userId_createdAt_idx" ON public.security_events USING btree ("userId", "createdAt");


--
-- Name: setting_environment_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX setting_environment_idx ON public."Setting" USING btree (environment);


--
-- Name: setting_key_environment_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX setting_key_environment_unique ON public."Setting" USING btree (key, environment);


--
-- Name: ActivityTicketMember ActivityTicketMember_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ActivityTicketMember"
    ADD CONSTRAINT "ActivityTicketMember_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."ActivityTicket"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ActivityTicketMember ActivityTicketMember_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ActivityTicketMember"
    ADD CONSTRAINT "ActivityTicketMember_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ActivityTicket ActivityTicket_columnId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ActivityTicket"
    ADD CONSTRAINT "ActivityTicket_columnId_fkey" FOREIGN KEY ("columnId") REFERENCES public."ActivityColumn"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CalendarEventAttachment CalendarEventAttachment_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CalendarEventAttachment"
    ADD CONSTRAINT "CalendarEventAttachment_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public."CalendarEvent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CalendarEventComment CalendarEventComment_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CalendarEventComment"
    ADD CONSTRAINT "CalendarEventComment_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public."CalendarEvent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CalendarEventComment CalendarEventComment_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CalendarEventComment"
    ADD CONSTRAINT "CalendarEventComment_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CalendarEvent CalendarEvent_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CalendarEvent"
    ADD CONSTRAINT "CalendarEvent_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CalendarEvent CalendarEvent_eventTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CalendarEvent"
    ADD CONSTRAINT "CalendarEvent_eventTypeId_fkey" FOREIGN KEY ("eventTypeId") REFERENCES public."CalendarEventType"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CalendarEvent CalendarEvent_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CalendarEvent"
    ADD CONSTRAINT "CalendarEvent_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CalendarEvent CalendarEvent_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CalendarEvent"
    ADD CONSTRAINT "CalendarEvent_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public."Task"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CanonicalConfiguration CanonicalConfiguration_baseProductId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CanonicalConfiguration"
    ADD CONSTRAINT "CanonicalConfiguration_baseProductId_fkey" FOREIGN KEY ("baseProductId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CmsEntryAsset CmsEntryAsset_entryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsEntryAsset"
    ADD CONSTRAINT "CmsEntryAsset_entryId_fkey" FOREIGN KEY ("entryId") REFERENCES public."CmsEntry"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CmsEntry CmsEntry_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsEntry"
    ADD CONSTRAINT "CmsEntry_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."ProductCategory"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CmsEntry CmsEntry_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsEntry"
    ADD CONSTRAINT "CmsEntry_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CmsEntry CmsEntry_sectionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsEntry"
    ADD CONSTRAINT "CmsEntry_sectionId_fkey" FOREIGN KEY ("sectionId") REFERENCES public."CmsSection"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CmsPageAlias CmsPageAlias_pageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsPageAlias"
    ADD CONSTRAINT "CmsPageAlias_pageId_fkey" FOREIGN KEY ("pageId") REFERENCES public."CmsPage"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CmsPageBlock CmsPageBlock_mediaId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsPageBlock"
    ADD CONSTRAINT "CmsPageBlock_mediaId_fkey" FOREIGN KEY ("mediaId") REFERENCES public."CmsMedia"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CmsPageBlock CmsPageBlock_sectionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsPageBlock"
    ADD CONSTRAINT "CmsPageBlock_sectionId_fkey" FOREIGN KEY ("sectionId") REFERENCES public."CmsPageSection"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CmsPageSection CmsPageSection_pageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CmsPageSection"
    ADD CONSTRAINT "CmsPageSection_pageId_fkey" FOREIGN KEY ("pageId") REFERENCES public."CmsPage"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ConversationExternalIdentity ConversationExternalIdentity_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConversationExternalIdentity"
    ADD CONSTRAINT "ConversationExternalIdentity_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ConversationHandoffEvent ConversationHandoffEvent_actorUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConversationHandoffEvent"
    ADD CONSTRAINT "ConversationHandoffEvent_actorUserId_fkey" FOREIGN KEY ("actorUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ConversationHandoffEvent ConversationHandoffEvent_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConversationHandoffEvent"
    ADD CONSTRAINT "ConversationHandoffEvent_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ConversationMessage ConversationMessage_authorCustomerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConversationMessage"
    ADD CONSTRAINT "ConversationMessage_authorCustomerId_fkey" FOREIGN KEY ("authorCustomerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ConversationMessage ConversationMessage_authorUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConversationMessage"
    ADD CONSTRAINT "ConversationMessage_authorUserId_fkey" FOREIGN KEY ("authorUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ConversationMessage ConversationMessage_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConversationMessage"
    ADD CONSTRAINT "ConversationMessage_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ConversationMessage ConversationMessage_inboxMessageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConversationMessage"
    ADD CONSTRAINT "ConversationMessage_inboxMessageId_fkey" FOREIGN KEY ("inboxMessageId") REFERENCES public."InboxMessage"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ConversationParticipant ConversationParticipant_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConversationParticipant"
    ADD CONSTRAINT "ConversationParticipant_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ConversationParticipant ConversationParticipant_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConversationParticipant"
    ADD CONSTRAINT "ConversationParticipant_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ConversationParticipant ConversationParticipant_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConversationParticipant"
    ADD CONSTRAINT "ConversationParticipant_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ConversationReadState ConversationReadState_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConversationReadState"
    ADD CONSTRAINT "ConversationReadState_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ConversationReadState ConversationReadState_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConversationReadState"
    ADD CONSTRAINT "ConversationReadState_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ConversationToolCall ConversationToolCall_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConversationToolCall"
    ADD CONSTRAINT "ConversationToolCall_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ConversationToolCall ConversationToolCall_messageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConversationToolCall"
    ADD CONSTRAINT "ConversationToolCall_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES public."ConversationMessage"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ConversationToolCall ConversationToolCall_requestedByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConversationToolCall"
    ADD CONSTRAINT "ConversationToolCall_requestedByUserId_fkey" FOREIGN KEY ("requestedByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Conversation Conversation_assignedToUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_assignedToUserId_fkey" FOREIGN KEY ("assignedToUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Conversation Conversation_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Conversation Conversation_inboxAccountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_inboxAccountId_fkey" FOREIGN KEY ("inboxAccountId") REFERENCES public."InboxAccount"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CustomerAddress CustomerAddress_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerAddress"
    ADD CONSTRAINT "CustomerAddress_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CustomerEmailVerificationToken CustomerEmailVerificationToken_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerEmailVerificationToken"
    ADD CONSTRAINT "CustomerEmailVerificationToken_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CustomerOAuthAccount CustomerOAuthAccount_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerOAuthAccount"
    ADD CONSTRAINT "CustomerOAuthAccount_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CustomerOtpChallenge CustomerOtpChallenge_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerOtpChallenge"
    ADD CONSTRAINT "CustomerOtpChallenge_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CustomerPhone CustomerPhone_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerPhone"
    ADD CONSTRAINT "CustomerPhone_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CustomerReauthToken CustomerReauthToken_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerReauthToken"
    ADD CONSTRAINT "CustomerReauthToken_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CustomerSecurityEvent CustomerSecurityEvent_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CustomerSecurityEvent"
    ADD CONSTRAINT "CustomerSecurityEvent_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Customer Customer_statusId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Customer"
    ADD CONSTRAINT "Customer_statusId_fkey" FOREIGN KEY ("statusId") REFERENCES public."CustomerStatus"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: EmailLog EmailLog_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmailLog"
    ADD CONSTRAINT "EmailLog_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public."EmailTemplate"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ExpenseAttachment ExpenseAttachment_expenseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExpenseAttachment"
    ADD CONSTRAINT "ExpenseAttachment_expenseId_fkey" FOREIGN KEY ("expenseId") REFERENCES public."Expense"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Expense Expense_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Expense"
    ADD CONSTRAINT "Expense_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."ExpenseCategory"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Expense Expense_statusId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Expense"
    ADD CONSTRAINT "Expense_statusId_fkey" FOREIGN KEY ("statusId") REFERENCES public."ExpenseStatus"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: InboxAttachment InboxAttachment_messageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InboxAttachment"
    ADD CONSTRAINT "InboxAttachment_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES public."InboxMessage"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: InboxMessageEvent InboxMessageEvent_messageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InboxMessageEvent"
    ADD CONSTRAINT "InboxMessageEvent_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES public."InboxMessage"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: InboxMessage InboxMessage_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InboxMessage"
    ADD CONSTRAINT "InboxMessage_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public."InboxAccount"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: InboxMessage InboxMessage_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InboxMessage"
    ADD CONSTRAINT "InboxMessage_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."InboxQueue"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: InboxQueueUserAssignment InboxQueueUserAssignment_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InboxQueueUserAssignment"
    ADD CONSTRAINT "InboxQueueUserAssignment_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."InboxQueue"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: InboxQueueUserAssignment InboxQueueUserAssignment_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InboxQueueUserAssignment"
    ADD CONSTRAINT "InboxQueueUserAssignment_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: InboxSyncState InboxSyncState_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InboxSyncState"
    ADD CONSTRAINT "InboxSyncState_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public."InboxAccount"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: KnowledgeCandidate KnowledgeCandidate_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeCandidate"
    ADD CONSTRAINT "KnowledgeCandidate_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: KnowledgeCandidate KnowledgeCandidate_createdByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeCandidate"
    ADD CONSTRAINT "KnowledgeCandidate_createdByUserId_fkey" FOREIGN KEY ("createdByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: KnowledgeCandidate KnowledgeCandidate_messageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeCandidate"
    ADD CONSTRAINT "KnowledgeCandidate_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES public."ConversationMessage"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: KnowledgeCandidate KnowledgeCandidate_observationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeCandidate"
    ADD CONSTRAINT "KnowledgeCandidate_observationId_fkey" FOREIGN KEY ("observationId") REFERENCES public."KnowledgeRawEvent"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: KnowledgeCandidate KnowledgeCandidate_reviewedByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeCandidate"
    ADD CONSTRAINT "KnowledgeCandidate_reviewedByUserId_fkey" FOREIGN KEY ("reviewedByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: KnowledgeConversationBundle KnowledgeConversationBundle_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeConversationBundle"
    ADD CONSTRAINT "KnowledgeConversationBundle_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: KnowledgeConversationBundle KnowledgeConversationBundle_createdByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeConversationBundle"
    ADD CONSTRAINT "KnowledgeConversationBundle_createdByUserId_fkey" FOREIGN KEY ("createdByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: KnowledgeConversationBundle KnowledgeConversationBundle_reviewedByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeConversationBundle"
    ADD CONSTRAINT "KnowledgeConversationBundle_reviewedByUserId_fkey" FOREIGN KEY ("reviewedByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: KnowledgeDerivedArtifact KnowledgeDerivedArtifact_sourceDocumentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeDerivedArtifact"
    ADD CONSTRAINT "KnowledgeDerivedArtifact_sourceDocumentId_fkey" FOREIGN KEY ("sourceDocumentId") REFERENCES public."KnowledgeDocument"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: KnowledgeDocumentChunk KnowledgeDocumentChunk_documentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeDocumentChunk"
    ADD CONSTRAINT "KnowledgeDocumentChunk_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES public."KnowledgeDocument"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: KnowledgeDocumentEmbedding KnowledgeDocumentEmbedding_documentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeDocumentEmbedding"
    ADD CONSTRAINT "KnowledgeDocumentEmbedding_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES public."KnowledgeDocument"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: KnowledgeDocument KnowledgeDocument_approvedByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeDocument"
    ADD CONSTRAINT "KnowledgeDocument_approvedByUserId_fkey" FOREIGN KEY ("approvedByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: KnowledgeDocument KnowledgeDocument_authoredByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeDocument"
    ADD CONSTRAINT "KnowledgeDocument_authoredByUserId_fkey" FOREIGN KEY ("authoredByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: KnowledgeIngestionRun KnowledgeIngestionRun_createdByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeIngestionRun"
    ADD CONSTRAINT "KnowledgeIngestionRun_createdByUserId_fkey" FOREIGN KEY ("createdByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: KnowledgeNegativeExample KnowledgeNegativeExample_candidateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeNegativeExample"
    ADD CONSTRAINT "KnowledgeNegativeExample_candidateId_fkey" FOREIGN KEY ("candidateId") REFERENCES public."KnowledgeCandidate"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: KnowledgeNegativeExample KnowledgeNegativeExample_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeNegativeExample"
    ADD CONSTRAINT "KnowledgeNegativeExample_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: KnowledgeNegativeExample KnowledgeNegativeExample_createdByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeNegativeExample"
    ADD CONSTRAINT "KnowledgeNegativeExample_createdByUserId_fkey" FOREIGN KEY ("createdByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: KnowledgeNegativeExample KnowledgeNegativeExample_feedbackId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeNegativeExample"
    ADD CONSTRAINT "KnowledgeNegativeExample_feedbackId_fkey" FOREIGN KEY ("feedbackId") REFERENCES public."KnowledgeSuggestionFeedback"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: KnowledgeNegativeExample KnowledgeNegativeExample_reviewedByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeNegativeExample"
    ADD CONSTRAINT "KnowledgeNegativeExample_reviewedByUserId_fkey" FOREIGN KEY ("reviewedByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: KnowledgeRawEvent KnowledgeRawEvent_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeRawEvent"
    ADD CONSTRAINT "KnowledgeRawEvent_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: KnowledgeRawEvent KnowledgeRawEvent_ingestionRunId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeRawEvent"
    ADD CONSTRAINT "KnowledgeRawEvent_ingestionRunId_fkey" FOREIGN KEY ("ingestionRunId") REFERENCES public."KnowledgeIngestionRun"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: KnowledgeRawEvent KnowledgeRawEvent_messageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeRawEvent"
    ADD CONSTRAINT "KnowledgeRawEvent_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES public."ConversationMessage"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: KnowledgeSnapshotEntry KnowledgeSnapshotEntry_snapshotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeSnapshotEntry"
    ADD CONSTRAINT "KnowledgeSnapshotEntry_snapshotId_fkey" FOREIGN KEY ("snapshotId") REFERENCES public."KnowledgeSnapshot"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: KnowledgeSnapshotSource KnowledgeSnapshotSource_snapshotEntryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeSnapshotSource"
    ADD CONSTRAINT "KnowledgeSnapshotSource_snapshotEntryId_fkey" FOREIGN KEY ("snapshotEntryId") REFERENCES public."KnowledgeSnapshotEntry"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: KnowledgeSnapshot KnowledgeSnapshot_generatedByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeSnapshot"
    ADD CONSTRAINT "KnowledgeSnapshot_generatedByUserId_fkey" FOREIGN KEY ("generatedByUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: KnowledgeSuggestionFeedback KnowledgeSuggestionFeedback_actorUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeSuggestionFeedback"
    ADD CONSTRAINT "KnowledgeSuggestionFeedback_actorUserId_fkey" FOREIGN KEY ("actorUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: KnowledgeSuggestionFeedback KnowledgeSuggestionFeedback_candidateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeSuggestionFeedback"
    ADD CONSTRAINT "KnowledgeSuggestionFeedback_candidateId_fkey" FOREIGN KEY ("candidateId") REFERENCES public."KnowledgeCandidate"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: KnowledgeSuggestionFeedback KnowledgeSuggestionFeedback_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeSuggestionFeedback"
    ADD CONSTRAINT "KnowledgeSuggestionFeedback_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: KnowledgeSuggestionFeedback KnowledgeSuggestionFeedback_operatorMessageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeSuggestionFeedback"
    ADD CONSTRAINT "KnowledgeSuggestionFeedback_operatorMessageId_fkey" FOREIGN KEY ("operatorMessageId") REFERENCES public."ConversationMessage"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: KnowledgeSuggestionFeedback KnowledgeSuggestionFeedback_targetMessageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."KnowledgeSuggestionFeedback"
    ADD CONSTRAINT "KnowledgeSuggestionFeedback_targetMessageId_fkey" FOREIGN KEY ("targetMessageId") REFERENCES public."ConversationMessage"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Notification Notification_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Notification Notification_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Notification Notification_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public."Payment"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Notification Notification_recipientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_recipientId_fkey" FOREIGN KEY ("recipientId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: OrderItem OrderItem_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: OrderItem OrderItem_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: OrderItem OrderItem_variantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderItem"
    ADD CONSTRAINT "OrderItem_variantId_fkey" FOREIGN KEY ("variantId") REFERENCES public."ProductVariant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: OrderTimelineEvent OrderTimelineEvent_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderTimelineEvent"
    ADD CONSTRAINT "OrderTimelineEvent_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Order Order_activityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_activityId_fkey" FOREIGN KEY ("activityId") REFERENCES public."CalendarEvent"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Order Order_convertedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_convertedBy_fkey" FOREIGN KEY ("convertedBy") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Order Order_convertedOrderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_convertedOrderId_fkey" FOREIGN KEY ("convertedOrderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Order Order_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Order Order_originId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_originId_fkey" FOREIGN KEY ("originId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PasswordResetToken PasswordResetToken_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PasswordResetToken PasswordResetToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PaymentAttachment PaymentAttachment_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PaymentAttachment"
    ADD CONSTRAINT "PaymentAttachment_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public."Payment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PaymentPlanMilestone PaymentPlanMilestone_paymentPlanId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PaymentPlanMilestone"
    ADD CONSTRAINT "PaymentPlanMilestone_paymentPlanId_fkey" FOREIGN KEY ("paymentPlanId") REFERENCES public."PaymentPlan"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PaymentPlan PaymentPlan_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PaymentPlan"
    ADD CONSTRAINT "PaymentPlan_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Payment Payment_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductCategory ProductCategory_installServiceProductId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductCategory"
    ADD CONSTRAINT "ProductCategory_installServiceProductId_fkey" FOREIGN KEY ("installServiceProductId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ProductCategory ProductCategory_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductCategory"
    ADD CONSTRAINT "ProductCategory_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."ProductCategory"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ProductImage ProductImage_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductImage"
    ADD CONSTRAINT "ProductImage_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductImage ProductImage_variantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductImage"
    ADD CONSTRAINT "ProductImage_variantId_fkey" FOREIGN KEY ("variantId") REFERENCES public."ProductVariant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductOptionValue ProductOptionValue_optionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductOptionValue"
    ADD CONSTRAINT "ProductOptionValue_optionId_fkey" FOREIGN KEY ("optionId") REFERENCES public."ProductOption"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductOption ProductOption_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductOption"
    ADD CONSTRAINT "ProductOption_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductRelation ProductRelation_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductRelation"
    ADD CONSTRAINT "ProductRelation_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductRelation ProductRelation_relatedProductId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductRelation"
    ADD CONSTRAINT "ProductRelation_relatedProductId_fkey" FOREIGN KEY ("relatedProductId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductReview ProductReview_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductReview"
    ADD CONSTRAINT "ProductReview_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductReview ProductReview_orderItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductReview"
    ADD CONSTRAINT "ProductReview_orderItemId_fkey" FOREIGN KEY ("orderItemId") REFERENCES public."OrderItem"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ProductReview ProductReview_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductReview"
    ADD CONSTRAINT "ProductReview_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductVariantSelection ProductVariantSelection_optionValueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductVariantSelection"
    ADD CONSTRAINT "ProductVariantSelection_optionValueId_fkey" FOREIGN KEY ("optionValueId") REFERENCES public."ProductOptionValue"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductVariantSelection ProductVariantSelection_variantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductVariantSelection"
    ADD CONSTRAINT "ProductVariantSelection_variantId_fkey" FOREIGN KEY ("variantId") REFERENCES public."ProductVariant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductVariant ProductVariant_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductVariant"
    ADD CONSTRAINT "ProductVariant_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Product Product_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."ProductCategory"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Product Product_installServiceProductId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_installServiceProductId_fkey" FOREIGN KEY ("installServiceProductId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ProductionOrder ProductionOrder_assignedToId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductionOrder"
    ADD CONSTRAINT "ProductionOrder_assignedToId_fkey" FOREIGN KEY ("assignedToId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ProductionOrder ProductionOrder_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductionOrder"
    ADD CONSTRAINT "ProductionOrder_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductionOrder ProductionOrder_workOrderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductionOrder"
    ADD CONSTRAINT "ProductionOrder_workOrderId_fkey" FOREIGN KEY ("workOrderId") REFERENCES public."WorkOrder"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: StorefrontPaymentIntent StorefrontPaymentIntent_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StorefrontPaymentIntent"
    ADD CONSTRAINT "StorefrontPaymentIntent_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: StoryItem StoryItem_storyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StoryItem"
    ADD CONSTRAINT "StoryItem_storyId_fkey" FOREIGN KEY ("storyId") REFERENCES public."Story"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TaskAssignee TaskAssignee_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TaskAssignee"
    ADD CONSTRAINT "TaskAssignee_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public."Task"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TaskAssignee TaskAssignee_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TaskAssignee"
    ADD CONSTRAINT "TaskAssignee_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Task Task_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Task Task_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: UserActivity UserActivity_deviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserActivity"
    ADD CONSTRAINT "UserActivity_deviceId_fkey" FOREIGN KEY ("deviceId") REFERENCES public."UserDevice"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: UserActivity UserActivity_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserActivity"
    ADD CONSTRAINT "UserActivity_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserDevice UserDevice_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserDevice"
    ADD CONSTRAINT "UserDevice_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WishlistItem WishlistItem_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WishlistItem"
    ADD CONSTRAINT "WishlistItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WishlistItem WishlistItem_wishlistId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WishlistItem"
    ADD CONSTRAINT "WishlistItem_wishlistId_fkey" FOREIGN KEY ("wishlistId") REFERENCES public."Wishlist"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Wishlist Wishlist_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Wishlist"
    ADD CONSTRAINT "Wishlist_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WorkOrder WorkOrder_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WorkOrder"
    ADD CONSTRAINT "WorkOrder_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: analytics_baseline_snapshots analytics_baseline_snapshots_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_baseline_snapshots
    ADD CONSTRAINT analytics_baseline_snapshots_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES public.analytics_connections(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: analytics_connection_credentials analytics_connection_credentials_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_connection_credentials
    ADD CONSTRAINT analytics_connection_credentials_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES public.analytics_connections(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: analytics_data_quality_checks analytics_data_quality_checks_baseline_snapshot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_data_quality_checks
    ADD CONSTRAINT analytics_data_quality_checks_baseline_snapshot_id_fkey FOREIGN KEY (baseline_snapshot_id) REFERENCES public.analytics_baseline_snapshots(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: analytics_data_quality_checks analytics_data_quality_checks_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_data_quality_checks
    ADD CONSTRAINT analytics_data_quality_checks_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES public.analytics_connections(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: analytics_data_quality_checks analytics_data_quality_checks_sync_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_data_quality_checks
    ADD CONSTRAINT analytics_data_quality_checks_sync_run_id_fkey FOREIGN KEY (sync_run_id) REFERENCES public.analytics_sync_runs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: analytics_report_reconciliations analytics_report_reconciliations_baseline_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_report_reconciliations
    ADD CONSTRAINT analytics_report_reconciliations_baseline_run_id_fkey FOREIGN KEY (baseline_run_id) REFERENCES public.analytics_report_runs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: analytics_report_reconciliations analytics_report_reconciliations_report_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_report_reconciliations
    ADD CONSTRAINT analytics_report_reconciliations_report_key_fkey FOREIGN KEY (report_key) REFERENCES public.analytics_report_catalog(key) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: analytics_report_reconciliations analytics_report_reconciliations_sync_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_report_reconciliations
    ADD CONSTRAINT analytics_report_reconciliations_sync_run_id_fkey FOREIGN KEY (sync_run_id) REFERENCES public.analytics_report_runs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: analytics_report_rows analytics_report_rows_report_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_report_rows
    ADD CONSTRAINT analytics_report_rows_report_run_id_fkey FOREIGN KEY (report_run_id) REFERENCES public.analytics_report_runs(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: analytics_report_runs analytics_report_runs_report_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_report_runs
    ADD CONSTRAINT analytics_report_runs_report_key_fkey FOREIGN KEY (report_key) REFERENCES public.analytics_report_catalog(key) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: analytics_sync_runs analytics_sync_runs_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_sync_runs
    ADD CONSTRAINT analytics_sync_runs_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES public.analytics_connections(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dimension_price_matrix dimension_price_matrix_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dimension_price_matrix
    ADD CONSTRAINT "dimension_price_matrix_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: otp_codes otp_codes_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_codes
    ADD CONSTRAINT "otp_codes_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parametric_compatibility_rules parametric_compatibility_rules_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parametric_compatibility_rules
    ADD CONSTRAINT "parametric_compatibility_rules_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parametric_matrix_staging parametric_matrix_staging_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parametric_matrix_staging
    ADD CONSTRAINT "parametric_matrix_staging_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: security_events security_events_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT "security_events_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict EqtJ91IdSxBbTzoIEFZlc29CBKCnX8QxTvzXNajHpqQ2hl2uxo16dOtDqanuXjg

